// MeshGeometry.cs - Unified geometric computations for mesh elements
// Eliminates code duplication across SimplexRemesher, CrackDuplication, UnifiedMesher
// All methods are static, pure functions with no side effects
// License: GPLv3

using System.Text;

namespace Numerical;

/// <summary>
///     Geometric operations for mesh elements (triangles, tetrahedra, quads).
///     Provides unified implementations of Jacobian computation, orientation checking,
///     quality metrics, and area/volume calculations.
/// </summary>
public static class MeshGeometry
{
    private const double EPSILON = 1e-10;

    #region 2D Triangle Operations

    /// <summary>
    ///     Compute 2D Jacobian determinant for a triangle.
    ///     Returns twice the signed area: positive = CCW, negative = CW (inverted).
    /// </summary>
    /// <remarks>
    ///     Jacobian = (x1-x0)(y2-y0) - (x2-x0)(y1-y0)
    ///     This is 2× the signed area of the triangle.
    ///     Used for: orientation checking, quality metrics, element validity.
    /// </remarks>
    public static double ComputeTriangleJacobian(double[,] coords, int n0, int n1, int n2)
    {
        double x0 = coords[n0, 0], y0 = coords[n0, 1];
        double x1 = coords[n1, 0], y1 = coords[n1, 1];
        double x2 = coords[n2, 0], y2 = coords[n2, 1];

        return (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
    }

    /// <summary>
    ///     Compute signed area of a triangle (half of Jacobian).
    ///     Positive = CCW, negative = CW, zero = degenerate.
    /// </summary>
    public static double ComputeTriangleArea(double[,] coords, int n0, int n1, int n2)
    {
        return 0.5 * Math.Abs(ComputeTriangleJacobian(coords, n0, n1, n2));
    }

    /// <summary>
    ///     Check if triangle has counter-clockwise (CCW) orientation.
    /// </summary>
    public static bool IsTriangleCCW(double[,] coords, int n0, int n1, int n2)
    {
        return ComputeTriangleJacobian(coords, n0, n1, n2) > EPSILON;
    }

    /// <summary>
    ///     Check if triangle is degenerate (zero or near-zero area).
    /// </summary>
    public static bool IsTriangleDegenerate(double[,] coords, int n0, int n1, int n2,
        double tolerance = EPSILON)
    {
        return Math.Abs(ComputeTriangleJacobian(coords, n0, n1, n2)) < tolerance;
    }

    /// <summary>
    ///     Compute aspect ratio of a triangle (max edge / min altitude).
    ///     Perfect equilateral = 1.0, degenerate → ∞.
    /// </summary>
    public static double ComputeTriangleAspectRatio(double[,] coords, int n0, int n1, int n2)
    {
        var area = ComputeTriangleArea(coords, n0, n1, n2);
        if (area < EPSILON)
            return double.PositiveInfinity;

        // Edge lengths
        var e1 = EdgeLength(coords, n0, n1);
        var e2 = EdgeLength(coords, n1, n2);
        var e3 = EdgeLength(coords, n2, n0);

        var perimeter = e1 + e2 + e3;
        var inradius = 2.0 * area / perimeter;
        var maxEdge = Math.Max(e1, Math.Max(e2, e3));

        // Aspect ratio = maxEdge / (2 * inradius)
        return maxEdge / (2.0 * inradius);
    }

    /// <summary>
    ///     Compute minimum interior angle of a triangle in radians.
    ///     Perfect equilateral = π/3 ≈ 1.047, degenerate → 0.
    /// </summary>
    public static double ComputeTriangleMinAngle(double[,] coords, int n0, int n1, int n2)
    {
        var e1 = EdgeLength(coords, n0, n1);
        var e2 = EdgeLength(coords, n1, n2);
        var e3 = EdgeLength(coords, n2, n0);

        // Law of cosines for each angle
        var angle0 = Math.Acos((e1 * e1 + e3 * e3 - e2 * e2) / (2 * e1 * e3));
        var angle1 = Math.Acos((e1 * e1 + e2 * e2 - e3 * e3) / (2 * e1 * e2));
        var angle2 = Math.Acos((e2 * e2 + e3 * e3 - e1 * e1) / (2 * e2 * e3));

        return Math.Min(angle0, Math.Min(angle1, angle2));
    }

    #endregion

    #region 3D Tetrahedron Operations

    /// <summary>
    ///     Compute 3D Jacobian determinant for a tetrahedron.
    ///     Returns 6 times the signed volume: positive = correct orientation, negative = inverted.
    /// </summary>
    /// <remarks>
    ///     Jacobian = v1 · (v2 × v3) where v1, v2, v3 are edge vectors from n0.
    ///     This is 6× the signed volume of the tetrahedron.
    ///     Used for: orientation checking, quality metrics, element validity.
    /// </remarks>
    public static double ComputeTetrahedronJacobian(double[,] coords, int n0, int n1, int n2, int n3)
    {
        // Edge vectors from n0
        var v1x = coords[n1, 0] - coords[n0, 0];
        var v1y = coords[n1, 1] - coords[n0, 1];
        var v1z = coords[n1, 2] - coords[n0, 2];

        var v2x = coords[n2, 0] - coords[n0, 0];
        var v2y = coords[n2, 1] - coords[n0, 1];
        var v2z = coords[n2, 2] - coords[n0, 2];

        var v3x = coords[n3, 0] - coords[n0, 0];
        var v3y = coords[n3, 1] - coords[n0, 1];
        var v3z = coords[n3, 2] - coords[n0, 2];

        // Scalar triple product: v1 · (v2 × v3)
        return v1x * (v2y * v3z - v2z * v3y) -
               v1y * (v2x * v3z - v2z * v3x) +
               v1z * (v2x * v3y - v2y * v3x);
    }

    /// <summary>
    ///     Compute volume of a tetrahedron (1/6 of Jacobian).
    /// </summary>
    public static double ComputeTetrahedronVolume(double[,] coords, int n0, int n1, int n2, int n3)
    {
        return Math.Abs(ComputeTetrahedronJacobian(coords, n0, n1, n2, n3)) / 6.0;
    }

    /// <summary>
    ///     Check if tetrahedron has correct orientation (positive Jacobian).
    /// </summary>
    public static bool IsTetrahedronCorrectOrientation(double[,] coords, int n0, int n1, int n2, int n3)
    {
        return ComputeTetrahedronJacobian(coords, n0, n1, n2, n3) > EPSILON;
    }

    /// <summary>
    ///     Check if tetrahedron is degenerate (zero or near-zero volume).
    /// </summary>
    public static bool IsTetrahedronDegenerate(double[,] coords, int n0, int n1, int n2, int n3,
        double tolerance = EPSILON)
    {
        return Math.Abs(ComputeTetrahedronJacobian(coords, n0, n1, n2, n3)) < tolerance;
    }

    /// <summary>
    ///     Compute aspect ratio of a tetrahedron.
    ///     Perfect regular tetrahedron ≈ 1.0, degenerate → ∞.
    /// </summary>
    public static double ComputeTetrahedronAspectRatio(double[,] coords, int n0, int n1, int n2, int n3)
    {
        var volume = ComputeTetrahedronVolume(coords, n0, n1, n2, n3);
        if (volume < EPSILON)
            return double.PositiveInfinity;

        // Edge lengths
        var e01 = EdgeLength3D(coords, n0, n1);
        var e02 = EdgeLength3D(coords, n0, n2);
        var e03 = EdgeLength3D(coords, n0, n3);
        var e12 = EdgeLength3D(coords, n1, n2);
        var e13 = EdgeLength3D(coords, n1, n3);
        var e23 = EdgeLength3D(coords, n2, n3);

        var maxEdge = Math.Max(e01, Math.Max(e02, Math.Max(e03, Math.Max(e12, Math.Max(e13, e23)))));

        // Aspect ratio = maxEdge³ / (8.48 × volume)
        // Factor 8.48 ≈ 6√2 normalizes to 1.0 for regular tetrahedron
        return maxEdge * maxEdge * maxEdge / (8.48 * volume);
    }

    #endregion

    #region 2D Quadrilateral Operations

    /// <summary>
    ///     Check if quadrilateral has counter-clockwise (CCW) orientation.
    ///     Tests cross product at first corner.
    /// </summary>
    public static bool IsQuadCCW(double[,] coords, int n0, int n1, int n2, int n3)
    {
        var ax = coords[n1, 0] - coords[n0, 0];
        var ay = coords[n1, 1] - coords[n0, 1];
        var bx = coords[n3, 0] - coords[n0, 0];
        var by = coords[n3, 1] - coords[n0, 1];

        return ax * by - ay * bx > EPSILON;
    }

    /// <summary>
    ///     Compute area of a quadrilateral (sum of two triangles).
    ///     Assumes convex or star-shaped quad.
    /// </summary>
    public static double ComputeQuadArea(double[,] coords, int n0, int n1, int n2, int n3)
    {
        // Split into triangles (n0,n1,n2) and (n0,n2,n3)
        var area1 = ComputeTriangleArea(coords, n0, n1, n2);
        var area2 = ComputeTriangleArea(coords, n0, n2, n3);
        return area1 + area2;
    }

    /// <summary>
    ///     Check if quadrilateral is convex (all interior angles &lt; π).
    /// </summary>
    public static bool IsQuadConvex(double[,] coords, int n0, int n1, int n2, int n3)
    {
        // Check all four cross products have same sign
        var cross0 = CrossProduct2D(coords, n0, n1, n2);
        var cross1 = CrossProduct2D(coords, n1, n2, n3);
        var cross2 = CrossProduct2D(coords, n2, n3, n0);
        var cross3 = CrossProduct2D(coords, n3, n0, n1);

        var allPositive = cross0 > 0 && cross1 > 0 && cross2 > 0 && cross3 > 0;
        var allNegative = cross0 < 0 && cross1 < 0 && cross2 < 0 && cross3 < 0;

        return allPositive || allNegative;
    }

    #endregion

    #region Mesh-wide Operations

    /// <summary>
    ///     Validate mesh quality: check all elements have positive Jacobians.
    /// </summary>
    /// <returns>Number of inverted elements found</returns>
    public static int ValidateMeshOrientation(SimplexMesh mesh, double[,] coords,
        out int invertedTris, out int invertedTets)
    {
        invertedTris = 0;
        invertedTets = 0;

        // Check triangles
        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            if (!IsTriangleCCW(coords, nodes[0], nodes[1], nodes[2]))
                invertedTris++;
        }

        // Check tetrahedra
        for (var i = 0; i < mesh.Count<Tet4>(); i++)
        {
            var nodes = mesh.NodesOf<Tet4, Node>(i);
            if (!IsTetrahedronCorrectOrientation(coords, nodes[0], nodes[1], nodes[2], nodes[3]))
                invertedTets++;
        }

        return invertedTris + invertedTets;
    }

    /// <summary>
    ///     Find degenerate elements (zero or near-zero area/volume).
    /// </summary>
    public static (int[] degenerateTris, int[] degenerateTets) FindDegenerateElements(
        SimplexMesh mesh, double[,] coords, double tolerance = EPSILON)
    {
        var badTris = new List<int>();
        var badTets = new List<int>();

        // Check triangles
        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            if (IsTriangleDegenerate(coords, nodes[0], nodes[1], nodes[2], tolerance))
                badTris.Add(i);
        }

        // Check tetrahedra
        for (var i = 0; i < mesh.Count<Tet4>(); i++)
        {
            var nodes = mesh.NodesOf<Tet4, Node>(i);
            if (IsTetrahedronDegenerate(coords, nodes[0], nodes[1], nodes[2], nodes[3], tolerance))
                badTets.Add(i);
        }

        return (badTris.ToArray(), badTets.ToArray());
    }

    /// <summary>
    ///     Compute mesh quality statistics.
    /// </summary>
    public static MeshQualityStats ComputeQualityStatistics(SimplexMesh mesh, double[,] coords)
    {
        var stats = new MeshQualityStats();

        // Triangle statistics
        if (mesh.Count<Tri3>() > 0)
        {
            var minAspect = double.PositiveInfinity;
            double maxAspect = 0;
            double sumAspect = 0;

            var minAngle = double.PositiveInfinity;
            double maxAngle = 0;

            for (var i = 0; i < mesh.Count<Tri3>(); i++)
            {
                var nodes = mesh.NodesOf<Tri3, Node>(i);

                var aspect = ComputeTriangleAspectRatio(coords, nodes[0], nodes[1], nodes[2]);
                minAspect = Math.Min(minAspect, aspect);
                maxAspect = Math.Max(maxAspect, aspect);
                sumAspect += aspect;

                var angle = ComputeTriangleMinAngle(coords, nodes[0], nodes[1], nodes[2]);
                minAngle = Math.Min(minAngle, angle);
                maxAngle = Math.Max(maxAngle, angle);
            }

            stats.TriangleCount = mesh.Count<Tri3>();
            stats.MinTriangleAspectRatio = minAspect;
            stats.MaxTriangleAspectRatio = maxAspect;
            stats.AvgTriangleAspectRatio = sumAspect / mesh.Count<Tri3>();
            stats.MinTriangleAngleDegrees = minAngle * 180.0 / Math.PI;
        }

        // Tetrahedron statistics
        if (mesh.Count<Tet4>() > 0)
        {
            var minAspect = double.PositiveInfinity;
            double maxAspect = 0;
            double sumAspect = 0;

            for (var i = 0; i < mesh.Count<Tet4>(); i++)
            {
                var nodes = mesh.NodesOf<Tet4, Node>(i);

                var aspect = ComputeTetrahedronAspectRatio(coords, nodes[0], nodes[1], nodes[2], nodes[3]);
                minAspect = Math.Min(minAspect, aspect);
                maxAspect = Math.Max(maxAspect, aspect);
                sumAspect += aspect;
            }

            stats.TetrahedronCount = mesh.Count<Tet4>();
            stats.MinTetrahedronAspectRatio = minAspect;
            stats.MaxTetrahedronAspectRatio = maxAspect;
            stats.AvgTetrahedronAspectRatio = sumAspect / mesh.Count<Tet4>();
        }

        return stats;
    }

    #endregion

    #region Helper Functions

    /// <summary>
    ///     Compute 2D edge length.
    /// </summary>
    private static double EdgeLength(double[,] coords, int n0, int n1)
    {
        var dx = coords[n1, 0] - coords[n0, 0];
        var dy = coords[n1, 1] - coords[n0, 1];
        return Math.Sqrt(dx * dx + dy * dy);
    }

    /// <summary>
    ///     Compute 3D edge length.
    /// </summary>
    private static double EdgeLength3D(double[,] coords, int n0, int n1)
    {
        var dx = coords[n1, 0] - coords[n0, 0];
        var dy = coords[n1, 1] - coords[n0, 1];
        var dz = coords[n1, 2] - coords[n0, 2];
        return Math.Sqrt(dx * dx + dy * dy + dz * dz);
    }

    /// <summary>
    ///     Compute 2D cross product (scalar) at three consecutive points.
    /// </summary>
    private static double CrossProduct2D(double[,] coords, int n0, int n1, int n2)
    {
        var ax = coords[n1, 0] - coords[n0, 0];
        var ay = coords[n1, 1] - coords[n0, 1];
        var bx = coords[n2, 0] - coords[n1, 0];
        var by = coords[n2, 1] - coords[n1, 1];

        return ax * by - ay * bx;
    }

    #endregion
}

/// <summary>
///     Container for mesh quality statistics.
/// </summary>
public class MeshQualityStats
{
    public int TriangleCount { get; set; }
    public int TetrahedronCount { get; set; }

    public double MinTriangleAspectRatio { get; set; }
    public double MaxTriangleAspectRatio { get; set; }
    public double AvgTriangleAspectRatio { get; set; }

    public double MinTetrahedronAspectRatio { get; set; }
    public double MaxTetrahedronAspectRatio { get; set; }
    public double AvgTetrahedronAspectRatio { get; set; }

    public double MinTriangleAngleDegrees { get; set; }

    public override string ToString()
    {
        var sb = new StringBuilder();
        sb.AppendLine("=== Mesh Quality Statistics ===");

        if (TriangleCount > 0)
        {
            sb.AppendLine($"Triangles: {TriangleCount}");
            sb.AppendLine(
                $"  Aspect Ratio: {MinTriangleAspectRatio:F2} - {MaxTriangleAspectRatio:F2} (avg: {AvgTriangleAspectRatio:F2})");
            sb.AppendLine($"  Min Angle: {MinTriangleAngleDegrees:F1}°");
        }

        if (TetrahedronCount > 0)
        {
            sb.AppendLine($"Tetrahedra: {TetrahedronCount}");
            sb.AppendLine(
                $"  Aspect Ratio: {MinTetrahedronAspectRatio:F2} - {MaxTetrahedronAspectRatio:F2} (avg: {AvgTetrahedronAspectRatio:F2})");
        }

        return sb.ToString();
    }
}
