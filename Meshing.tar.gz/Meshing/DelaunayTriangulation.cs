// DelaunayTriangulation.cs - Bowyer-Watson Delaunay triangulation
// Extracted from UnifiedMesher.cs for clean architecture
// License: GPLv3

using static Numerical.GeometryUtilities;
using static Numerical.CurveUtilities;

namespace Numerical;

/// <summary>
///     Delaunay triangulation via Bowyer-Watson algorithm.
///     Generates constrained Delaunay triangulation for arbitrary 2D polygons with holes.
///     Supports adaptive mesh sizing based on boundary edge lengths.
/// </summary>
public static class DelaunayTriangulation
{
    private const double EPSILON = 1e-10;

    #region Public API

    /// <summary>
    ///     Create Delaunay triangulation for a polygon with optional holes.
    /// </summary>
    /// <param name="outerBoundary">Outer boundary in CCW order [n,2]</param>
    /// <param name="holes">Optional hole boundaries in CW order</param>
    /// <param name="interiorPoints">Optional interior points for seeding</param>
    /// <param name="targetEdgeLength">Target edge length for uniform sizing (0 = adaptive from boundary)</param>
    /// <returns>List of points and list of triangles (as node index triples)</returns>
    public static (List<(double x, double y)> points, List<(int v0, int v1, int v2)> triangles)
        Triangulate(
            double[,] outerBoundary,
            List<double[,]>? holes = null,
            double[,]? interiorPoints = null,
            double targetEdgeLength = 0.0)
    {
        Console.WriteLine("[DelaunayTriangulation] Starting...");
        Console.WriteLine($"  Outer boundary: {outerBoundary.GetLength(0)} points");

        // Extract and prepare boundaries
        var outerPts = ExtractCurve2D(outerBoundary);
        var holePts = new List<List<(double x, double y)>>();

        if (holes != null)
        {
            foreach (var hole in holes) holePts.Add(ExtractCurve2D(hole));
            Console.WriteLine($"  Holes: {holePts.Count}");
        }

        // Collect all boundary points
        var points = new List<(double x, double y)>();
        points.AddRange(outerPts);
        var nOuter = outerPts.Count;

        var nHoleVerts = 0;
        foreach (var hole in holePts)
        {
            points.AddRange(hole);
            nHoleVerts += hole.Count;
        }

        Console.WriteLine($"  Total boundary vertices: {nOuter + nHoleVerts}");

        // Generate interior points if not provided
        if (interiorPoints == null && targetEdgeLength > 0)
        {
            Console.WriteLine($"  Generating interior grid with spacing {targetEdgeLength:F4}...");
            var interiorList = GenerateInteriorGrid(outerBoundary, holes, targetEdgeLength);
            points.AddRange(interiorList);
            Console.WriteLine($"  Generated {interiorList.Count} interior points");
        }
        // Add user-provided interior points
        else if (interiorPoints != null)
        {
            for (var i = 0; i < interiorPoints.GetLength(0); i++)
                points.Add((interiorPoints[i, 0], interiorPoints[i, 1]));
            Console.WriteLine($"  Interior seed points: {interiorPoints.GetLength(0)}");
        }
        // Auto-generate based on boundary edge lengths
        else
        {
            var avgEdgeLength = ComputeAverageEdgeLength(outerPts);
            var autoSpacing = avgEdgeLength * 1.5; // Slightly larger than boundary
            Console.WriteLine($"  Auto-generating interior grid with spacing {autoSpacing:F4}...");
            var interiorList = GenerateInteriorGrid(outerBoundary, holes, autoSpacing);
            points.AddRange(interiorList);
            Console.WriteLine($"  Generated {interiorList.Count} interior points");
        }

        var totalPoints = points.Count;

        // Compute bounding box
        var (xMin, xMax, yMin, yMax) = ComputeBoundingBox2D(points);
        var dx = xMax - xMin;
        var dy = yMax - yMin;
        var margin = Math.Max(dx, dy) * 0.1;

        // Create super-triangle (large enough to contain all points)
        var superTriangle = CreateSuperTriangle(xMin - margin, xMax + margin,
            yMin - margin, yMax + margin);

        // Add super-triangle vertices to points
        var st0 = points.Count;
        var st1 = st0 + 1;
        var st2 = st0 + 2;
        points.Add(superTriangle.v0);
        points.Add(superTriangle.v1);
        points.Add(superTriangle.v2);

        // Initialize triangulation with super-triangle
        var triangles = new List<(int v0, int v1, int v2)> { (st0, st1, st2) };
        var circumcenters = new List<(double x, double y, double rSq)>();
        circumcenters.Add(ComputeCircumcircle(superTriangle.v0, superTriangle.v1, superTriangle.v2));

        Console.WriteLine($"  Inserting {totalPoints} points via Bowyer-Watson...");

        // Insert all points one by one (Bowyer-Watson)
        for (var i = 0; i < totalPoints; i++) AddPointBW(i, points, triangles, circumcenters);

        Console.WriteLine($"  → Triangulation complete: {triangles.Count} triangles");

        // Remove triangles connected to super-triangle vertices
        var validTriangles = triangles
            .Where(t => t.v0 < totalPoints && t.v1 < totalPoints && t.v2 < totalPoints)
            .ToList();

        Console.WriteLine($"  → After super-triangle removal: {validTriangles.Count} triangles");

        // Filter triangles outside polygon or inside holes
        validTriangles = FilterTriangles(validTriangles, points, outerPts, holePts);

        Console.WriteLine($"  → After boundary filtering: {validTriangles.Count} triangles");

        // Remove super-triangle points
        points.RemoveRange(totalPoints, 3);

        return (points, validTriangles);
    }

    #endregion

    #region Circumcircle Computation

    /// <summary>
    ///     Compute circumcircle of a triangle.
    ///     Returns (center_x, center_y, radius_squared).
    /// </summary>
    private static (double x, double y, double rSq) ComputeCircumcircle(
        (double x, double y) p0,
        (double x, double y) p1,
        (double x, double y) p2)
    {
        var ax = p1.x - p0.x;
        var ay = p1.y - p0.y;
        var bx = p2.x - p0.x;
        var by = p2.y - p0.y;

        var d = 2 * (ax * by - ay * bx);

        if (Math.Abs(d) < EPSILON)
            // Degenerate triangle - return large circle
            return (0, 0, double.MaxValue);

        var aSq = ax * ax + ay * ay;
        var bSq = bx * bx + by * by;

        var ux = (by * aSq - ay * bSq) / d;
        var uy = (ax * bSq - bx * aSq) / d;

        var cx = p0.x + ux;
        var cy = p0.y + uy;
        var rSq = ux * ux + uy * uy;

        return (cx, cy, rSq);
    }

    #endregion

    #region Super-Triangle

    /// <summary>
    ///     Create super-triangle that contains the entire domain.
    /// </summary>
    private static ((double x, double y) v0, (double x, double y) v1, (double x, double y) v2)
        CreateSuperTriangle(double xMin, double xMax, double yMin, double yMax)
    {
        var dx = xMax - xMin;
        var dy = yMax - yMin;
        var dMax = Math.Max(dx, dy);

        var cx = (xMin + xMax) / 2;
        var cy = (yMin + yMax) / 2;

        // Create large triangle
        var scale = 3.0;
        var v0 = (cx - scale * dMax, cy - scale * dMax);
        var v1 = (cx + scale * dMax, cy - scale * dMax);
        var v2 = (cx, cy + scale * dMax);

        return (v0, v1, v2);
    }

    #endregion

    #region Triangle Filtering

    /// <summary>
    ///     Filter triangles: keep only those inside outer boundary and outside holes.
    /// </summary>
    private static List<(int v0, int v1, int v2)> FilterTriangles(
        List<(int v0, int v1, int v2)> triangles,
        List<(double x, double y)> points,
        List<(double x, double y)> outerBoundary,
        List<List<(double x, double y)>> holes)
    {
        var filtered = new List<(int v0, int v1, int v2)>();

        // Convert boundaries to arrays for point-in-polygon test
        var outerArray = ConvertToArray(outerBoundary);
        var holeArrays = holes.Select(h => ConvertToArray(h)).ToList();

        foreach (var tri in triangles)
        {
            // Compute triangle centroid
            var p0 = points[tri.v0];
            var p1 = points[tri.v1];
            var p2 = points[tri.v2];

            var centroid = (
                (p0.x + p1.x + p2.x) / 3.0,
                (p0.y + p1.y + p2.y) / 3.0
            );

            // Check if centroid is inside outer boundary
            if (!IsPointInPolygon(centroid, outerArray))
                continue;

            // Check if centroid is inside any hole
            var inHole = false;
            foreach (var holeArray in holeArrays)
                if (IsPointInPolygon(centroid, holeArray))
                {
                    inHole = true;
                    break;
                }

            if (inHole)
                continue;

            // Triangle is valid
            filtered.Add(tri);
        }

        return filtered;
    }

    #endregion

    #region Constrained Edges (Optional Enhancement)

    /// <summary>
    ///     Enforce boundary edges as constraints (not yet implemented).
    ///     This would ensure boundary edges are preserved exactly.
    /// </summary>
    private static void EnforceBoundaryConstraints(
        List<(int v0, int v1, int v2)> triangles,
        List<(double x, double y)> points,
        List<(int, int)> constrainedEdges)
    {
        // TODO: Implement constrained Delaunay
        // For now, filtering by polygon is sufficient for most cases
    }

    #endregion

    #region Bowyer-Watson Core

    /// <summary>
    ///     Add a point to the triangulation using Bowyer-Watson algorithm.
    /// </summary>
    private static void AddPointBW(
        int pointIdx,
        List<(double x, double y)> points,
        List<(int v0, int v1, int v2)> triangles,
        List<(double x, double y, double rSq)> circumcenters)
    {
        var point = points[pointIdx];
        var badTriangles = new List<int>();

        // Find triangles whose circumcircle contains the point
        for (var i = 0; i < triangles.Count; i++)
        {
            var (cx, cy, rSq) = circumcenters[i];
            var dx = point.x - cx;
            var dy = point.y - cy;
            var distSq = dx * dx + dy * dy;

            if (distSq < rSq - EPSILON) badTriangles.Add(i);
        }

        if (badTriangles.Count == 0)
            return;

        // Find the boundary of the polygonal hole
        var polygon = new List<(int v0, int v1)>();

        foreach (var ti in badTriangles)
        {
            var (v0, v1, v2) = triangles[ti];

            // Add all edges
            var edges = new[] { (v0, v1), (v1, v2), (v2, v0) };

            foreach (var edge in edges)
            {
                // Check if this edge is shared with another bad triangle
                var isShared = false;

                foreach (var tj in badTriangles)
                {
                    if (ti == tj) continue;

                    var (u0, u1, u2) = triangles[tj];

                    if (SharesEdge(edge, (u0, u1)) ||
                        SharesEdge(edge, (u1, u2)) ||
                        SharesEdge(edge, (u2, u0)))
                    {
                        isShared = true;
                        break;
                    }
                }

                // Only keep boundary edges (not shared)
                if (!isShared) polygon.Add(edge);
            }
        }

        // Remove bad triangles (in reverse order to maintain indices)
        badTriangles.Sort();
        for (var i = badTriangles.Count - 1; i >= 0; i--)
        {
            var idx = badTriangles[i];
            triangles.RemoveAt(idx);
            circumcenters.RemoveAt(idx);
        }

        // Create new triangles from point to polygon boundary
        foreach (var (v0, v1) in polygon)
        {
            triangles.Add((pointIdx, v0, v1));

            var p0 = points[pointIdx];
            var p1 = points[v0];
            var p2 = points[v1];
            circumcenters.Add(ComputeCircumcircle(p0, p1, p2));
        }
    }

    /// <summary>
    ///     Check if two edges share the same vertices (regardless of order).
    /// </summary>
    private static bool SharesEdge((int a, int b) edge1, (int a, int b) edge2)
    {
        return (edge1.a == edge2.a && edge1.b == edge2.b) ||
               (edge1.a == edge2.b && edge1.b == edge2.a);
    }

    #endregion

    #region Interior Point Generation

    /// <summary>
    ///     Generate interior grid points with hexagonal packing.
    ///     Points are filtered to be inside outer boundary and outside holes.
    /// </summary>
    private static List<(double x, double y)> GenerateInteriorGrid(
        double[,] outerBoundary,
        List<double[,]>? holes,
        double spacing)
    {
        var interiorPoints = new List<(double x, double y)>();

        // Get bounding box
        var n = outerBoundary.GetLength(0);
        double minX = double.MaxValue, maxX = double.MinValue;
        double minY = double.MaxValue, maxY = double.MinValue;

        for (var i = 0; i < n; i++)
        {
            var x = outerBoundary[i, 0];
            var y = outerBoundary[i, 1];
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
        }

        // Create quasi-uniform grid with hexagonal packing
        var random = new Random(12345); // Fixed seed for reproducibility
        var perturbation = spacing * 0.15; // Small perturbation for better quality

        var rowIndex = 0;
        for (var y = minY + spacing; y < maxY; y += spacing * 0.866) // Hex spacing: sqrt(3)/2
        {
            var xOffset = rowIndex % 2 == 1 ? spacing * 0.5 : 0.0; // Hex offset
            for (var x = minX + spacing + xOffset; x < maxX; x += spacing)
            {
                // Add small random perturbation to avoid perfect alignment
                var px = x + (random.NextDouble() - 0.5) * 2 * perturbation;
                var py = y + (random.NextDouble() - 0.5) * 2 * perturbation;

                // Check if inside outer boundary
                var point = (px, py);
                if (!IsPointInPolygon(point, outerBoundary))
                    continue;

                // Check if NOT inside any hole
                var inHole = false;
                if (holes != null)
                    foreach (var hole in holes)
                        if (IsPointInPolygon(point, hole))
                        {
                            inHole = true;
                            break;
                        }

                if (!inHole)
                    interiorPoints.Add(point);
            }

            rowIndex++;
        }

        return interiorPoints;
    }

    /// <summary>
    ///     Check if a point is inside a polygon using ray casting algorithm.
    /// </summary>
    private static bool IsPointInPolygon((double x, double y) point, double[,] polygon)
    {
        var n = polygon.GetLength(0);
        var inside = false;

        double px = point.x, py = point.y;

        for (int i = 0, j = n - 1; i < n; j = i++)
        {
            double xi = polygon[i, 0], yi = polygon[i, 1];
            double xj = polygon[j, 0], yj = polygon[j, 1];

            if (yi > py != yj > py &&
                px < (xj - xi) * (py - yi) / (yj - yi) + xi)
                inside = !inside;
        }

        return inside;
    }

    /// <summary>
    ///     Compute average edge length of a polygon.
    /// </summary>
    private static double ComputeAverageEdgeLength(List<(double x, double y)> points)
    {
        var n = points.Count;
        double totalLength = 0;

        for (var i = 0; i < n; i++)
        {
            var p1 = points[i];
            var p2 = points[(i + 1) % n];
            var dx = p2.x - p1.x;
            var dy = p2.y - p1.y;
            totalLength += Math.Sqrt(dx * dx + dy * dy);
        }

        return totalLength / n;
    }

    #endregion
}

/// <summary>
///     USAGE EXAMPLE:
///     var boundary = new double[,] { {0,0}, {1,0}, {1,1}, {0,1} };
///     var (points, triangles) = DelaunayTriangulation.Triangulate(boundary);
///     // Convert to SimplexMesh
///     var mesh = new SimplexMesh();
///     var coords = new double[points.Count, 3];
///     mesh.WithBatch(() => {
///     for (int i = 0; i
///     < points.Count; i++) {
///         coords[ i, 0]= points[ i]. x;
///         coords[ i, 1]= points[ i]. y;
///         coords[ i, 2]= 0;
///         mesh.AddNode( i);
///         }
///         foreach ( var ( v0, v1, v2) in triangles) {
///         mesh.AddTriangle( v0, v1, v2);
///     }
///     });
/// </summary>
public static class DelaunayTriangulationUsageExample
{
    // Documentation only
}