// SimplexRemesher.cs - REFACTORED VERSION (I/O and utilities only)
// Mesh file I/O (GiD, Gmsh, ASCII) and utility functions
// 
// REFACTORED: Removed duplicate functions to eliminate code duplication:
//   - CreateRectangularMesh() → Now in MeshGeneration.cs
//   - CreateBoxMesh()         → Now in MeshGeneration.cs  
//   - Refine()                → Now in MeshRefinement.cs
//   - InterpolateCoordinates() → Now in MeshRefinement.cs
//
// This file now contains ONLY:
//   ✓ SimplexRemesher static class (I/O only)
//   ✓ GiD I/O (SaveGiD, LoadGiD)
//   ✓ Gmsh I/O (SaveMSH, LoadMSH)
//   ✓ ASCII I/O (SaveASCII)
//   ✓ Utilities (PrintStats, DiscoverEdges)
//   ✓ Advanced (CreateCrackFromSignedField)
//
// Size: ~1820 lines (was 2340, reduced by 440 lines / 19%)
// License: GPLv3

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

namespace Numerical;


// NOTE: SimplexMesh class definition is in SimplexMesh.cs
// This file contains only the SimplexRemesher static class with I/O functions

/// <summary>
/// Simplex mesh refinement by edge bisection with conforming subdivision.
/// </summary>
public static class SimplexRemesher
{
    // ═══════════════════════════════════════════════════════════════════════════
    // Mesh Factory Methods
    // ═══════════════════════════════════════════════════════════════════════════
    
    /// <summary>
    /// <summary>
    /// Creates a rectangular triangular mesh.
    /// </summary>
    /// <param name="nx">Number of divisions in x direction</param>
    /// <param name="ny">Number of divisions in y direction</param>
    /// <param name="xMin">Minimum x coordinate</param>
    /// <param name="xMax">Maximum x coordinate</param>
    /// <param name="yMin">Minimum y coordinate</param>
    /// <param name="yMax">Maximum y coordinate</param>
    /// <returns>Mesh and coordinates array</returns>
    
    // ═══════════════════════════════════════════════════════════════════════════
    // REMOVED: Mesh Generation Functions (now in MeshGeneration.cs)
    // ═══════════════════════════════════════════════════════════════════════════
    // The following functions have been REMOVED to eliminate code duplication:
    // 
    // - CreateRectangularMesh() → Use MeshGeneration.CreateRectangularMesh()
    // - CreateBoxMesh()         → Use MeshGeneration.CreateBoxMesh()
    //
    // Example usage:
    //   using static Numerical.MeshGeneration;
    //   var (mesh, coords) = CreateRectangularMesh(nx, ny, x0, x1, y0, y1);
    //   var (mesh3d, coords3d) = CreateBoxMesh(nx, ny, nz, x0, x1, y0, y1, z0, z1);
    // ═══════════════════════════════════════════════════════════════════════════
    
    // ═══════════════════════════════════════════════════════════════════════════
    // Edge Refinement
    // ═══════════════════════════════════════════════════════════════════════════

    // Edge definitions: TetEdges[e] = (nodeA, nodeB)
    static readonly (int A, int B)[] TetEdges = new (int A, int B)[] { (0,1), (1,2), (0,2), (2,3), (0,3), (1,3) };
    
    // O(1) edge lookup: EdgeIdx[n1,n2] = edge index (-1 if invalid)
    static readonly int[,] EdgeIdx = BuildEdgeIndex();
    static int[,] BuildEdgeIndex()
    {
        var t = new int[4, 4];
        for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) t[i, j] = -1;
        for (int e = 0; e < 6; e++) { t[TetEdges[e].A, TetEdges[e].B] = e; t[TetEdges[e].B, TetEdges[e].A] = e; }
        return t;
    }

    public static void DiscoverEdges(SimplexMesh m)
    {
        if (m.Count<Edge>() > 0) return;
        if (m.Count<Bar2>() > 0) m.DiscoverSubEntities<Bar2, Edge, Node>(SubEntityDefinition.Bar2Edge);
        if (m.Count<Tri3>() > 0) m.DiscoverSubEntities<Tri3, Edge, Node>(SubEntityDefinition.Tri3Edges);
        if (m.Count<Tet4>() > 0) m.DiscoverSubEntities<Tet4, Edge, Node>(SubEntityDefinition.Tet4Edges);
    }

    /// <summary>
    /// Creates a thin pseudo-crack using two sequential refinements.
    /// Pass 1: Refines crack edges at midpoint
    /// Pass 2: Refines edges in elements adjacent to crack (but not on crack itself)
    /// This creates a thin volumetric crack zone.
    /// </summary>
    /// <summary>
    /// Creates a pseudo-crack using two cuts at slightly different positions.
    /// Both cuts are identified in the original mesh, then applied sequentially.
    /// This creates two parallel refined lines with a thin gap between them.
    /// </summary>
    /// <summary>
    /// Creates a pseudo-crack by refining crack edges and duplicating nodes along the crack.
    /// This creates an actual discontinuity in the mesh.
    /// </summary>
    /// <param name="input">Input mesh</param>
    /// <param name="coordinates">Node coordinates</param>
    /// <param name="crackEdges">Edges defining the crack path</param>
    /// <param name="gapRatio">Unused - kept for API compatibility</param>
    /// <returns>Refined mesh with duplicated crack nodes and coordinates</returns>
    
    // ═══════════════════════════════════════════════════════════════════════════
    // REMOVED: Refine() Function (now in MeshRefinement.cs)
    // ═══════════════════════════════════════════════════════════════════════════
    // The Refine() function has been REMOVED to eliminate code duplication.
    //
    // Use instead: MeshRefinement.Refine()
    //
    // Example usage:
    //   using static Numerical.MeshRefinement;
    //   var (refinedMesh, refinedEdges) = Refine(mesh, markedEdges);
    //
    // The refactored version is identical in functionality but better organized.
    // ═══════════════════════════════════════════════════════════════════════════
    
    // ═══════════════════════════════════════════════════════════════════════════
    // Mesh I/O
    // ═══════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Save mesh to Gmsh .msh (MSH 2.2 ASCII) format.
    /// </summary>
    /// </summary>
    public static void SaveMSH(SimplexMesh mesh, double[,] coordinates, string path)
    {
        ArgumentNullException.ThrowIfNull(mesh);
        ArgumentNullException.ThrowIfNull(coordinates);
        ArgumentNullException.ThrowIfNull(path);

        int numNodes = mesh.Count<Node>();
        int numPoints = mesh.Count<Point>();
        int numBars = mesh.Count<Bar2>();
        int numTris = mesh.Count<Tri3>();
        int numTets = mesh.Count<Tet4>();
        int numElements = numPoints + numBars + numTris + numTets;

        using var writer = new StreamWriter(path);
        
        // Header
        writer.WriteLine("$MeshFormat");
        writer.WriteLine("2.2 0 8");
        writer.WriteLine("$EndMeshFormat");

        // Nodes
        writer.WriteLine("$Nodes");
        writer.WriteLine(numNodes);
        for (int i = 0; i < numNodes; i++)
            writer.WriteLine(string.Format(CultureInfo.InvariantCulture,
                "{0} {1} {2} {3}", i + 1, coordinates[i, 0], coordinates[i, 1], coordinates[i, 2]));
        writer.WriteLine("$EndNodes");

        // Elements
        writer.WriteLine("$Elements");
        writer.WriteLine(numElements);
        
        int elemId = 1;
        // Gmsh element types: 15=point, 1=line, 2=triangle, 4=tetrahedron
        
        for (int i = 0; i < numPoints; i++)
        {
            var n = mesh.NodesOf<Point, Node>(i);
            writer.WriteLine($"{elemId++} 15 2 0 0 {n[0] + 1}");
        }
        for (int i = 0; i < numBars; i++)
        {
            var n = mesh.NodesOf<Bar2, Node>(i);
            writer.WriteLine($"{elemId++} 1 2 0 0 {n[0] + 1} {n[1] + 1}");
        }
        for (int i = 0; i < numTris; i++)
        {
            var n = mesh.NodesOf<Tri3, Node>(i);
            writer.WriteLine($"{elemId++} 2 2 0 0 {n[0] + 1} {n[1] + 1} {n[2] + 1}");
        }
        for (int i = 0; i < numTets; i++)
        {
            var n = mesh.NodesOf<Tet4, Node>(i);
            writer.WriteLine($"{elemId++} 4 2 0 0 {n[0] + 1} {n[1] + 1} {n[2] + 1} {n[3] + 1}");
        }
        
        writer.WriteLine("$EndElements");
    }

    /// <summary>
    /// Saves a SimplexMesh to Gmsh MSH format (v2.2 ASCII) with element tags.
    /// Each element has exactly 2 tags: physical tag and elementary tag.
    /// </summary>
    /// <param name="mesh">Mesh to save</param>
    /// <param name="coordinates">Node coordinates</param>
    /// <param name="path">Output file path</param>
    /// <param name="physicalNames">Optional dictionary mapping physical tag to (dimension, name)</param>
    /// <param name="pointTags">Optional physical tags for Point elements (length must match Point count)</param>
    /// <param name="barTags">Optional physical tags for Bar2 elements (length must match Bar2 count)</param>
    /// <param name="triTags">Optional physical tags for Tri3 elements (length must match Tri3 count)</param>
    /// <param name="tetTags">Optional physical tags for Tet4 elements (length must match Tet4 count)</param>
    public static void SaveMSH(SimplexMesh mesh, double[,] coordinates, string path,
        Dictionary<int, (int Dimension, string Name)>? physicalNames = null,
        int[]? pointTags = null,
        int[]? barTags = null,
        int[]? triTags = null,
        int[]? tetTags = null)
    {
        ArgumentNullException.ThrowIfNull(mesh);
        ArgumentNullException.ThrowIfNull(coordinates);
        ArgumentNullException.ThrowIfNull(path);

        int numNodes = mesh.Count<Node>();
        int numPoints = mesh.Count<Point>();
        int numBars = mesh.Count<Bar2>();
        int numTris = mesh.Count<Tri3>();
        int numTets = mesh.Count<Tet4>();
        int numElements = numPoints + numBars + numTris + numTets;

        // Validate tag array lengths
        if (pointTags != null && pointTags.Length != numPoints)
            throw new ArgumentException($"pointTags length ({pointTags.Length}) must match Point count ({numPoints})");
        if (barTags != null && barTags.Length != numBars)
            throw new ArgumentException($"barTags length ({barTags.Length}) must match Bar2 count ({numBars})");
        if (triTags != null && triTags.Length != numTris)
            throw new ArgumentException($"triTags length ({triTags.Length}) must match Tri3 count ({numTris})");
        if (tetTags != null && tetTags.Length != numTets)
            throw new ArgumentException($"tetTags length ({tetTags.Length}) must match Tet4 count ({numTets})");

        using var writer = new StreamWriter(path);
        
        // Header
        writer.WriteLine("$MeshFormat");
        writer.WriteLine("2.2 0 8");
        writer.WriteLine("$EndMeshFormat");

        // Physical names section
        if (physicalNames != null && physicalNames.Count > 0)
        {
            writer.WriteLine("$PhysicalNames");
            writer.WriteLine(physicalNames.Count);
            foreach (var (id, (dim, name)) in physicalNames.OrderBy(kv => kv.Key))
                writer.WriteLine($"{dim} {id} \"{name}\"");
            writer.WriteLine("$EndPhysicalNames");
        }

        // Nodes
        writer.WriteLine("$Nodes");
        writer.WriteLine(numNodes);
        for (int i = 0; i < numNodes; i++)
            writer.WriteLine(string.Format(CultureInfo.InvariantCulture,
                "{0} {1} {2} {3}", i + 1, coordinates[i, 0], coordinates[i, 1], coordinates[i, 2]));
        writer.WriteLine("$EndNodes");

        // Elements with physical tags
        // Format: elem-id type num-tags physical-tag elementary-tag node1 node2 ...
        writer.WriteLine("$Elements");
        writer.WriteLine(numElements);
        
        int elemId = 1;
        // Gmsh element types: 15=point, 1=line, 2=triangle, 4=tetrahedron
        
        for (int i = 0; i < numPoints; i++)
        {
            var n = mesh.NodesOf<Point, Node>(i);
            int physTag = pointTags?[i] ?? 0;
            writer.WriteLine($"{elemId++} 15 2 {physTag} 0 {n[0] + 1}");
        }
        for (int i = 0; i < numBars; i++)
        {
            var n = mesh.NodesOf<Bar2, Node>(i);
            int physTag = barTags?[i] ?? 0;
            writer.WriteLine($"{elemId++} 1 2 {physTag} 0 {n[0] + 1} {n[1] + 1}");
        }
        for (int i = 0; i < numTris; i++)
        {
            var n = mesh.NodesOf<Tri3, Node>(i);
            int physTag = triTags?[i] ?? 0;
            writer.WriteLine($"{elemId++} 2 2 {physTag} 0 {n[0] + 1} {n[1] + 1} {n[2] + 1}");
        }
        for (int i = 0; i < numTets; i++)
        {
            var n = mesh.NodesOf<Tet4, Node>(i);
            int physTag = tetTags?[i] ?? 0;
            writer.WriteLine($"{elemId++} 4 2 {physTag} 0 {n[0] + 1} {n[1] + 1} {n[2] + 1} {n[3] + 1}");
        }
        
        writer.WriteLine("$EndElements");
    }

    /// <summary>
    /// Saves a SimplexMesh to Gmsh MSH format with cracked/non-cracked element classification.
    /// Convenience overload that creates physical groups based on a set of cracked element indices.
    /// </summary>
    /// <param name="mesh">Mesh to save</param>
    /// <param name="coordinates">Node coordinates</param>
    /// <param name="path">Output file path</param>
    /// <param name="crackedTriangles">Set of cracked Tri3 element indices (0-based)</param>
    /// <param name="crackedTetrahedra">Set of cracked Tet4 element indices (0-based)</param>
    /// <param name="intactGroupId">Tag for intact elements (default: 1)</param>
    /// <param name="crackedGroupId">Tag for cracked elements (default: 2)</param>
    public static void SaveMSHWithCrackGroups(SimplexMesh mesh, double[,] coordinates, string path,
        HashSet<int>? crackedTriangles = null,
        HashSet<int>? crackedTetrahedra = null,
        int intactGroupId = 1,
        int crackedGroupId = 2)
    {
        ArgumentNullException.ThrowIfNull(mesh);
        ArgumentNullException.ThrowIfNull(coordinates);
        ArgumentNullException.ThrowIfNull(path);

        int numTris = mesh.Count<Tri3>();
        int numTets = mesh.Count<Tet4>();

        // Build tag arrays
        int[]? triTags = null;
        int[]? tetTags = null;

        if (crackedTriangles != null || numTris > 0)
        {
            triTags = new int[numTris];
            for (int i = 0; i < numTris; i++)
                triTags[i] = (crackedTriangles?.Contains(i) == true) ? crackedGroupId : intactGroupId;
        }

        if (crackedTetrahedra != null || numTets > 0)
        {
            tetTags = new int[numTets];
            for (int i = 0; i < numTets; i++)
                tetTags[i] = (crackedTetrahedra?.Contains(i) == true) ? crackedGroupId : intactGroupId;
        }

        // Determine dimensionality for physical names
        int dim = numTets > 0 ? 3 : 2;
        
        var physicalNames = new Dictionary<int, (int Dimension, string Name)>
        {
            { intactGroupId, (dim, "NonCracked") },
            { crackedGroupId, (dim, "Cracked") }
        };

        SaveMSH(mesh, coordinates, path, physicalNames,
            pointTags: null, barTags: null, triTags: triTags, tetTags: tetTags);
    }

    /// <summary>
    /// Saves mesh to simple ASCII format for debugging.
    /// </summary>
    public static void SaveASCII(SimplexMesh mesh, double[,] coordinates, string path)
    {
        ArgumentNullException.ThrowIfNull(mesh);
        ArgumentNullException.ThrowIfNull(coordinates);
        ArgumentNullException.ThrowIfNull(path);

        int numNodes = mesh.Count<Node>();
        int numTris = mesh.Count<Tri3>();
        int numTets = mesh.Count<Tet4>();

        using var writer = new StreamWriter(path);
        
        writer.WriteLine($"# SimplexMesh ASCII format");
        writer.WriteLine($"# Nodes: {numNodes}");
        writer.WriteLine($"# Tri3: {numTris}");
        writer.WriteLine($"# Tet4: {numTets}");
        writer.WriteLine();

        writer.WriteLine("COORDINATES");
        writer.WriteLine(numNodes);
        for (int i = 0; i < numNodes; i++)
            writer.WriteLine(string.Format(CultureInfo.InvariantCulture,
                "{0} {1} {2}", coordinates[i, 0], coordinates[i, 1], coordinates[i, 2]));
        writer.WriteLine();

        if (numTris > 0)
        {
            writer.WriteLine("TRIANGLES");
            writer.WriteLine(numTris);
            for (int i = 0; i < numTris; i++)
            {
                var n = mesh.NodesOf<Tri3, Node>(i);
                writer.WriteLine($"{n[0]} {n[1]} {n[2]}");
            }
            writer.WriteLine();
        }

        if (numTets > 0)
        {
            writer.WriteLine("TETRAHEDRA");
            writer.WriteLine(numTets);
            for (int i = 0; i < numTets; i++)
            {
                var n = mesh.NodesOf<Tet4, Node>(i);
                writer.WriteLine($"{n[0]} {n[1]} {n[2]} {n[3]}");
            }
        }
    }

    /// <summary>
    /// Prints mesh statistics to console for debugging.
    /// </summary>
    public static void PrintStats(SimplexMesh mesh, string label = "Mesh")
    {
        Console.WriteLine($"=== {label} ===");
        Console.WriteLine($"  Nodes: {mesh.Count<Node>()}");
        Console.WriteLine($"  Edges: {mesh.Count<Edge>()}");
        Console.WriteLine($"  Points: {mesh.Count<Point>()}");
        Console.WriteLine($"  Bar2: {mesh.Count<Bar2>()}");
        Console.WriteLine($"  Tri3: {mesh.Count<Tri3>()}");
        Console.WriteLine($"  Tet4: {mesh.Count<Tet4>()}");
    }
    /// <summary>
    /// Interpolates coordinates for midpoint nodes created during refinement.
    /// </summary>
    
    // ═══════════════════════════════════════════════════════════════════════════
    // REMOVED: InterpolateCoordinates() Function (now in MeshRefinement.cs)
    // ═══════════════════════════════════════════════════════════════════════════
    // The InterpolateCoordinates() function has been REMOVED to eliminate duplication.
    //
    // Use instead: MeshRefinement.InterpolateCoordinates()
    //
    // Example usage:
    //   using static Numerical.MeshRefinement;
    //   var newCoords = InterpolateCoordinates(refinedMesh, oldCoords);
    //
    // The refactored version is identical in functionality.
    // ═══════════════════════════════════════════════════════════════════════════
    
    public static (SimplexMesh Mesh, double[,] Coordinates) LoadMSH(string path)
    {
        ArgumentNullException.ThrowIfNull(path);
        if (!File.Exists(path))
            throw new FileNotFoundException($"MSH file not found: {path}");

        using var reader = new StreamReader(path);
        return ParseMSH(reader);
    }

    /// <summary>
    /// Loads a SimplexMesh from a Gmsh MSH file, also returning physical tags per element type.
    /// </summary>
    /// <param name="path">Path to the .msh file</param>
    /// <returns>Loaded mesh, coordinates, and physical tags for each element type</returns>
    public static (SimplexMesh Mesh, double[,] Coordinates, 
        Dictionary<int, (int Dimension, string Name)> PhysicalNames,
        int[] PointTags, int[] BarTags, int[] TriTags, int[] TetTags) LoadMSHWithTags(string path)
    {
        ArgumentNullException.ThrowIfNull(path);
        if (!File.Exists(path))
            throw new FileNotFoundException($"MSH file not found: {path}");

        using var reader = new StreamReader(path);
        return ParseMSHWithTags(reader);
    }

    private static (SimplexMesh Mesh, double[,] Coordinates) ParseMSH(StreamReader reader)
    {
        var (mesh, coords, _, _, _, _, _) = ParseMSHWithTags(reader);
        return (mesh, coords);
    }

    private static (SimplexMesh Mesh, double[,] Coordinates,
        Dictionary<int, (int Dimension, string Name)> PhysicalNames,
        int[] PointTags, int[] BarTags, int[] TriTags, int[] TetTags) ParseMSHWithTags(StreamReader reader)
    {
        var physicalNames = new Dictionary<int, (int Dimension, string Name)>();
        double[,]? coordinates = null;
        var elements = new List<(int ElemType, int PhysTag, int[] Nodes)>();

        string? line;
        while ((line = reader.ReadLine()) != null)
        {
            line = line.Trim();
            
            if (line == "$MeshFormat")
            {
                line = reader.ReadLine()?.Trim();
                if (line != null)
                {
                    var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    double version = double.Parse(parts[0], CultureInfo.InvariantCulture);
                    if (version < 2.0 || version >= 3.0)
                        Console.WriteLine($"Warning: Expected Gmsh 2.x format, got {version}");
                }
                SkipToEndSection(reader, "$EndMeshFormat");
            }
            else if (line == "$PhysicalNames")
            {
                line = reader.ReadLine()?.Trim();
                int numNames = int.Parse(line!, CultureInfo.InvariantCulture);
                for (int i = 0; i < numNames; i++)
                {
                    line = reader.ReadLine()?.Trim();
                    if (line == null) break;
                    var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    int dim = int.Parse(parts[0], CultureInfo.InvariantCulture);
                    int id = int.Parse(parts[1], CultureInfo.InvariantCulture);
                    string name = parts[2].Trim('"');
                    physicalNames[id] = (dim, name);
                }
                SkipToEndSection(reader, "$EndPhysicalNames");
            }
            else if (line == "$Nodes")
            {
                line = reader.ReadLine()?.Trim();
                int nodeCount = int.Parse(line!, CultureInfo.InvariantCulture);
                coordinates = new double[nodeCount, 3];
                
                for (int i = 0; i < nodeCount; i++)
                {
                    line = reader.ReadLine()?.Trim();
                    if (line == null) break;
                    var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    int nodeId = int.Parse(parts[0], CultureInfo.InvariantCulture) - 1; // 0-based
                    coordinates[nodeId, 0] = double.Parse(parts[1], CultureInfo.InvariantCulture);
                    coordinates[nodeId, 1] = double.Parse(parts[2], CultureInfo.InvariantCulture);
                    coordinates[nodeId, 2] = double.Parse(parts[3], CultureInfo.InvariantCulture);
                }
                SkipToEndSection(reader, "$EndNodes");
            }
            else if (line == "$Elements")
            {
                line = reader.ReadLine()?.Trim();
                int numElements = int.Parse(line!, CultureInfo.InvariantCulture);
                
                for (int i = 0; i < numElements; i++)
                {
                    line = reader.ReadLine()?.Trim();
                    if (line == null) break;
                    var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    // Format: elem-id type num-tags [tags...] node1 node2 ...
                    int elemType = int.Parse(parts[1], CultureInfo.InvariantCulture);
                    int numTags = int.Parse(parts[2], CultureInfo.InvariantCulture);
                    int physTag = numTags > 0 ? int.Parse(parts[3], CultureInfo.InvariantCulture) : 0;
                    
                    int nodeStart = 3 + numTags;
                    var nodes = new int[parts.Length - nodeStart];
                    for (int j = 0; j < nodes.Length; j++)
                        nodes[j] = int.Parse(parts[nodeStart + j], CultureInfo.InvariantCulture) - 1; // 0-based
                    
                    elements.Add((elemType, physTag, nodes));
                }
                SkipToEndSection(reader, "$EndElements");
            }
            else if (line.StartsWith("$"))
            {
                // Skip unknown sections
                string endMarker = "$End" + line.Substring(1);
                SkipToEndSection(reader, endMarker);
            }
        }

        if (coordinates == null)
            throw new FormatException("MSH file missing $Nodes section");

        // Build mesh and collect tags by element type
        // Gmsh types: 15=point, 1=line, 2=triangle, 4=tetrahedron
        var pointList = new List<(int PhysTag, int[] Nodes)>();
        var barList = new List<(int PhysTag, int[] Nodes)>();
        var triList = new List<(int PhysTag, int[] Nodes)>();
        var tetList = new List<(int PhysTag, int[] Nodes)>();

        foreach (var (elemType, physTag, nodes) in elements)
        {
            switch (elemType)
            {
                case 15: // Point
                    pointList.Add((physTag, nodes));
                    break;
                case 1: // 2-node line
                case 8: // 3-node line (quadratic) - treat as linear
                    barList.Add((physTag, new[] { nodes[0], nodes[1] }));
                    break;
                case 2: // 3-node triangle
                case 9: // 6-node triangle (quadratic) - treat as linear
                    triList.Add((physTag, new[] { nodes[0], nodes[1], nodes[2] }));
                    break;
                case 4: // 4-node tetrahedron
                case 11: // 10-node tetrahedron (quadratic) - treat as linear
                    tetList.Add((physTag, new[] { nodes[0], nodes[1], nodes[2], nodes[3] }));
                    break;
            }
        }

        var mesh = new SimplexMesh();
        int numNodes = coordinates.GetLength(0);

        mesh.WithBatch(() =>
        {
            for (int i = 0; i < numNodes; i++)
            {
                mesh.Add<Node>();
                mesh.Set<Node, ParentNodes>(i, new ParentNodes(i, i));
            }

            foreach (var (_, nodes) in pointList)
            {
                int pi = mesh.Add<Point, Node>(nodes[0]);
                mesh.Set<Point, OriginalElement>(pi, new OriginalElement(pi));
            }
            foreach (var (_, nodes) in barList)
            {
                int bi = mesh.Add<Bar2, Node>(nodes[0], nodes[1]);
                mesh.Set<Bar2, OriginalElement>(bi, new OriginalElement(bi));
            }
            foreach (var (_, nodes) in triList)
            {
                int ti = mesh.Add<Tri3, Node>(nodes[0], nodes[1], nodes[2]);
                mesh.Set<Tri3, OriginalElement>(ti, new OriginalElement(ti));
            }
            foreach (var (_, nodes) in tetList)
            {
                int ei = mesh.Add<Tet4, Node>(nodes[0], nodes[1], nodes[2], nodes[3]);
                mesh.Set<Tet4, OriginalElement>(ei, new OriginalElement(ei));
            }
        });

        return (mesh, coordinates, physicalNames,
            pointList.Select(x => x.PhysTag).ToArray(),
            barList.Select(x => x.PhysTag).ToArray(),
            triList.Select(x => x.PhysTag).ToArray(),
            tetList.Select(x => x.PhysTag).ToArray());
    }

    private static void SkipToEndSection(StreamReader reader, string endMarker)
    {
        string? line;
        while ((line = reader.ReadLine()) != null)
        {
            if (line.Trim() == endMarker) break;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // GiD/CIMNE Mesh I/O
    // ═══════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Loads a SimplexMesh from a GiD/CIMNE mesh file (.msh).
    /// </summary>
    /// <param name="path">Path to the .msh file</param>
    /// <returns>Loaded mesh and coordinates</returns>
    public static (SimplexMesh Mesh, double[,] Coordinates) LoadGiD(string path)
    {
        ArgumentNullException.ThrowIfNull(path);
        if (!File.Exists(path))
            throw new FileNotFoundException($"GiD mesh file not found: {path}");

        using var reader = new StreamReader(path);
        return ParseGiD(reader);
    }

    /// <summary>
    /// Loads a SimplexMesh from a GiD/CIMNE mesh file, also returning material IDs.
    /// </summary>
    /// <param name="path">Path to the .msh file</param>
    /// <returns>Loaded mesh, coordinates, and material IDs for each element type</returns>
    public static (SimplexMesh Mesh, double[,] Coordinates,
        int[] PointMaterials, int[] BarMaterials, int[] TriMaterials, int[] TetMaterials) LoadGiDWithMaterials(string path)
    {
        ArgumentNullException.ThrowIfNull(path);
        if (!File.Exists(path))
            throw new FileNotFoundException($"GiD mesh file not found: {path}");

        using var reader = new StreamReader(path);
        return ParseGiDWithMaterials(reader);
    }

    private static (SimplexMesh Mesh, double[,] Coordinates) ParseGiD(StreamReader reader)
    {
        var (mesh, coords, _, _, _, _) = ParseGiDWithMaterials(reader);
        return (mesh, coords);
    }

    private static (SimplexMesh Mesh, double[,] Coordinates,
        int[] PointMaterials, int[] BarMaterials, int[] TriMaterials, int[] TetMaterials) ParseGiDWithMaterials(StreamReader reader)
    {
        var nodeCoords = new Dictionary<int, (double X, double Y, double Z)>();
        var pointList = new List<(int Material, int[] Nodes)>();
        var barList = new List<(int Material, int[] Nodes)>();
        var triList = new List<(int Material, int[] Nodes)>();
        var tetList = new List<(int Material, int[] Nodes)>();

        int dimension = 3;
        string currentElemType = "";
        int currentNnode = 0;
        bool inCoordinates = false;
        bool inElements = false;

        string? line;
        while ((line = reader.ReadLine()) != null)
        {
            line = line.Trim();
            if (string.IsNullOrEmpty(line) || line.StartsWith("#")) continue;

            var upperLine = line.ToUpperInvariant();

            // Parse MESH header: MESH dimension D ElemType TypeName Nnode N
            if (upperLine.StartsWith("MESH"))
            {
                var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < parts.Length - 1; i++)
                {
                    var key = parts[i].ToUpperInvariant();
                    if (key == "DIMENSION" && i + 1 < parts.Length)
                        dimension = int.Parse(parts[i + 1], CultureInfo.InvariantCulture);
                    else if (key == "ELEMTYPE" && i + 1 < parts.Length)
                        currentElemType = parts[i + 1].ToUpperInvariant();
                    else if (key == "NNODE" && i + 1 < parts.Length)
                        currentNnode = int.Parse(parts[i + 1], CultureInfo.InvariantCulture);
                }
                continue;
            }

            if (upperLine == "COORDINATES")
            {
                inCoordinates = true;
                inElements = false;
                continue;
            }
            if (upperLine == "END COORDINATES")
            {
                inCoordinates = false;
                continue;
            }
            if (upperLine == "ELEMENTS")
            {
                inElements = true;
                inCoordinates = false;
                continue;
            }
            if (upperLine == "END ELEMENTS")
            {
                inElements = false;
                continue;
            }

            if (inCoordinates)
            {
                var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length >= 3)
                {
                    int nodeId = int.Parse(parts[0], CultureInfo.InvariantCulture);
                    double x = double.Parse(parts[1], CultureInfo.InvariantCulture);
                    double y = double.Parse(parts[2], CultureInfo.InvariantCulture);
                    double z = parts.Length > 3 ? double.Parse(parts[3], CultureInfo.InvariantCulture) : 0.0;
                    nodeCoords[nodeId] = (x, y, z);
                }
            }
            else if (inElements)
            {
                var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length < 2) continue;

                // Format: elem-id node1 node2 ... [material]
                // Node count determined by currentNnode or element type
                int nNodes = currentNnode > 0 ? currentNnode : GuessNodeCount(currentElemType);
                if (parts.Length < 1 + nNodes) continue;

                var nodes = new int[nNodes];
                for (int j = 0; j < nNodes; j++)
                    nodes[j] = int.Parse(parts[1 + j], CultureInfo.InvariantCulture);
                
                // Material is the last column (optional)
                int material = parts.Length > 1 + nNodes 
                    ? int.Parse(parts[1 + nNodes], CultureInfo.InvariantCulture) 
                    : 0;

                // Classify by element type
                switch (currentElemType)
                {
                    case "POINT":
                        pointList.Add((material, nodes));
                        break;
                    case "LINEAR":
                    case "LINE":
                        barList.Add((material, new[] { nodes[0], nodes[1] }));
                        break;
                    case "TRIANGLE":
                        triList.Add((material, new[] { nodes[0], nodes[1], nodes[2] }));
                        break;
                    case "TETRAHEDRA":
                    case "TETRAHEDRON":
                        tetList.Add((material, new[] { nodes[0], nodes[1], nodes[2], nodes[3] }));
                        break;
                    default:
                        // Guess from node count
                        if (nNodes == 1) pointList.Add((material, nodes));
                        else if (nNodes == 2) barList.Add((material, nodes));
                        else if (nNodes == 3) triList.Add((material, nodes));
                        else if (nNodes == 4) tetList.Add((material, nodes));
                        break;
                }
            }
        }

        if (nodeCoords.Count == 0)
            throw new FormatException("GiD mesh file has no coordinates");

        // Build node array (GiD uses 1-based, need to map to 0-based)
        int maxNodeId = nodeCoords.Keys.Max();
        int minNodeId = nodeCoords.Keys.Min();
        bool isOneBased = minNodeId == 1;
        
        int numNodes = nodeCoords.Count;
        var coordinates = new double[numNodes, 3];
        var nodeIdMap = new Dictionary<int, int>(); // old id -> new 0-based id

        int idx = 0;
        foreach (var nodeId in nodeCoords.Keys.OrderBy(x => x))
        {
            var (x, y, z) = nodeCoords[nodeId];
            coordinates[idx, 0] = x;
            coordinates[idx, 1] = y;
            coordinates[idx, 2] = z;
            nodeIdMap[nodeId] = idx;
            idx++;
        }

        // Remap element node IDs
        void RemapNodes(int[] nodes)
        {
            for (int i = 0; i < nodes.Length; i++)
                nodes[i] = nodeIdMap[nodes[i]];
        }

        foreach (var (_, nodes) in pointList) RemapNodes(nodes);
        foreach (var (_, nodes) in barList) RemapNodes(nodes);
        foreach (var (_, nodes) in triList) RemapNodes(nodes);
        foreach (var (_, nodes) in tetList) RemapNodes(nodes);

        // Build mesh
        var mesh = new SimplexMesh();
        mesh.WithBatch(() =>
        {
            for (int i = 0; i < numNodes; i++)
            {
                mesh.Add<Node>();
                mesh.Set<Node, ParentNodes>(i, new ParentNodes(i, i));
            }

            foreach (var (_, nodes) in pointList)
            {
                int pi = mesh.Add<Point, Node>(nodes[0]);
                mesh.Set<Point, OriginalElement>(pi, new OriginalElement(pi));
            }
            foreach (var (_, nodes) in barList)
            {
                int bi = mesh.Add<Bar2, Node>(nodes[0], nodes[1]);
                mesh.Set<Bar2, OriginalElement>(bi, new OriginalElement(bi));
            }
            foreach (var (_, nodes) in triList)
            {
                int ti = mesh.Add<Tri3, Node>(nodes[0], nodes[1], nodes[2]);
                mesh.Set<Tri3, OriginalElement>(ti, new OriginalElement(ti));
            }
            foreach (var (_, nodes) in tetList)
            {
                int ei = mesh.Add<Tet4, Node>(nodes[0], nodes[1], nodes[2], nodes[3]);
                mesh.Set<Tet4, OriginalElement>(ei, new OriginalElement(ei));
            }
        });

        return (mesh, coordinates,
            pointList.Select(x => x.Material).ToArray(),
            barList.Select(x => x.Material).ToArray(),
            triList.Select(x => x.Material).ToArray(),
            tetList.Select(x => x.Material).ToArray());
    }

    private static int GuessNodeCount(string elemType) => elemType switch
    {
        "POINT" => 1,
        "LINEAR" or "LINE" => 2,
        "TRIANGLE" => 3,
        "QUADRILATERAL" => 4,
        "TETRAHEDRA" or "TETRAHEDRON" => 4,
        "HEXAHEDRA" or "HEXAHEDRON" => 8,
        "PRISM" => 6,
        "PYRAMID" => 5,
        _ => 0
    };

    /// <summary>
    /// Saves a SimplexMesh to GiD/CIMNE mesh format (.msh).
    /// </summary>
    /// <param name="mesh">Mesh to save</param>
    /// <param name="coordinates">Node coordinates</param>
    /// <param name="path">Output file path</param>
    public static void SaveGiD(SimplexMesh mesh, double[,] coordinates, string path)
    {
        SaveGiD(mesh, coordinates, path, null, null, null, null, null);
    }

    /// <summary>
    /// Saves a SimplexMesh to GiD/CIMNE mesh format (.msh) with material IDs.
    /// GUARANTEES continuous node and element numbering with no gaps.
    /// </summary>
    /// <param name="mesh">Mesh to save</param>
    /// <param name="coordinates">Node coordinates</param>
    /// <param name="path">Output file path</param>
    /// <param name="pointMaterials">Optional material IDs for Point elements</param>
    /// <param name="barMaterials">Optional material IDs for Bar2 elements</param>
    /// <param name="triMaterials">Optional material IDs for Tri3 elements</param>
    /// <param name="tetMaterials">Optional material IDs for Tet4 elements</param>
    /// <param name="meshName">Optional mesh name for GiD header</param>
    public static void SaveGiD(SimplexMesh mesh, double[,] coordinates, string path,
        int[]? pointMaterials,
        int[]? barMaterials,
        int[]? triMaterials,
        int[]? quadMaterials,
        int[]? tetMaterials,
        string? meshName = null)
    {
        ArgumentNullException.ThrowIfNull(mesh);
        ArgumentNullException.ThrowIfNull(coordinates);
        ArgumentNullException.ThrowIfNull(path);

        int numPoints = mesh.Count<Point>();
        int numBars = mesh.Count<Bar2>();
        int numTris = mesh.Count<Tri3>();
        int numQuads = mesh.Count<Quad4>();
        int numTets = mesh.Count<Tet4>();
        int numElements = numPoints + numBars + numTris + numQuads + numTets;

        // Validate material array lengths
        if (pointMaterials != null && pointMaterials.Length != numPoints)
            throw new ArgumentException($"pointMaterials length ({pointMaterials.Length}) must match Point count ({numPoints})");
        if (barMaterials != null && barMaterials.Length != numBars)
            throw new ArgumentException($"barMaterials length ({barMaterials.Length}) must match Bar2 count ({numBars})");
        if (triMaterials != null && triMaterials.Length != numTris)
            throw new ArgumentException($"triMaterials length ({triMaterials.Length}) must match Tri3 count ({numTris})");
        if (quadMaterials != null && quadMaterials.Length != numQuads)
            throw new ArgumentException($"quadMaterials length ({quadMaterials.Length}) must match Quad4 count ({numQuads})");
        if (tetMaterials != null && tetMaterials.Length != numTets)
            throw new ArgumentException($"tetMaterials length ({tetMaterials.Length}) must match Tet4 count ({numTets})");

        // STEP 1: Collect all active nodes (nodes referenced by elements)
        var activeNodes = new HashSet<int>();
        
        for (int i = 0; i < numPoints; i++)
        {
            var n = mesh.NodesOf<Point, Node>(i);
            activeNodes.Add(n[0]);
        }
        
        for (int i = 0; i < numBars; i++)
        {
            var n = mesh.NodesOf<Bar2, Node>(i);
            activeNodes.Add(n[0]);
            activeNodes.Add(n[1]);
        }
        
        for (int i = 0; i < numTris; i++)
        {
            var n = mesh.NodesOf<Tri3, Node>(i);
            activeNodes.Add(n[0]);
            activeNodes.Add(n[1]);
            activeNodes.Add(n[2]);
        }
        
        for (int i = 0; i < numQuads; i++)
        {
            var n = mesh.NodesOf<Quad4, Node>(i);
            activeNodes.Add(n[0]);
            activeNodes.Add(n[1]);
            activeNodes.Add(n[2]);
            activeNodes.Add(n[3]);
        }
        
        for (int i = 0; i < numTets; i++)
        {
            var n = mesh.NodesOf<Tet4, Node>(i);
            activeNodes.Add(n[0]);
            activeNodes.Add(n[1]);
            activeNodes.Add(n[2]);
            activeNodes.Add(n[3]);
        }
        
        // STEP 2: Create continuous node numbering: oldID -> newID (1, 2, 3, ...)
        var nodeMap = new Dictionary<int, int>();
        var sortedNodes = activeNodes.OrderBy(n => n).ToArray();
        
        for (int i = 0; i < sortedNodes.Length; i++)
        {
            nodeMap[sortedNodes[i]] = i + 1;  // GiD uses 1-based indexing
        }
        
        int numActiveNodes = sortedNodes.Length;
        
        Console.WriteLine($"[SaveGiD] Mesh has {mesh.Count<Node>()} node IDs, {numActiveNodes} active nodes");
        if (numActiveNodes < mesh.Count<Node>())
        {
            Console.WriteLine($"[SaveGiD] Removed {mesh.Count<Node>() - numActiveNodes} unused nodes (gaps eliminated)");
        }

        // Determine mesh dimension
        int dimension = numTets > 0 ? 3 : (numTris > 0 ? 2 : 1);

        // Ensure path has .msh extension
        if (!path.EndsWith(".msh", StringComparison.OrdinalIgnoreCase))
        {
            path = path + ".msh";
        }

        using var writer = new StreamWriter(path);
        
        // Write mesh information header
        writer.WriteLine("# GiD/CIMNE Mesh File");
        writer.WriteLine($"# Generated by SimplexRemesher with continuous numbering");
        if (!string.IsNullOrEmpty(meshName))
            writer.WriteLine($"# Mesh name: {meshName}");
        writer.WriteLine($"# Dimension: {dimension}");
        writer.WriteLine($"# Nodes: {numActiveNodes} (continuous 1-based)");
        writer.WriteLine($"# Elements: {numElements} total");
        writer.WriteLine("#   Tets: {0}, Quads: {1}, Tris: {2}, Bars: {3}, Points: {4}",
            numTets, numQuads, numTris, numBars, numPoints);
        writer.WriteLine();
        
        int currentElementId = 1; // Track continuous element numbering across types

        // Write bulk elements first (highest dimension), then lower-dimensional
        // GiD groups elements by type in separate MESH blocks
        // Each MESH block MUST have its own Coordinates section

        // Tetrahedra
        if (numTets > 0)
        {
            writer.WriteLine($"MESH dimension {dimension} ElemType Tetrahedra Nnode 4");
            WriteGiDCoordinatesWithMapping(writer, coordinates, sortedNodes, dimension);
            writer.WriteLine("Elements");
            for (int i = 0; i < numTets; i++)
            {
                var n = mesh.NodesOf<Tet4, Node>(i);
                int mat = tetMaterials?[i] ?? 0;
                writer.WriteLine(string.Format(CultureInfo.InvariantCulture,
                    "  {0}  {1}  {2}  {3}  {4}  {5}", 
                    currentElementId++,  // Continuous numbering
                    nodeMap[n[0]], nodeMap[n[1]], nodeMap[n[2]], nodeMap[n[3]], 
                    mat));
            }
            writer.WriteLine("End Elements");
            writer.WriteLine();
        }

        // Quadrilaterals
        if (numQuads > 0)
        {
            writer.WriteLine($"MESH dimension {dimension} ElemType Quadrilateral Nnode 4");
            WriteGiDCoordinatesWithMapping(writer, coordinates, sortedNodes, dimension);
            writer.WriteLine("Elements");
            for (int i = 0; i < numQuads; i++)
            {
                var n = mesh.NodesOf<Quad4, Node>(i);
                int mat = quadMaterials?[i] ?? 0;
                writer.WriteLine(string.Format(CultureInfo.InvariantCulture,
                    "  {0}  {1}  {2}  {3}  {4}  {5}", 
                    currentElementId++,  // Continuous numbering
                    nodeMap[n[0]], nodeMap[n[1]], nodeMap[n[2]], nodeMap[n[3]], 
                    mat));
            }
            writer.WriteLine("End Elements");
            writer.WriteLine();
        }

        // Triangles
        if (numTris > 0)
        {
            writer.WriteLine($"MESH dimension {dimension} ElemType Triangle Nnode 3");
            WriteGiDCoordinatesWithMapping(writer, coordinates, sortedNodes, dimension);
            writer.WriteLine("Elements");
            for (int i = 0; i < numTris; i++)
            {
                var n = mesh.NodesOf<Tri3, Node>(i);
                int mat = triMaterials?[i] ?? 0;
                writer.WriteLine(string.Format(CultureInfo.InvariantCulture,
                    "  {0}  {1}  {2}  {3}  {4}", 
                    currentElementId++,  // Continuous numbering
                    nodeMap[n[0]], nodeMap[n[1]], nodeMap[n[2]], 
                    mat));
            }
            writer.WriteLine("End Elements");
            writer.WriteLine();
        }

        // Lines/Bars
        if (numBars > 0)
        {
            writer.WriteLine($"MESH dimension {dimension} ElemType Linear Nnode 2");
            WriteGiDCoordinatesWithMapping(writer, coordinates, sortedNodes, dimension);
            writer.WriteLine("Elements");
            for (int i = 0; i < numBars; i++)
            {
                var n = mesh.NodesOf<Bar2, Node>(i);
                int mat = barMaterials?[i] ?? 0;
                writer.WriteLine(string.Format(CultureInfo.InvariantCulture,
                    "  {0}  {1}  {2}  {3}", 
                    currentElementId++,  // Continuous numbering
                    nodeMap[n[0]], nodeMap[n[1]], 
                    mat));
            }
            writer.WriteLine("End Elements");
            writer.WriteLine();
        }

        // Points
        if (numPoints > 0)
        {
            writer.WriteLine($"MESH dimension {dimension} ElemType Point Nnode 1");
            WriteGiDCoordinatesWithMapping(writer, coordinates, sortedNodes, dimension);
            writer.WriteLine("Elements");
            for (int i = 0; i < numPoints; i++)
            {
                var n = mesh.NodesOf<Point, Node>(i);
                int mat = pointMaterials?[i] ?? 0;
                writer.WriteLine(string.Format(CultureInfo.InvariantCulture,
                    "  {0}  {1}  {2}", 
                    currentElementId++,  // Continuous numbering
                    nodeMap[n[0]], 
                    mat));
            }
            writer.WriteLine("End Elements");
            writer.WriteLine();
        }
        
        Console.WriteLine($"[SaveGiD] ✓ Saved to {path} with continuous numbering (no gaps)");
    }

    private static void WriteGiDCoordinatesWithMapping(StreamWriter writer, double[,] coordinates, int[] sortedNodes, int dimension)
    {
        writer.WriteLine("Coordinates");
        for (int i = 0; i < sortedNodes.Length; i++)
        {
            int oldNodeId = sortedNodes[i];
            int newNodeId = i + 1;  // GiD uses 1-based indexing
            
            if (dimension == 2)
                writer.WriteLine(string.Format(CultureInfo.InvariantCulture,
                    "  {0}  {1}  {2}", newNodeId, coordinates[oldNodeId, 0], coordinates[oldNodeId, 1]));
            else
                writer.WriteLine(string.Format(CultureInfo.InvariantCulture,
                    "  {0}  {1}  {2}  {3}", newNodeId, coordinates[oldNodeId, 0], coordinates[oldNodeId, 1], coordinates[oldNodeId, 2]));
        }
        writer.WriteLine("End Coordinates");
        writer.WriteLine();
    }
    
    // ========================================================================
    // SIGNED FIELD CRACK INSERTION
    // ========================================================================
    
    /// <summary>
    /// Signed field function delegate for level set crack insertion.
    /// Returns: positive on one side, negative on other side, zero on crack.
    /// </summary>
    /// <example>
    /// SINGLE LEVEL SET EXAMPLES:
    /// Horizontal crack at y=0.5: (x,y,z) => y - 0.5
    /// Circular crack: (x,y,z) => Math.Sqrt((x-cx)^2 + (y-cy)^2) - radius
    /// Planar 3D crack: (x,y,z) => z - 0.5
    /// 
    /// TWO LEVEL SET EXAMPLES:
    /// Level set 1 defines crack surface, level set 2 defines active region.
    /// Crack forms where surface crosses zero AND region is ≤ 0.
    /// 
    /// 2D horizontal crack from x=0.2 to x=1.5:
    ///   crackSurface = (x,y,z) => y - 0.5
    ///   activeRegion = (x,y,z) => (x < 0.2) ? (x - 0.2) : (x > 1.5) ? (x - 1.5) : -0.1
    /// 
    /// 3D circular crack (plane z=0.5, radius 0.3 at center):
    ///   crackSurface = (x,y,z) => z - 0.5
    ///   activeRegion = (x,y,z) => Math.Sqrt((x-0.5)^2 + (y-0.5)^2) - 0.3
    /// </example>
    public delegate double SignedFieldFunction(double x, double y, double z);
    
    /// <summary>
    /// Create crack in mesh using signed field (level set method).
    /// 
    /// Algorithm:
    /// 1. Find edges where field changes sign
    /// 2. Refine those edges, positioning new nodes at exact zero-crossing
    /// 3. Classify original nodes by field sign (positive/negative)
    /// 4. Duplicate all crack nodes except tips
    /// 5. Elements with all positive original nodes use duplicates
    /// 
    /// Works for all crack types:
    /// - Boundary-to-boundary
    /// - Edge-to-interior (with singular tip)
    /// - Closed loops
    /// - Any shape defined by implicit function
    /// </summary>
    /// <param name="mesh">Input mesh</param>
    /// <param name="coordinates">Node coordinates</param>
    /// <param name="signedField">Signed distance/level set function (defines crack surface)</param>
    /// <param name="regionField">Optional second level set to define crack active region (crack exists where regionField ≤ 0). If null, crack extends along entire zero level set.</param>
    /// <param name="enableSmoothing">Enable CVT smoothing after refinement (disable for multi-crack patterns)</param>
    /// <returns>Cracked mesh and coordinates</returns>
    
    /// <summary>
    /// Helper to safely get z-coordinate from 2D or 3D coordinate array
    /// </summary>
    private static double GetZ(double[,] coords, int nodeId)
    {
        return coords.GetLength(1) == 3 ? coords[nodeId, 2] : 0.0;
    }
    
    public static (SimplexMesh, double[,]) CreateCrackFromSignedField(
        SimplexMesh mesh,
        double[,] coordinates,
        SignedFieldFunction signedField,
        SignedFieldFunction? regionField = null,
        bool enableMeshPerturbation = false,
        bool enableSmoothing = false,
        double visualizationOffset = 0.0)
    {
        int originalNodeCount = mesh.Count<Node>();
        int coordDim = coordinates.GetLength(1);  // 2 for 2D, 3 for 3D
        
        // Clone coordinates to avoid modifying input
        coordinates = (double[,])coordinates.Clone();
        
        // OPTIONAL: MESH PERTURBATION to avoid exact zeros in signed field
        if (enableMeshPerturbation)
        {
            Console.WriteLine($"  → Applying mesh perturbation...");
            
            // Calculate average edge length
            DiscoverEdges(mesh);
            double avgEdgeLength = 0.0;
            int numEdges = 0;
            for (int i = 0; i < mesh.Count<Edge>(); i++)
            {
                var nodes = mesh.NodesOf<Edge, Node>(i);
                int n1 = nodes[0], n2 = nodes[1];
                double dx = coordinates[n2, 0] - coordinates[n1, 0];
                double dy = coordinates[n2, 1] - coordinates[n1, 1];
                double dz = coordDim == 3 ? coordinates[n2, 2] - coordinates[n1, 2] : 0.0;
                avgEdgeLength += Math.Sqrt(dx * dx + dy * dy + dz * dz);
                numEdges++;
            }
            avgEdgeLength /= numEdges;
            
            // Perturb each node by a tiny random amount (1e-6 * avgEdgeLength)
            double perturbationScale = 1e-6 * avgEdgeLength;
            var random = new Random(12345);  // Fixed seed for reproducibility
            
            for (int i = 0; i < mesh.Count<Node>(); i++)
            {
                coordinates[i, 0] += (random.NextDouble() * 2.0 - 1.0) * perturbationScale;
                coordinates[i, 1] += (random.NextDouble() * 2.0 - 1.0) * perturbationScale;
                if (coordDim == 3)
                    coordinates[i, 2] += (random.NextDouble() * 2.0 - 1.0) * perturbationScale;
            }
            
            Console.WriteLine($"  → Mesh perturbed by ±{perturbationScale:E3}");
        }
        else
        {
            DiscoverEdges(mesh);
        }
        
        // Step 1: Find ALL edges that cross the signed field
        var edgesToRefine = new List<(int, int)>();
        
        Console.WriteLine($"  → Total edges in mesh: {mesh.Count<Edge>()}");
        
        int crossingEdges = 0;
        int regionFiltered = 0;
        
        for (int i = 0; i < mesh.Count<Edge>(); i++)
        {
            var nodes = mesh.NodesOf<Edge, Node>(i);
            int n1 = nodes[0], n2 = nodes[1];
            
            double f1 = signedField(coordinates[n1, 0], coordinates[n1, 1], GetZ(coordinates, n1));
            double f2 = signedField(coordinates[n2, 0], coordinates[n2, 1], GetZ(coordinates, n2));
            
            // Check if crack surface crosses this edge (sign change)
            // With perturbation, f1*f2 == 0 should be extremely rare
            bool crossesCrack = f1 * f2 < 0;
            
            if (crossesCrack)
            {
                crossingEdges++;
                
                // If region field is provided, check if edge is in active region
                if (regionField != null)
                {
                    double r1 = regionField(coordinates[n1, 0], coordinates[n1, 1], GetZ(coordinates, n1));
                    double r2 = regionField(coordinates[n2, 0], coordinates[n2, 1], GetZ(coordinates, n2));
                    
                    // Check if crossing point is in active region
                    // Approximate crossing point using linear interpolation
                    double t = Math.Abs(f2 - f1) > 1e-14 ? -f1 / (f2 - f1) : 0.5;
                    t = Math.Max(0.0, Math.Min(1.0, t));
                    
                    double xCross = coordinates[n1, 0] + t * (coordinates[n2, 0] - coordinates[n1, 0]);
                    double yCross = coordinates[n1, 1] + t * (coordinates[n2, 1] - coordinates[n1, 1]);
                    double zCross = GetZ(coordinates, n1) + t * (GetZ(coordinates, n2) - GetZ(coordinates, n1));
                    double rCross = regionField(xCross, yCross, zCross);
                    
                    // Only refine edge if crossing point is in active region (r ≤ 0)
                    if (rCross <= 0)
                    {
                        edgesToRefine.Add((n1, n2));
                    }
                    else
                    {
                        regionFiltered++;
                    }
                }
                else
                {
                    // No region constraint - refine all crossing edges
                    edgesToRefine.Add((n1, n2));
                }
            }
        }
        
        Console.WriteLine($"  → Edges with sign change: {crossingEdges}");
        Console.WriteLine($"  → Filtered by region: {regionFiltered}");
        Console.WriteLine($"  → Edges to refine: {edgesToRefine.Count}");
        
        if (edgesToRefine.Count == 0)
        {
            Console.WriteLine($"  ⚠️  No edges cross the crack surface in active region");
            return (mesh, coordinates);
        }
        
        Console.WriteLine($"  → Refining {edgesToRefine.Count} edges that cross crack");
        
        // Step 2: Refine those edges once
        var refinedMesh = mesh;
        var refinedCoords = coordinates;
        
        for (int pass = 0; pass < 1; pass++)  // Single pass per crack
        {
            // Cache signed field values for all nodes (avoid recomputation)
            var cachedFieldValues = new double[refinedMesh.Count<Node>()];
            var cachedRegionValues = new double[refinedMesh.Count<Node>()];
            
            for (int i = 0; i < refinedMesh.Count<Node>(); i++)
            {
                cachedFieldValues[i] = signedField(refinedCoords[i, 0], refinedCoords[i, 1], GetZ(refinedCoords, i));
                if (regionField != null)
                    cachedRegionValues[i] = regionField(refinedCoords[i, 0], refinedCoords[i, 1], GetZ(refinedCoords, i));
            }
            
            // Find edges to refine in current mesh
            var currentEdgesToRefine = new HashSet<(int, int)>();
            
            for (int i = 0; i < refinedMesh.Count<Tri3>(); i++)
            {
                var n = refinedMesh.NodesOf<Tri3, Node>(i);
                int n1 = n[0], n2 = n[1], n3 = n[2];
                
                double f1 = cachedFieldValues[n1];
                double f2 = cachedFieldValues[n2];
                double f3 = cachedFieldValues[n3];
                
                // Check region constraint
                bool checkRegion = (regionField != null);
                bool refineEdge12 = false, refineEdge23 = false, refineEdge31 = false;
                
                if (f1 * f2 <= 0)
                {
                    if (checkRegion)
                    {
                        double r1 = cachedRegionValues[n1];
                        double r2 = cachedRegionValues[n2];
                        refineEdge12 = (r1 <= 0 || r2 <= 0);
                    }
                    else refineEdge12 = true;
                }
                
                if (f2 * f3 <= 0)
                {
                    if (checkRegion)
                    {
                        double r2 = cachedRegionValues[n2];
                        double r3 = cachedRegionValues[n3];
                        refineEdge23 = (r2 <= 0 || r3 <= 0);
                    }
                    else refineEdge23 = true;
                }
                
                if (f3 * f1 <= 0)
                {
                    if (checkRegion)
                    {
                        double r3 = cachedRegionValues[n3];
                        double r1 = cachedRegionValues[n1];
                        refineEdge31 = (r3 <= 0 || r1 <= 0);
                    }
                    else refineEdge31 = true;
                }
                
                if (refineEdge12) currentEdgesToRefine.Add(n1 < n2 ? (n1, n2) : (n2, n1));
                if (refineEdge23) currentEdgesToRefine.Add(n2 < n3 ? (n2, n3) : (n3, n2));
                if (refineEdge31) currentEdgesToRefine.Add(n1 < n3 ? (n1, n3) : (n3, n1));
            }
            
            if (currentEdgesToRefine.Count == 0)
            {
                Console.WriteLine($"  → Pass {pass + 1}: No more edges to refine");
                break;
            }
            
            Console.WriteLine($"  → Pass {pass + 1}: Refining {currentEdgesToRefine.Count} edges");
            (refinedMesh, _) = MeshRefinement.Refine(refinedMesh, currentEdgesToRefine.ToList());
            refinedCoords = MeshRefinement.InterpolateCoordinates(refinedMesh, refinedCoords);
        }
        
        // Step 3: Snap new crack nodes to EXACT zero-crossing (surface = 0)
        int snappedCount = 0;
        double maxSnapError = 0.0;
        
        for (int i = originalNodeCount; i < refinedMesh.Count<Node>(); i++)
        {
            var parents = refinedMesh.Get<Node, ParentNodes>(i);
            
            if (parents.Parent1 != parents.Parent2)
            {
                int p1 = parents.Parent1, p2 = parents.Parent2;
                
                double x1 = refinedCoords[p1, 0], y1 = refinedCoords[p1, 1], z1 = GetZ(refinedCoords, p1);
                double x2 = refinedCoords[p2, 0], y2 = refinedCoords[p2, 1], z2 = GetZ(refinedCoords, p2);
                
                double f1 = signedField(x1, y1, z1);
                double f2 = signedField(x2, y2, z2);
                
                // Snap to zero-crossing if edge crosses crack
                if (Math.Abs(f2 - f1) > 1e-10 && f1 * f2 <= 0)
                {
                    // Use bisection for nonlinear fields (more robust than linear interpolation)
                    double tMin = 0.0, tMax = 1.0;
                    double t = 0.5;
                    
                    for (int iter = 0; iter < 20; iter++)
                    {
                        t = (tMin + tMax) / 2.0;
                        double xm = x1 + t * (x2 - x1);
                        double ym = y1 + t * (y2 - y1);
                        double zm = z1 + t * (z2 - z1);
                        double fm = signedField(xm, ym, zm);
                        
                        if (Math.Abs(fm) < 1e-12) break;
                        
                        if (fm * f1 < 0)
                        {
                            tMax = t;
                            f2 = fm;
                        }
                        else
                        {
                            tMin = t;
                            f1 = fm;
                        }
                    }
                    
                    refinedCoords[i, 0] = x1 + t * (x2 - x1);
                    refinedCoords[i, 1] = y1 + t * (y2 - y1);
                    if (refinedCoords.GetLength(1) == 3)
                        refinedCoords[i, 2] = z1 + t * (z2 - z1);
                    
                    // Verify snap quality
                    double fSnapped = signedField(refinedCoords[i, 0], refinedCoords[i, 1], GetZ(refinedCoords, i));
                    maxSnapError = Math.Max(maxSnapError, Math.Abs(fSnapped));
                    snappedCount++;
                }
            }
        }
        
        Console.WriteLine($"  → Snapped {snappedCount} nodes to surface=0 (max error: {maxSnapError:E3})");
        
        // Step 4: RECALCULATE nodal values of surface and region on refined mesh
        Console.WriteLine($"  → Recalculating surface and region values on ALL refined nodes...");
        
        var surfaceValues = new double[refinedMesh.Count<Node>()];
        var regionValues = new double[refinedMesh.Count<Node>()];
        
        for (int i = 0; i < refinedMesh.Count<Node>(); i++)
        {
            surfaceValues[i] = signedField(refinedCoords[i, 0], refinedCoords[i, 1], GetZ(refinedCoords, i));
            
            if (regionField != null)
            {
                regionValues[i] = regionField(refinedCoords[i, 0], refinedCoords[i, 1], GetZ(refinedCoords, i));
            }
            else
            {
                regionValues[i] = -1.0; // All nodes in active region if no region field
            }
        }
        
        // Discover edges before computing average length
        DiscoverEdges(refinedMesh);
        
        // Compute average edge length for tolerance
        double avgEdgeLen = 0;
        int numEdges2 = 0;
        for (int i = 0; i < refinedMesh.Count<Edge>(); i++)
        {
            var n = refinedMesh.NodesOf<Edge, Node>(i);
            double dx = refinedCoords[n[1],0] - refinedCoords[n[0],0];
            double dy = refinedCoords[n[1],1] - refinedCoords[n[0],1];
            double dz = coordDim == 3 ? refinedCoords[n[1],2] - refinedCoords[n[0],2] : 0;
            avgEdgeLen += Math.Sqrt(dx*dx + dy*dy + dz*dz);
            numEdges2++;
        }
        avgEdgeLen /= numEdges2;
        
        // Step 5: Identify crack nodes (nodes where |surface| ≈ 0 AND region < -tol)
        // Use 0.1% of avgEdgeLen to exclude crack tip boundary
        const double zeroTolerance = 1e-5;
        double regionTolerance = 0.001 * avgEdgeLen;  // 0.1% of average edge
        var crackNodes = new HashSet<int>();
        int rejectedByRegion = 0;
        
        for (int i = 0; i < refinedMesh.Count<Node>(); i++)
        {
            if (Math.Abs(surfaceValues[i]) < zeroTolerance)
            {
                if (regionValues[i] < -regionTolerance)
                {
                    crackNodes.Add(i);
                }
                else
                {
                    rejectedByRegion++;
                }
            }
        }
        
        if (rejectedByRegion > 0)
        {
            Console.WriteLine($"  → Rejected {rejectedByRegion} nodes at crack tip (r ≥ {-regionTolerance:E2})");
        }
        
        Console.WriteLine($"  → Found {crackNodes.Count} crack nodes (|surface| < {zeroTolerance:E1}, region < {-regionTolerance:E2})");
        
        if (crackNodes.Count == 0)
        {
            Console.WriteLine($"  ⚠️  No crack nodes found!");
            return (mesh, coordinates);
        }
        
        // Step 6: Identify ORIGINAL mesh boundary (before refinement)
        Console.WriteLine($"  → Identifying original mesh boundary...");
        var originalBoundaryNodes = FindBoundaryNodes(mesh);
        Console.WriteLine($"  → Found {originalBoundaryNodes.Count} boundary nodes in original mesh");
        
        // Map refined nodes back to original boundary
        // A refined node is on original boundary if its parents are both on original boundary
        var refinedBoundaryNodes = new HashSet<int>();
        for (int i = 0; i < refinedMesh.Count<Node>(); i++)
        {
            var parents = refinedMesh.Get<Node, ParentNodes>(i);
            if (parents.Parent1 == parents.Parent2)
            {
                // Original node (not created by refinement)
                if (originalBoundaryNodes.Contains(parents.Parent1))
                    refinedBoundaryNodes.Add(i);
            }
            else
            {
                // Refined node (created on edge between Parent1 and Parent2)
                if (originalBoundaryNodes.Contains(parents.Parent1) && 
                    originalBoundaryNodes.Contains(parents.Parent2))
                    refinedBoundaryNodes.Add(i);
            }
        }
        
        Console.WriteLine($"  → Mapped to {refinedBoundaryNodes.Count} boundary nodes in refined mesh");
        
        // Step 7: Identify tip nodes (crack nodes at crack boundary/termination)
        // A tip node is a crack node that has neighbors OUTSIDE the crack region
        var tipNodes = new HashSet<int>();
        
        if (regionField != null)
        {
            // Build node-to-node connectivity
            var nodeNeighbors = new Dictionary<int, HashSet<int>>();
            for (int i = 0; i < refinedMesh.Count<Node>(); i++)
                nodeNeighbors[i] = new HashSet<int>();
            
            for (int i = 0; i < refinedMesh.Count<Tri3>(); i++)
            {
                var nodes = refinedMesh.NodesOf<Tri3, Node>(i);
                for (int j = 0; j < 3; j++)
                {
                    nodeNeighbors[nodes[j]].Add(nodes[(j + 1) % 3]);
                    nodeNeighbors[nodes[j]].Add(nodes[(j + 2) % 3]);
                }
            }
            
            // Check each crack node for neighbors outside active region
            // Interior tips (crack terminates inside mesh): DON'T duplicate
            // Boundary tips (crack reaches mesh edge): DO duplicate
            foreach (int crackNode in crackNodes)
            {
                // Check if any neighbor is outside the crack region (r > 0)
                bool hasFarNeighbor = false;
                foreach (int neighbor in nodeNeighbors[crackNode])
                {
                    if (regionValues[neighbor] > 0)
                    {
                        hasFarNeighbor = true;
                        break;
                    }
                }
                
                // If this is a tip AND not on mesh boundary, don't duplicate it
                if (hasFarNeighbor && !refinedBoundaryNodes.Contains(crackNode))
                {
                    tipNodes.Add(crackNode);
                }
            }
        }
        
        Console.WriteLine($"  → Found {tipNodes.Count} tip nodes (will NOT be duplicated)");
        
        // Step 8: Nodes to duplicate = crack nodes - tip nodes
        var nodesToDuplicate = new HashSet<int>(crackNodes);
        nodesToDuplicate.ExceptWith(tipNodes);
        
        Console.WriteLine($"  → Will duplicate {nodesToDuplicate.Count} nodes");
        
        if (nodesToDuplicate.Count == 0)
        {
            Console.WriteLine($"  → No nodes to duplicate - returning refined mesh");
            return (refinedMesh, refinedCoords);
        }
        
        // Step 9: Duplicate nodes CAREFULLY
        return DuplicateNodesCarefully(
            refinedMesh,
            refinedCoords,
            nodesToDuplicate,
            surfaceValues,
            visualizationOffset,
            enableSmoothing);
    }
    
    /// <summary>
    /// Duplicate crack nodes CAREFULLY to avoid creating holes.
    /// Uses consistent side classification: each crack node is assigned to ONE side based on its neighbors.
    /// </summary>
    /// <summary>
    /// Duplicate crack nodes to create discontinuity.
    /// Element-based approach: for each element, determine which side based on non-crack nodes.
    /// </summary>
    private static (SimplexMesh, double[,]) DuplicateNodesCarefully(
        SimplexMesh mesh,
        double[,] coords,
        HashSet<int> nodesToDuplicate,
        double[] surfaceValues,
        double visualizationOffset = 0.0,
        bool enableSmoothing = false)
    {
        Console.WriteLine($"  → Starting element-based crack duplication...");
        
        int totalNodes = mesh.Count<Node>();
        int coordDim = coords.GetLength(1);
        
        // CREATE ALL NODES (originals + duplicates)
        var crackedMesh = new SimplexMesh();
        int finalNodeCount = totalNodes + nodesToDuplicate.Count;
        var crackedCoords = new double[finalNodeCount, coordDim];
        
        var originalMap = new Dictionary<int, int>();
        var duplicateMap = new Dictionary<int, int>();
        
        // Copy all original nodes
        for (int i = 0; i < totalNodes; i++)
        {
            int newId = crackedMesh.Add<Node>();
            originalMap[i] = newId;
            
            for (int d = 0; d < coordDim; d++)
                crackedCoords[newId, d] = coords[i, d];
            
            var parents = mesh.Get<Node, ParentNodes>(i);
            crackedMesh.Set<Node, ParentNodes>(newId, parents);
        }
        
        // Create duplicates
        foreach (int nodeId in nodesToDuplicate)
        {
            int dupId = crackedMesh.Add<Node>();
            duplicateMap[nodeId] = dupId;
            
            for (int d = 0; d < coordDim; d++)
                crackedCoords[dupId, d] = coords[nodeId, d];
            
            var parents = mesh.Get<Node, ParentNodes>(nodeId);
            crackedMesh.Set<Node, ParentNodes>(dupId, parents);
        }
        
        Console.WriteLine($"  → Created {totalNodes} original + {nodesToDuplicate.Count} duplicate nodes");
        
        // RECREATE ELEMENTS - determine side based on non-crack nodes
        int elementsCreated = 0;
        int positiveSideElements = 0;
        int negativeSideElements = 0;
        int duplicatesUsed = 0;
        
        for (int i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            var newNodes = new int[3];
            
            // Determine element side from first non-crack node
            double sideValue = 0.0;
            bool hasNonCrackNode = false;
            
            for (int j = 0; j < 3; j++)
            {
                if (!nodesToDuplicate.Contains(nodes[j]))
                {
                    sideValue = surfaceValues[nodes[j]];
                    hasNonCrackNode = true;
                    break;
                }
            }
            
            // If element has no non-crack nodes, default to negative side
            bool usePositiveSide = hasNonCrackNode && (sideValue > 0);
            
            if (usePositiveSide)
                positiveSideElements++;
            else
                negativeSideElements++;
            
            // Assign nodes
            for (int j = 0; j < 3; j++)
            {
                if (!nodesToDuplicate.Contains(nodes[j]))
                {
                    // Non-crack node
                    newNodes[j] = originalMap[nodes[j]];
                }
                else
                {
                    // Crack node - use duplicate for positive, original for negative
                    if (usePositiveSide)
                    {
                        newNodes[j] = duplicateMap[nodes[j]];
                        duplicatesUsed++;
                    }
                    else
                    {
                        newNodes[j] = originalMap[nodes[j]];
                    }
                }
            }
            
            crackedMesh.Add<Tri3, Node>(newNodes[0], newNodes[1], newNodes[2]);
            elementsCreated++;
        }
        
        Console.WriteLine($"  → Created {elementsCreated} elements");
        Console.WriteLine($"  → Positive side: {positiveSideElements} elements, Negative side: {negativeSideElements} elements");
        Console.WriteLine($"  → Duplicate nodes used {duplicatesUsed} times in elements");
        Console.WriteLine($"  → Final mesh: {crackedMesh.Count<Node>()} nodes, {crackedMesh.Count<Tri3>()} triangles");
        
        // OPTIONAL: VISUALIZATION OFFSET (separate crack surfaces)
        if (visualizationOffset > 0)
        {
            Console.WriteLine($"  → Applying visualization offset: {visualizationOffset}mm");
            
            // Simple approach: offset along surface normal approximation
            foreach (var crackNode in nodesToDuplicate)
            {
                int origId = originalMap[crackNode];
                int dupId = duplicateMap[crackNode];
                
                // Approximate normal from surface gradient (simplified)
                double nx = 0, ny = 0;
                
                // Use surface values to estimate gradient direction
                double surfVal = surfaceValues[crackNode];
                if (Math.Abs(surfVal) < 1e-6)
                {
                    // On crack - use simple approximation
                    nx = 0;
                    ny = 1.0;  // Default to y-direction
                }
                
                // Normalize
                double len = Math.Sqrt(nx * nx + ny * ny + 1e-10);
                nx /= len;
                ny /= len;
                
                // Offset nodes in opposite directions
                crackedCoords[origId, 0] -= (visualizationOffset / 2.0) * nx;
                crackedCoords[origId, 1] -= (visualizationOffset / 2.0) * ny;
                
                crackedCoords[dupId, 0] += (visualizationOffset / 2.0) * nx;
                crackedCoords[dupId, 1] += (visualizationOffset / 2.0) * ny;
            }
        }
        
        // OPTIONAL: SMOOTHING (with crack nodes fixed as boundaries)
        if (enableSmoothing)
        {
            Console.WriteLine($"  → Smoothing mesh (all boundaries fixed)...");
            
            var boundaryNodes = new HashSet<int>();
            
            // Fix ALL boundary nodes in the cracked mesh (includes crack surfaces)
            var crackedBoundary = FindBoundaryNodes(crackedMesh);
            foreach (var node in crackedBoundary)
                boundaryNodes.Add(node);
            
            Console.WriteLine($"  → Fixed {boundaryNodes.Count} boundary nodes (mesh edges + crack surfaces)");
            
            // Fast conservative Laplacian smoothing
            var smoothedCoords = (double[,])crackedCoords.Clone();
            int iterations = 3;  // Reduced from 5
            double relaxation = 0.25;  // More conservative (was 0.5)
            
            // Build neighbor map once (FAST)
            var nodeNeighbors = new Dictionary<int, HashSet<int>>();
            for (int i = 0; i < crackedMesh.Count<Node>(); i++)
                nodeNeighbors[i] = new HashSet<int>();
            
            for (int elemId = 0; elemId < crackedMesh.Count<Tri3>(); elemId++)
            {
                var n = crackedMesh.NodesOf<Tri3, Node>(elemId);
                nodeNeighbors[n[0]].Add(n[1]); nodeNeighbors[n[0]].Add(n[2]);
                nodeNeighbors[n[1]].Add(n[0]); nodeNeighbors[n[1]].Add(n[2]);
                nodeNeighbors[n[2]].Add(n[0]); nodeNeighbors[n[2]].Add(n[1]);
            }
            
            for (int iter = 0; iter < iterations; iter++)
            {
                var newCoords = (double[,])smoothedCoords.Clone();
                int rejected = 0;
                
                for (int nodeId = 0; nodeId < crackedMesh.Count<Node>(); nodeId++)
                {
                    if (boundaryNodes.Contains(nodeId)) continue;
                    
                    var neighbors = nodeNeighbors[nodeId];
                    if (neighbors.Count == 0) continue;
                    
                    // Compute centroid
                    double[] centroid = new double[coordDim];
                    foreach (var nbr in neighbors)
                        for (int d = 0; d < coordDim; d++)
                            centroid[d] += smoothedCoords[nbr, d];
                    
                    for (int d = 0; d < coordDim; d++)
                        centroid[d] /= neighbors.Count;
                    
                    // Conservative move
                    double[] newPos = new double[coordDim];
                    for (int d = 0; d < coordDim; d++)
                        newPos[d] = smoothedCoords[nodeId, d] + relaxation * (centroid[d] - smoothedCoords[nodeId, d]);
                    
                    // Quality check: reject if move inverts any triangle
                    bool valid = true;
                    for (int elemId = 0; elemId < crackedMesh.Count<Tri3>(); elemId++)
                    {
                        var n = crackedMesh.NodesOf<Tri3, Node>(elemId);
                        bool hasNode = (n[0] == nodeId || n[1] == nodeId || n[2] == nodeId);
                        if (!hasNode) continue;
                        
                        // Check area with new position
                        double[,] testCoords = (double[,])smoothedCoords.Clone();
                        for (int d = 0; d < coordDim; d++)
                            testCoords[nodeId, d] = newPos[d];
                        
                        double area2 = (testCoords[n[1],0] - testCoords[n[0],0]) * (testCoords[n[2],1] - testCoords[n[0],1]) -
                                      (testCoords[n[1],1] - testCoords[n[0],1]) * (testCoords[n[2],0] - testCoords[n[0],0]);
                        
                        if (area2 <= 0)
                        {
                            valid = false;
                            rejected++;
                            break;
                        }
                    }
                    
                    if (valid)
                    {
                        for (int d = 0; d < coordDim; d++)
                            newCoords[nodeId, d] = newPos[d];
                    }
                }
                
                smoothedCoords = newCoords;
            }
            
            crackedMesh = CorrectTriangleOrientations(crackedMesh, smoothedCoords);
            return (crackedMesh, smoothedCoords);
        }
        
        crackedMesh = CorrectTriangleOrientations(crackedMesh, crackedCoords);
        return (crackedMesh, crackedCoords);
    }
    
    /// <summary>
    /// Determine side of crack node using local crack geometry when neighbors don't provide clear answer.
    /// Simplified version - just return NEGATIVE to avoid expensive computation.
    /// </summary>
    private static string DetermineSideByCrackNormal(
        SimplexMesh mesh,
        double[,] coords,
        int crackNode,
        double[] surfaceValues)
    {
        // Simplified: Default to NEGATIVE side for isolated crack nodes
        // This avoids expensive O(n) search through all triangles
        return "NEGATIVE";
    }
    
    /// <summary>
    /// Duplicate crack nodes to create topological discontinuity.
    /// Uses element-side classification: if most nodes (except new node) are positive, use duplicate.
    /// Tips (nodes at region boundary, not on mesh boundary) are NOT duplicated.
    /// </summary>
    
    /// <summary>
    /// Find boundary nodes (nodes that share boundary edges).
    /// </summary>
    public static HashSet<int> FindBoundaryNodes(SimplexMesh mesh)
    {
        var boundaryNodes = new HashSet<int>();
        
        DiscoverEdges(mesh);
        
        // Count how many triangles share each edge
        var edgeCount = new Dictionary<(int, int), int>();
        
        for (int i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            
            for (int j = 0; j < 3; j++)
            {
                int n1 = nodes[j];
                int n2 = nodes[(j + 1) % 3];
                
                var edge = n1 < n2 ? (n1, n2) : (n2, n1);
                
                if (!edgeCount.ContainsKey(edge))
                    edgeCount[edge] = 0;
                edgeCount[edge]++;
            }
        }
        
        // Boundary edges have count == 1
        foreach (var (edge, count) in edgeCount)
        {
            if (count == 1)
            {
                boundaryNodes.Add(edge.Item1);
                boundaryNodes.Add(edge.Item2);
            }
        }
        
        return boundaryNodes;
    }
    
    /// <summary>
    /// Duplicate nodes from a given set to create crack topology.
    /// </summary>
    /// Duplicate crack nodes to create topological discontinuity.
    /// Internal method used by CreateCrackFromSignedField.
    /// </summary>
    private static (SimplexMesh, double[,]) DuplicateNewNodes(
        SimplexMesh mesh,
        double[,] coords,
        int originalNodeCount,
        List<(int, int)> originalCutEdges,
        SimplexMesh originalMesh,
        SignedFieldFunction? signedField,
        double[,]? originalCoords,
        double visualizationOffset)
    {
        // NO NODE DUPLICATION - just return refined mesh with crack nodes
        Console.WriteLine($"  → Skipping node duplication (disabled)");
        return (mesh, coords);
    }
    
    /// <summary>
    /// Compute opening direction for crack nodes based on local crack geometry.
    /// For 2D: perpendicular to crack edges (in xy-plane)
    /// For 3D: perpendicular to crack surface (using triangle normals)
    /// </summary>
    private static Dictionary<int, (double, double, double)> ComputeOpeningDirections(
        SimplexMesh mesh,
        double[,] coords,
        HashSet<int> newNodes,
        HashSet<int> nodesToDuplicate)
    {
        var openingDirection = new Dictionary<int, (double, double, double)>();
        
        // Determine if mesh is 2D or 3D by checking z-coordinate variation
        double minZ = double.MaxValue, maxZ = double.MinValue;
        for (int i = 0; i < mesh.Count<Node>(); i++)
        {
            double z = GetZ(coords, i);
            if (z < minZ) minZ = z;
            if (z > maxZ) maxZ = z;
        }
        bool is2D = (maxZ - minZ) < 1e-6;
        
        foreach (int nodeId in nodesToDuplicate)
        {
            double sumNX = 0, sumNY = 0, sumNZ = 0;
            int count = 0;
            
            if (is2D)
            {
                // 2D: Use edge normals in xy-plane
                for (int i = 0; i < mesh.Count<Edge>(); i++)
                {
                    var edgeNodes = mesh.NodesOf<Edge, Node>(i);
                    
                    if (edgeNodes[0] == nodeId || edgeNodes[1] == nodeId)
                    {
                        int other = (edgeNodes[0] == nodeId) ? edgeNodes[1] : edgeNodes[0];
                        
                        if (newNodes.Contains(other))
                        {
                            double x1 = coords[nodeId, 0], y1 = coords[nodeId, 1];
                            double x2 = coords[other, 0], y2 = coords[other, 1];
                            
                            double tx = x2 - x1, ty = y2 - y1;
                            double len = Math.Sqrt(tx * tx + ty * ty);
                            
                            if (len > 1e-10)
                            {
                                tx /= len;
                                ty /= len;
                                
                                // Normal = rotate tangent 90° in xy-plane
                                double nx = -ty, ny = tx;
                                
                                sumNX += nx;
                                sumNY += ny;
                                count++;
                            }
                        }
                    }
                }
            }
            else
            {
                // 3D: Use crack surface triangle normals
                for (int i = 0; i < mesh.Count<Tri3>(); i++)
                {
                    var triNodes = mesh.NodesOf<Tri3, Node>(i);
                    
                    // Check if this triangle is on the crack surface
                    bool hasThisNode = (triNodes[0] == nodeId) || (triNodes[1] == nodeId) || (triNodes[2] == nodeId);
                    bool allNewNodes = newNodes.Contains(triNodes[0]) && 
                                      newNodes.Contains(triNodes[1]) && 
                                      newNodes.Contains(triNodes[2]);
                    
                    if (hasThisNode && allNewNodes)
                    {
                        // This is a crack surface triangle
                        double x0 = coords[triNodes[0], 0], y0 = coords[triNodes[0], 1], z0 = GetZ(coords, triNodes[0]);
                        double x1 = coords[triNodes[1], 0], y1 = coords[triNodes[1], 1], z1 = GetZ(coords, triNodes[1]);
                        double x2 = coords[triNodes[2], 0], y2 = coords[triNodes[2], 1], z2 = GetZ(coords, triNodes[2]);
                        
                        // Compute triangle normal via cross product
                        double v1x = x1 - x0, v1y = y1 - y0, v1z = z1 - z0;
                        double v2x = x2 - x0, v2y = y2 - y0, v2z = z2 - z0;
                        
                        double nx = v1y * v2z - v1z * v2y;
                        double ny = v1z * v2x - v1x * v2z;
                        double nz = v1x * v2y - v1y * v2x;
                        
                        double len = Math.Sqrt(nx * nx + ny * ny + nz * nz);
                        if (len > 1e-10)
                        {
                            nx /= len;
                            ny /= len;
                            nz /= len;
                            
                            sumNX += nx;
                            sumNY += ny;
                            sumNZ += nz;
                            count++;
                        }
                    }
                }
            }
            
            if (count > 0)
            {
                sumNX /= count;
                sumNY /= count;
                sumNZ /= count;
                
                double normLen = Math.Sqrt(sumNX * sumNX + sumNY * sumNY + sumNZ * sumNZ);
                if (normLen > 1e-10)
                {
                    sumNX /= normLen;
                    sumNY /= normLen;
                    sumNZ /= normLen;
                }
                
                openingDirection[nodeId] = (sumNX, sumNY, sumNZ);
            }
            else
            {
                // Fallback: use Y for 2D, Z for 3D
                openingDirection[nodeId] = is2D ? (0, 1, 0) : (0, 0, 1);
            }
        }
        
        return openingDirection;
    }
    
    /// <summary>
    /// Copy all elements, using duplicate nodes for elements on positive side.
    /// Rule: If ALL non-crack nodes are positive → use duplicates.
    /// </summary>
    private static void CopyElementsWithCrackNodes(
        SimplexMesh newMesh,
        SimplexMesh mesh,
        HashSet<int> newNodes,
        Dictionary<int, bool> nodeIsPositive,
        Dictionary<int, int> nodeIdMap,
        Dictionary<int, int> duplicateMap)
    {
        newMesh.WithBatch(() =>
        {
            // Points
            for (int i = 0; i < mesh.Count<Point>(); i++)
            {
                var nodes = mesh.NodesOf<Point, Node>(i);
                int nodeId = nodes[0];
                
                int newNodeId = (duplicateMap.ContainsKey(nodeId)) ? 
                    duplicateMap[nodeId] : nodeIdMap[nodeId];
                
                int idx = newMesh.Add<Point, Node>(newNodeId);
                var orig = mesh.Get<Point, OriginalElement>(i);
                newMesh.Set<Point, OriginalElement>(idx, orig);
            }
            
            // Bar2
            for (int i = 0; i < mesh.Count<Bar2>(); i++)
            {
                var nodes = mesh.NodesOf<Bar2, Node>(i);
                
                bool allOtherNodesPositive = CheckAllNonCrackNodesPositive(
                    nodes, newNodes, nodeIsPositive);
                
                int n0 = (allOtherNodesPositive && duplicateMap.ContainsKey(nodes[0])) ? 
                    duplicateMap[nodes[0]] : nodeIdMap[nodes[0]];
                int n1 = (allOtherNodesPositive && duplicateMap.ContainsKey(nodes[1])) ? 
                    duplicateMap[nodes[1]] : nodeIdMap[nodes[1]];
                
                int idx = newMesh.Add<Bar2, Node>(n0, n1);
                var orig = mesh.Get<Bar2, OriginalElement>(i);
                newMesh.Set<Bar2, OriginalElement>(idx, orig);
            }
            
            // Tri3
            for (int i = 0; i < mesh.Count<Tri3>(); i++)
            {
                var nodes = mesh.NodesOf<Tri3, Node>(i);
                
                bool allOtherNodesPositive = CheckAllNonCrackNodesPositive(
                    nodes, newNodes, nodeIsPositive);
                
                int n0 = (allOtherNodesPositive && duplicateMap.ContainsKey(nodes[0])) ? 
                    duplicateMap[nodes[0]] : nodeIdMap[nodes[0]];
                int n1 = (allOtherNodesPositive && duplicateMap.ContainsKey(nodes[1])) ? 
                    duplicateMap[nodes[1]] : nodeIdMap[nodes[1]];
                int n2 = (allOtherNodesPositive && duplicateMap.ContainsKey(nodes[2])) ? 
                    duplicateMap[nodes[2]] : nodeIdMap[nodes[2]];
                
                int idx = newMesh.Add<Tri3, Node>(n0, n1, n2);
                var orig = mesh.Get<Tri3, OriginalElement>(i);
                newMesh.Set<Tri3, OriginalElement>(idx, orig);
            }
            
            // Tet4
            for (int i = 0; i < mesh.Count<Tet4>(); i++)
            {
                var nodes = mesh.NodesOf<Tet4, Node>(i);
                
                bool allOtherNodesPositive = CheckAllNonCrackNodesPositive(
                    nodes, newNodes, nodeIsPositive);
                
                int n0 = (allOtherNodesPositive && duplicateMap.ContainsKey(nodes[0])) ? 
                    duplicateMap[nodes[0]] : nodeIdMap[nodes[0]];
                int n1 = (allOtherNodesPositive && duplicateMap.ContainsKey(nodes[1])) ? 
                    duplicateMap[nodes[1]] : nodeIdMap[nodes[1]];
                int n2 = (allOtherNodesPositive && duplicateMap.ContainsKey(nodes[2])) ? 
                    duplicateMap[nodes[2]] : nodeIdMap[nodes[2]];
                int n3 = (allOtherNodesPositive && duplicateMap.ContainsKey(nodes[3])) ? 
                    duplicateMap[nodes[3]] : nodeIdMap[nodes[3]];
                
                int idx = newMesh.Add<Tet4, Node>(n0, n1, n2, n3);
                var orig = mesh.Get<Tet4, OriginalElement>(i);
                newMesh.Set<Tet4, OriginalElement>(idx, orig);
            }
        });
    }
    
    /// <summary>
    /// Check if all non-crack nodes in element are on positive side.
    /// </summary>
    private static bool CheckAllNonCrackNodesPositive(
        IReadOnlyList<int> nodes,
        HashSet<int> newNodes,
        Dictionary<int, bool> nodeIsPositive)
    {
        foreach (int nodeId in nodes)
        {
            if (!newNodes.Contains(nodeId))
            {
                if (!nodeIsPositive.ContainsKey(nodeId) || !nodeIsPositive[nodeId])
                {
                    return false;
                }
            }
        }
        return true;
    }
    
    /// <summary>
    /// Verify element quality and reduce crack opening if needed to maintain positive Jacobians.
    /// </summary>
    /// <summary>
    /// Verify element quality and reduce crack opening if needed to maintain positive Jacobians.
    /// Works for both 2D (Tri3) and 3D (Tet4) meshes.
    /// </summary>
    private static void VerifyAndFixJacobians(
        SimplexMesh mesh,
        double[,] coords,
        double[,] originalCoords,
        Dictionary<int, int> duplicateMap,
        Dictionary<int, (double, double, double)> openingDirection,
        double openingMagnitude)
    {
        int negativeJacCount = 0;
        
        // Check triangles
        for (int i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            double jac = ComputeTriangleJacobian(coords, nodes[0], nodes[1], nodes[2]);
            
            if (jac < 0)
            {
                negativeJacCount++;
            }
        }
        
        // Check tetrahedra
        for (int i = 0; i < mesh.Count<Tet4>(); i++)
        {
            var nodes = mesh.NodesOf<Tet4, Node>(i);
            double jac = ComputeTetrahedronJacobian(coords, nodes[0], nodes[1], nodes[2], nodes[3]);
            
            if (jac < 0)
            {
                negativeJacCount++;
            }
        }
        
        if (negativeJacCount > 0)
        {
            // Reduce opening gradually until all Jacobians are positive
            double[] reductionFactors = { 0.5, 0.25, 0.1, 0.05, 0.0 };
            
            foreach (double factor in reductionFactors)
            {
                // Apply reduced opening
                foreach (var (oldId, newId) in duplicateMap)
                {
                    if (openingDirection.ContainsKey(oldId))
                    {
                        var (nx, ny, nz) = openingDirection[oldId];
                        coords[newId, 0] = originalCoords[oldId, 0] + openingMagnitude * factor * nx;
                        coords[newId, 1] = originalCoords[oldId, 1] + openingMagnitude * factor * ny;
                        if (coords.GetLength(1) == 3)
                            coords[newId, 2] = originalCoords[oldId, 2] + openingMagnitude * factor * nz;
                    }
                }
                
                // Recheck all elements
                int stillNegative = 0;
                
                for (int i = 0; i < mesh.Count<Tri3>(); i++)
                {
                    var nodes = mesh.NodesOf<Tri3, Node>(i);
                    double jac = ComputeTriangleJacobian(coords, nodes[0], nodes[1], nodes[2]);
                    if (jac < 0) stillNegative++;
                }
                
                for (int i = 0; i < mesh.Count<Tet4>(); i++)
                {
                    var nodes = mesh.NodesOf<Tet4, Node>(i);
                    double jac = ComputeTetrahedronJacobian(coords, nodes[0], nodes[1], nodes[2], nodes[3]);
                    if (jac < 0) stillNegative++;
                }
                
                if (stillNegative == 0)
                {
                    break;
                }
            }
        }
    }
    
    /// <summary>
    /// Compute 2D Jacobian determinant for a triangle.
    /// </summary>
    private static double ComputeTriangleJacobian(double[,] coords, int n0, int n1, int n2)
    {
        double x0 = coords[n0, 0], y0 = coords[n0, 1];
        double x1 = coords[n1, 0], y1 = coords[n1, 1];
        double x2 = coords[n2, 0], y2 = coords[n2, 1];
        
        return (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
    }
    
    /// <summary>
    /// Compute 3D Jacobian determinant for a tetrahedron.
    /// </summary>
    private static double ComputeTetrahedronJacobian(double[,] coords, int n0, int n1, int n2, int n3)
    {
        int maxNode = coords.GetLength(0) - 1;
        
        // Check bounds before accessing
        if (n0 > maxNode || n1 > maxNode || n2 > maxNode || n3 > maxNode)
        {
            Console.WriteLine($"ERROR: Node index out of bounds!");
            Console.WriteLine($"  coords array size: {coords.GetLength(0)}");
            Console.WriteLine($"  node indices: {n0}, {n1}, {n2}, {n3}");
            Console.WriteLine($"  out of bounds: {(n0 > maxNode ? "n0" : "")}{(n1 > maxNode ? " n1" : "")}{(n2 > maxNode ? " n2" : "")}{(n3 > maxNode ? " n3" : "")}");
            throw new IndexOutOfRangeException($"Node indices out of bounds: max={maxNode}, nodes=({n0},{n1},{n2},{n3})");
        }
        
        double x0 = coords[n0, 0], y0 = coords[n0, 1], z0 = GetZ(coords, n0);
        double x1 = coords[n1, 0], y1 = coords[n1, 1], z1 = GetZ(coords, n1);
        double x2 = coords[n2, 0], y2 = coords[n2, 1], z2 = GetZ(coords, n2);
        double x3 = coords[n3, 0], y3 = coords[n3, 1], z3 = GetZ(coords, n3);
        
        // Jacobian = det of 3x3 matrix formed by edge vectors
        double v1x = x1 - x0, v1y = y1 - y0, v1z = z1 - z0;
        double v2x = x2 - x0, v2y = y2 - y0, v2z = z2 - z0;
        double v3x = x3 - x0, v3y = y3 - y0, v3z = z3 - z0;
        
        return v1x * (v2y * v3z - v2z * v3y) -
               v1y * (v2x * v3z - v2z * v3x) +
               v1z * (v2x * v3y - v2y * v3x);
    }
    
    #region Crack Insertion - 3D (Tetrahedral Meshes)
    
    /// <summary>
    /// Create a crack in a 3D tetrahedral mesh using signed distance field.
    /// Same algorithm as 2D but for tetrahedra.
    /// </summary>
    public static (SimplexMesh, double[,]) CreateCrackFromSignedField3D(
        SimplexMesh mesh,
        double[,] coordinates,
        SignedFieldFunction signedField,
        SignedFieldFunction? regionField = null,
        bool enableMeshPerturbation = false,
        bool enableSmoothing = false)
    {
        Console.WriteLine($"  → Creating 3D crack with mesh refinement and node duplication...");
        Console.WriteLine($"  → Initial mesh: {mesh.Count<Node>()} nodes, {mesh.Count<Tet4>()} tetrahedra");
        
        // Find edges that cross the crack surface
        DiscoverEdges(mesh);
        var edgesToRefine = new List<(int, int)>();
        
        int totalCrossingEdges = 0;
        int regionFilteredEdges = 0;
        
        for (int i = 0; i < mesh.Count<Edge>(); i++)
        {
            var nodes = mesh.NodesOf<Edge, Node>(i);
            int n1 = nodes[0], n2 = nodes[1];
            
            double f1 = signedField(coordinates[n1, 0], coordinates[n1, 1], coordinates[n1, 2]);
            double f2 = signedField(coordinates[n2, 0], coordinates[n2, 1], coordinates[n2, 2]);
            
            if (f1 * f2 < 0)  // Sign change = edge crosses crack
            {
                totalCrossingEdges++;
                
                if (regionField != null)
                {
                    double r1 = regionField(coordinates[n1, 0], coordinates[n1, 1], coordinates[n1, 2]);
                    double r2 = regionField(coordinates[n2, 0], coordinates[n2, 1], coordinates[n2, 2]);
                    
                    if (r1 <= 0 || r2 <= 0)  // At least one endpoint in active region
                        edgesToRefine.Add((n1, n2));
                    else
                        regionFilteredEdges++;
                }
                else
                {
                    edgesToRefine.Add((n1, n2));
                }
            }
        }
        
        Console.WriteLine($"  → Edges crossing crack surface: {totalCrossingEdges}");
        if (regionField != null)
            Console.WriteLine($"  → Filtered by region: {regionFilteredEdges}");
        Console.WriteLine($"  → Edges to refine: {edgesToRefine.Count}");
        
        if (edgesToRefine.Count == 0)
        {
            Console.WriteLine($"  ⚠️  No edges to refine - returning original mesh");
            return (mesh, coordinates);
        }
        
        // CHECK INITIAL MESH JACOBIANS (before refinement)
        Console.WriteLine($"  → Checking initial mesh quality...");
        int initialNegative = 0;
        for (int i = 0; i < mesh.Count<Tet4>(); i++)
        {
            var nodes = mesh.NodesOf<Tet4, Node>(i);
            double jac = ComputeTetrahedronJacobian(coordinates, nodes[0], nodes[1], nodes[2], nodes[3]);
            if (jac <= 0) initialNegative++;
        }
        if (initialNegative > 0)
            Console.WriteLine($"  ⚠️  Initial mesh has {initialNegative}/{mesh.Count<Tet4>()} elements with non-positive Jacobian!");
        else
            Console.WriteLine($"  ✓ Initial mesh: all elements have positive Jacobians");
        
        // Store original node count before refinement
        int originalNodeCount = mesh.Count<Node>();
        
        // Use MeshRefinement.Refine to split edges AND subdivide tetrahedra
        Console.WriteLine($"  → Calling MeshRefinement.Refine with closure enforcement...");
        var (refinedMesh, _) = MeshRefinement.Refine(mesh, edgesToRefine, 
            enforceClosureForTets: false,
            validateTopology: true,
            inputCoordinates: coordinates);
        
        Console.WriteLine($"  → Refined mesh: {refinedMesh.Count<Node>()} nodes, {refinedMesh.Count<Tet4>()} tetrahedra");
        
        // Use MeshRefinement's own coordinate interpolation
        Console.WriteLine($"  → Using MeshRefinement.InterpolateCoordinates...");
        var refinedCoords = MeshRefinement.InterpolateCoordinates(refinedMesh, coordinates);
        
        // Save intermediate refined mesh for visualization
        Console.WriteLine($"  → Saving refined mesh before snapping...");
        SimplexRemesher.SaveGiD(refinedMesh, refinedCoords, "refined_crack_mesh.post.msh");
        
        // Snap new nodes to exact crack surface (surface = 0)
        Console.WriteLine($"  → Snapping crack nodes to exact zero crossing...");
        int snappedCount = 0;
        int skippedTooClose = 0;
        int skippedWouldInvert = 0;
        double maxSnapError = 0.0;
        
        // Build node-to-tets map for validation
        var nodeToTets = new Dictionary<int, List<int>>();
        for (int t = 0; t < refinedMesh.Count<Tet4>(); t++)
        {
            var nodes = refinedMesh.NodesOf<Tet4, Node>(t);
            for (int j = 0; j < 4; j++)
            {
                if (!nodeToTets.ContainsKey(nodes[j]))
                    nodeToTets[nodes[j]] = new List<int>();
                nodeToTets[nodes[j]].Add(t);
            }
        }
        
        for (int i = originalNodeCount; i < refinedMesh.Count<Node>(); i++)
        {
            var parents = refinedMesh.Get<Node, ParentNodes>(i);
            
            if (parents.Parent1 != parents.Parent2)
            {
                int p1 = parents.Parent1, p2 = parents.Parent2;
                
                double x1 = coordinates[p1, 0], y1 = coordinates[p1, 1], z1 = coordinates[p1, 2];
                double x2 = coordinates[p2, 0], y2 = coordinates[p2, 1], z2 = coordinates[p2, 2];
                
                double f1 = signedField(x1, y1, z1);
                double f2 = signedField(x2, y2, z2);
                
                // Snap to zero-crossing if edge crosses crack
                if (Math.Abs(f2 - f1) > 1e-10 && f1 * f2 <= 0)
                {
                    // Current interpolated position
                    double xCurr = refinedCoords[i, 0];
                    double yCurr = refinedCoords[i, 1];
                    double zCurr = refinedCoords[i, 2];
                    double fCurr = signedField(xCurr, yCurr, zCurr);
                    
                    // Don't snap if already very close to surface
                    double edgeLength = Math.Sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1) + (z2-z1)*(z2-z1));
                    double snapTolerance = Math.Max(0.001, 0.001 * edgeLength); // 0.1% of edge or 0.001mm
                    
                    if (Math.Abs(fCurr) < snapTolerance)
                    {
                        skippedTooClose++;
                        continue;
                    }
                    
                    // Use bisection for nonlinear fields
                    double tMin = 0.0, tMax = 1.0;
                    double t = 0.5;
                    
                    for (int iter = 0; iter < 20; iter++)
                    {
                        t = (tMin + tMax) / 2.0;
                        double xm = x1 + t * (x2 - x1);
                        double ym = y1 + t * (y2 - y1);
                        double zm = z1 + t * (z2 - z1);
                        double fm = signedField(xm, ym, zm);
                        
                        if (Math.Abs(fm) < 1e-10) break;
                        
                        if (fm * f1 < 0)
                        {
                            tMax = t;
                            f2 = fm;
                        }
                        else
                        {
                            tMin = t;
                            f1 = fm;
                        }
                    }
                    
                    // Check if snap distance is significant
                    double xNew = x1 + t * (x2 - x1);
                    double yNew = y1 + t * (y2 - y1);
                    double zNew = z1 + t * (z2 - z1);
                    double snapDist = Math.Sqrt((xNew-xCurr)*(xNew-xCurr) + (yNew-yCurr)*(yNew-yCurr) + (zNew-zCurr)*(zNew-zCurr));
                    
                    if (snapDist > snapTolerance)
                    {
                        // Validate: check if snapping would invert any adjacent tet
                        bool wouldInvert = false;
                        if (nodeToTets.ContainsKey(i))
                        {
                            var tempCoords = (double[,])refinedCoords.Clone();
                            tempCoords[i, 0] = xNew;
                            tempCoords[i, 1] = yNew;
                            tempCoords[i, 2] = zNew;
                            
                            foreach (var tetIdx in nodeToTets[i])
                            {
                                var tetNodes = refinedMesh.NodesOf<Tet4, Node>(tetIdx);
                                double jac = ComputeTetrahedronJacobian(tempCoords, tetNodes[0], tetNodes[1], tetNodes[2], tetNodes[3]);
                                if (jac <= 0)
                                {
                                    wouldInvert = true;
                                    break;
                                }
                            }
                        }
                        
                        if (!wouldInvert)
                        {
                            refinedCoords[i, 0] = xNew;
                            refinedCoords[i, 1] = yNew;
                            refinedCoords[i, 2] = zNew;
                            
                            double finalError = Math.Abs(signedField(refinedCoords[i, 0], refinedCoords[i, 1], refinedCoords[i, 2]));
                            maxSnapError = Math.Max(maxSnapError, finalError);
                            snappedCount++;
                        }
                        else
                        {
                            skippedWouldInvert++;
                        }
                    }
                    else
                    {
                        skippedTooClose++;
                    }
                }
            }
        }
        
        Console.WriteLine($"  → Snapped {snappedCount} nodes to surface=0 (max error: {maxSnapError:E3})");
        if (skippedTooClose > 0)
            Console.WriteLine($"  → Skipped {skippedTooClose} nodes already close enough to surface");
        if (skippedWouldInvert > 0)
            Console.WriteLine($"  → Skipped {skippedWouldInvert} nodes that would invert tets");

        MeshRefinement.CheckJacobians(refinedMesh, refinedCoords, "After snapping");
        MeshRefinement.FixNegativeJacobians(refinedMesh, refinedCoords);
        MeshRefinement.CheckJacobians(refinedMesh, refinedCoords, "Final mesh");

        
        // Duplicate nodes on crack surface
        Console.WriteLine($"  → Duplicating crack surface nodes...");
        var crackSurfaceNodes = new HashSet<int>();
        
        // Identify crack surface nodes (use generous tolerance)
        for (int i = 0; i < refinedMesh.Count<Node>(); i++)
        {
            double f = signedField(refinedCoords[i, 0], refinedCoords[i, 1], refinedCoords[i, 2]);
            if (Math.Abs(f) < 1e-3) // Match snap tolerance
                crackSurfaceNodes.Add(i);
        }
        
        // Find crack faces (triangular faces with all 3 nodes on crack)
        var crackFaces = new HashSet<(int, int, int)>();
        var faceTets = new Dictionary<(int, int, int), List<(int tetIdx, int oppositeNode)>>();
        
        for (int t = 0; t < refinedMesh.Count<Tet4>(); t++)
        {
            var nodes = refinedMesh.NodesOf<Tet4, Node>(t);
            var faces = new[]
            {
                (nodes[1], nodes[2], nodes[3], nodes[0]), // Face opposite node 0
                (nodes[0], nodes[2], nodes[3], nodes[1]), // Face opposite node 1
                (nodes[0], nodes[1], nodes[3], nodes[2]), // Face opposite node 2
                (nodes[0], nodes[1], nodes[2], nodes[3])  // Face opposite node 3
            };
            
            foreach (var (n1, n2, n3, opp) in faces)
            {
                if (crackSurfaceNodes.Contains(n1) && crackSurfaceNodes.Contains(n2) && crackSurfaceNodes.Contains(n3))
                {
                    var face = CanonicalFace(n1, n2, n3);
                    crackFaces.Add(face);
                    
                    if (!faceTets.ContainsKey(face))
                        faceTets[face] = new List<(int, int)>();
                    faceTets[face].Add((t, opp));
                }
            }
        }
        
        Console.WriteLine($"  → Found {crackFaces.Count} crack faces");
        
        // Expand coordinates for duplicates
        var expandedCoords = new double[refinedMesh.Count<Node>() + crackSurfaceNodes.Count, 3];
        Array.Copy(refinedCoords, expandedCoords, refinedMesh.Count<Node>() * 3);
        
        // Create duplicates
        var nodeDuplicate = new Dictionary<int, int>();
        foreach (int nodeIdx in crackSurfaceNodes)
        {
            int duplicate = refinedMesh.Add<Node>();
            nodeDuplicate[nodeIdx] = duplicate;
            
            expandedCoords[duplicate, 0] = refinedCoords[nodeIdx, 0];
            expandedCoords[duplicate, 1] = refinedCoords[nodeIdx, 1];
            expandedCoords[duplicate, 2] = refinedCoords[nodeIdx, 2];
        }
        refinedCoords = expandedCoords;
        
        Console.WriteLine($"  → Duplicated {nodeDuplicate.Count} crack surface nodes");
        
        // Update tet connectivity based on which side of crack face
        var allTets = new List<int[]>();
        int modifiedCount = 0;
        
        for (int t = 0; t < refinedMesh.Count<Tet4>(); t++)
        {
            var nodesReadOnly = refinedMesh.NodesOf<Tet4, Node>(t);
            var nodes = new int[] { nodesReadOnly[0], nodesReadOnly[1], nodesReadOnly[2], nodesReadOnly[3] };
            bool modified = false;
            
            // Check if this tet touches a crack face
            var faces = new[]
            {
                (nodes[1], nodes[2], nodes[3], 0),
                (nodes[0], nodes[2], nodes[3], 1),
                (nodes[0], nodes[1], nodes[3], 2),
                (nodes[0], nodes[1], nodes[2], 3)
            };
            
            foreach (var (n1, n2, n3, oppIdx) in faces)
            {
                var face = CanonicalFace(n1, n2, n3);
                if (crackFaces.Contains(face))
                {
                    int oppositeNode = nodes[oppIdx];
                    double f = signedField(refinedCoords[oppositeNode, 0], 
                                          refinedCoords[oppositeNode, 1], 
                                          refinedCoords[oppositeNode, 2]);
                    
                    if (f > 1e-9)
                    {
                        for (int j = 0; j < 4; j++)
                        {
                            if (j != oppIdx && nodeDuplicate.ContainsKey(nodes[j]))
                            {
                                nodes[j] = nodeDuplicate[nodes[j]];
                                modified = true;
                            }
                        }
                    }
                    break;
                }
            }
            
            if (modified) modifiedCount++;
            allTets.Add(nodes);
        }
        
        Console.WriteLine($"  → Modified {modifiedCount} tets to use duplicated nodes");
        
        // Create NEW mesh with updated connectivity to avoid duplication
        var newMesh = new SimplexMesh();
        
        // Copy all nodes (original + duplicates) with their attributes
        for (int i = 0; i < refinedMesh.Count<Node>(); i++)
        {
            newMesh.Add<Node>();
            try
            {
                var parents = refinedMesh.Get<Node, ParentNodes>(i);
                newMesh.Set<Node, ParentNodes>(i, parents);
            }
            catch { } // Skip if ParentNodes not set
        }
        
        // Add all tets with updated connectivity
        foreach (var nodes in allTets)
            newMesh.Add<Tet4, Node>(nodes[0], nodes[1], nodes[2], nodes[3]);
        
        refinedMesh = newMesh;
        
        // Validate orientation after duplication
        Console.WriteLine($"  → Validating orientation after duplication...");
        int invertedAfterDup = 0;
        for (int t = 0; t < refinedMesh.Count<Tet4>(); t++)
        {
            var nodes = refinedMesh.NodesOf<Tet4, Node>(t);
            double jac = ComputeTetrahedronJacobian(refinedCoords, nodes[0], nodes[1], nodes[2], nodes[3]);
            if (jac <= 0) invertedAfterDup++;
        }
        
        if (invertedAfterDup > 0)
            Console.WriteLine($"  ⚠️  WARNING: {invertedAfterDup} inverted tets after duplication - chirality corrupted!");
        else
            Console.WriteLine($"  ✓ All tets have positive Jacobians after duplication");
        
        // Check mesh quality with actual coordinates
        Console.WriteLine($"  → Checking refined mesh quality...");
        int negativeCount = 0;
        for (int i = 0; i < refinedMesh.Count<Tet4>(); i++)
        {
            var nodes = refinedMesh.NodesOf<Tet4, Node>(i);
            double jac = ComputeTetrahedronJacobian(refinedCoords, nodes[0], nodes[1], nodes[2], nodes[3]);
            if (jac <= 0) negativeCount++;
        }
        
        // DIAGNOSTIC: Show first inverted tet if any
        if (negativeCount > 0)
        {
            Console.WriteLine($"  → DIAGNOSTIC: Found {negativeCount} inverted tets, examining first one...");
            for (int i = 0; i < refinedMesh.Count<Tet4>(); i++)
            {
                var nodes = refinedMesh.NodesOf<Tet4, Node>(i);
                double jac = ComputeTetrahedronJacobian(refinedCoords, nodes[0], nodes[1], nodes[2], nodes[3]);
                if (jac <= 0)
                {
                    Console.WriteLine($"     Tet {i}: nodes={nodes[0]},{nodes[1]},{nodes[2]},{nodes[3]}, Jac={jac:E3}");
                    
                    // Check if it's a new tet (created by refinement) or old tet
                    int oldNodeCount = mesh.Count<Node>();
                    bool hasNewNode = nodes.Any(n => n >= oldNodeCount);
                    Console.WriteLine($"     Has new midpoint node: {hasNewNode}");
                    
                    // Show coordinates
                    for (int j = 0; j < 4; j++)
                    {
                        int n = nodes[j];
                        Console.WriteLine($"       Node {n}: ({refinedCoords[n,0]:F3}, {refinedCoords[n,1]:F3}, {refinedCoords[n,2]:F3})");
                    }
                    break;
                }
            }
        }
        
        // Verify Jacobians
        negativeCount = 0;
        for (int i = 0; i < refinedMesh.Count<Tet4>(); i++)
        {
            var nodes = refinedMesh.NodesOf<Tet4, Node>(i);
            double jac = ComputeTetrahedronJacobian(refinedCoords, nodes[0], nodes[1], nodes[2], nodes[3]);
            if (jac <= 0) negativeCount++;
        }
        
        if (negativeCount > 0)
            Console.WriteLine($"  ⚠️  WARNING: {negativeCount} elements with non-positive Jacobian");
        else
            Console.WriteLine($"  ✓ All elements have positive Jacobians");
        
        return (refinedMesh, refinedCoords);
    }
    public static HashSet<int> FindBoundaryNodes3D(SimplexMesh mesh)
    {
        var boundaryNodes = new HashSet<int>();
        
        // Count how many tetrahedra share each face
        var faceCount = new Dictionary<(int, int, int), int>();
        
        for (int i = 0; i < mesh.Count<Tet4>(); i++)
        {
            var nodes = mesh.NodesOf<Tet4, Node>(i);
            
            // Four faces per tetrahedron
            var faces = new[]
            {
                (nodes[0], nodes[1], nodes[2]),
                (nodes[0], nodes[1], nodes[3]),
                (nodes[0], nodes[2], nodes[3]),
                (nodes[1], nodes[2], nodes[3])
            };
            
            foreach (var face in faces)
            {
                // Sort to get canonical form
                var sorted = new[] { face.Item1, face.Item2, face.Item3 };
                Array.Sort(sorted);
                var key = (sorted[0], sorted[1], sorted[2]);
                
                if (!faceCount.ContainsKey(key))
                    faceCount[key] = 0;
                faceCount[key]++;
            }
        }
        
        // Boundary faces have count == 1
        foreach (var (face, count) in faceCount)
        {
            if (count == 1)
            {
                boundaryNodes.Add(face.Item1);
                boundaryNodes.Add(face.Item2);
                boundaryNodes.Add(face.Item3);
            }
        }
        
        return boundaryNodes;
    }
    
    /// <summary>
    /// Duplicate crack nodes in 3D tetrahedral mesh using consistent side classification.
    /// </summary>
    private static (SimplexMesh, double[,]) DuplicateNodesCarefully3D(
        SimplexMesh mesh,
        double[,] coords,
        HashSet<int> nodesToDuplicate,
        double[] surfaceValues)
    {
        Console.WriteLine($"  → Starting consistent side classification algorithm (3D)...");
        
        int totalNodes = mesh.Count<Node>();
        
        // STEP 1: CLASSIFY ALL NODES BY SIDE
        Console.WriteLine($"  → Step 1: Classifying all nodes by side...");
        
        var side = new Dictionary<int, string>(); // "POSITIVE", "NEGATIVE", or "UNASSIGNED"
        
        for (int i = 0; i < totalNodes; i++)
        {
            if (nodesToDuplicate.Contains(i))
            {
                side[i] = "UNASSIGNED";  // Crack nodes - determine later
            }
            else
            {
                side[i] = (surfaceValues[i] > 0) ? "POSITIVE" : "NEGATIVE";
            }
        }
        
        // STEP 2: PROPAGATE SIDE LABELS TO CRACK NODES
        Console.WriteLine($"  → Step 2: Propagating side labels to crack nodes...");
        
        // Build node-to-node connectivity (edges)
        var nodeNeighbors = new Dictionary<int, HashSet<int>>();
        for (int i = 0; i < totalNodes; i++)
        {
            nodeNeighbors[i] = new HashSet<int>();
        }
        
        // Extract edges from tetrahedra
        for (int i = 0; i < mesh.Count<Tet4>(); i++)
        {
            var nodes = mesh.NodesOf<Tet4, Node>(i);
            
            // Six edges per tetrahedron
            var edges = new[]
            {
                (nodes[0], nodes[1]),
                (nodes[0], nodes[2]),
                (nodes[0], nodes[3]),
                (nodes[1], nodes[2]),
                (nodes[1], nodes[3]),
                (nodes[2], nodes[3])
            };
            
            foreach (var (n1, n2) in edges)
            {
                nodeNeighbors[n1].Add(n2);
                nodeNeighbors[n2].Add(n1);
            }
        }
        
        // Classify each crack node based on its non-crack neighbors
        int positiveAssigned = 0, negativeAssigned = 0, tieBreaks = 0;
        
        foreach (int crackNode in nodesToDuplicate)
        {
            var neighbors = nodeNeighbors[crackNode];
            
            // Count positive and negative neighbors (excluding other crack nodes)
            int positiveCount = 0;
            int negativeCount = 0;
            
            foreach (int neighbor in neighbors)
            {
                if (!nodesToDuplicate.Contains(neighbor)) // Only count non-crack neighbors
                {
                    if (side[neighbor] == "POSITIVE")
                        positiveCount++;
                    else if (side[neighbor] == "NEGATIVE")
                        negativeCount++;
                }
            }
            
            // Assign side based on majority
            if (positiveCount > negativeCount)
            {
                side[crackNode] = "POSITIVE";
                positiveAssigned++;
            }
            else if (negativeCount > positiveCount)
            {
                side[crackNode] = "NEGATIVE";
                negativeAssigned++;
            }
            else
            {
                // TIE-BREAKER: default to NEGATIVE
                side[crackNode] = "NEGATIVE";
                tieBreaks++;
            }
        }
        
        Console.WriteLine($"     Assigned {positiveAssigned} to POSITIVE side");
        Console.WriteLine($"     Assigned {negativeAssigned} to NEGATIVE side");
        Console.WriteLine($"     Tie-breaks: {tieBreaks}");
        
        // STEP 3: CREATE NODE MAPPINGS
        Console.WriteLine($"  → Step 3: Creating node mappings...");
        
        var crackedMesh = new SimplexMesh();
        int finalNodeCount = totalNodes + nodesToDuplicate.Count;
        var crackedCoords = new double[finalNodeCount, 3];
        
        var originalMap = new Dictionary<int, int>(); // original -> original copy
        var duplicateMap = new Dictionary<int, int>(); // original -> duplicate copy
        var nodeMap = new Dictionary<int, int>();      // original -> final node to use
        
        // Copy all nodes (originals)
        for (int i = 0; i < totalNodes; i++)
        {
            int newId = crackedMesh.Add<Node>();
            originalMap[i] = newId;
            
            crackedCoords[newId, 0] = coords[i, 0];
            crackedCoords[newId, 1] = coords[i, 1];
            if (crackedCoords.GetLength(1) == 3)
                crackedCoords[newId, 2] = coords[i, 2];
            
            var parents = mesh.Get<Node, ParentNodes>(i);
            crackedMesh.Set<Node, ParentNodes>(newId, parents);
        }
        
        // Create duplicates
        foreach (int nodeId in nodesToDuplicate)
        {
            int dupId = crackedMesh.Add<Node>();
            duplicateMap[nodeId] = dupId;
            
            crackedCoords[dupId, 0] = coords[nodeId, 0];
            crackedCoords[dupId, 1] = coords[nodeId, 1];
            if (crackedCoords.GetLength(1) == 3)
                crackedCoords[dupId, 2] = coords[nodeId, 2];
            
            var parents = mesh.Get<Node, ParentNodes>(nodeId);
            crackedMesh.Set<Node, ParentNodes>(dupId, parents);
        }
        
        // Build final mapping: POSITIVE crack nodes use duplicate, others use original
        for (int i = 0; i < totalNodes; i++)
        {
            if (!nodesToDuplicate.Contains(i))
            {
                nodeMap[i] = originalMap[i];
            }
            else
            {
                if (side[i] == "POSITIVE")
                    nodeMap[i] = duplicateMap[i];
                else
                    nodeMap[i] = originalMap[i];
            }
        }
        
        Console.WriteLine($"  → Copied {totalNodes} original nodes + {nodesToDuplicate.Count} duplicates");
        
        // STEP 4: RECREATE ALL TETRAHEDRA
        Console.WriteLine($"  → Step 4: Recreating all tetrahedra...");
        
        int elementsCreated = 0;
        
        for (int i = 0; i < mesh.Count<Tet4>(); i++)
        {
            var nodes = mesh.NodesOf<Tet4, Node>(i);
            var newNodes = new int[4];
            
            for (int j = 0; j < 4; j++)
            {
                newNodes[j] = nodeMap[nodes[j]];
            }
            
            crackedMesh.AddTetrahedron(newNodes[0], newNodes[1], newNodes[2], newNodes[3]);
            elementsCreated++;
        }
        
        Console.WriteLine($"  → Created {elementsCreated} tetrahedra (expected {mesh.Count<Tet4>()})");
        
        if (elementsCreated != mesh.Count<Tet4>())
        {
            Console.WriteLine($"  ⚠️  WARNING: Element count mismatch!");
        }
        else
        {
            Console.WriteLine($"  ✓ No holes - all tetrahedra recreated successfully");
        }
        
        Console.WriteLine($"  → Final mesh: {crackedMesh.Count<Node>()} nodes, {crackedMesh.Count<Tet4>()} tetrahedra");
        
        return (crackedMesh, crackedCoords);
    }
    
    #endregion
    
    #region Orientation Correction

    /// <summary>Correct triangle orientations to ensure CCW (positive signed area)</summary>
    private static SimplexMesh CorrectTriangleOrientations(SimplexMesh mesh, double[,] coords)
    {
        var output = new SimplexMesh();
        int flipped = 0;
        
        output.WithBatch(() =>
        {
            for (int i = 0; i < mesh.Count<Node>(); i++)
            {
                output.Add<Node>();
                output.Set<Node, ParentNodes>(i, mesh.Get<Node, ParentNodes>(i));
            }
            
            for (int i = 0; i < mesh.Count<Tri3>(); i++)
            {
                var n = mesh.NodesOf<Tri3, Node>(i);
                double area2 = (coords[n[1],0] - coords[n[0],0]) * (coords[n[2],1] - coords[n[0],1]) -
                              (coords[n[1],1] - coords[n[0],1]) * (coords[n[2],0] - coords[n[0],0]);
                
                const double tol = 1e-14;
                if (Math.Abs(area2) < tol)
                {
                    // Degenerate - keep as is
                    output.Add<Tri3, Node>(n[0], n[1], n[2]);
                }
                else if (area2 < 0)
                {
                    // CW → CCW: swap nodes 1 and 2
                    output.Add<Tri3, Node>(n[0], n[2], n[1]);
                    flipped++;
                }
                else
                {
                    // Already CCW
                    output.Add<Tri3, Node>(n[0], n[1], n[2]);
                }
            }
            
            for (int i = 0; i < mesh.Count<Quad4>(); i++)
            {
                var n = mesh.NodesOf<Quad4, Node>(i);
                output.Add<Quad4, Node>(n[0], n[1], n[2], n[3]);
            }
        });
        
        if (flipped > 0)
            Console.WriteLine($"  → Corrected {flipped} CW→CCW triangles");
        
        return output;
    }

    /// <summary>Correct quad orientations to ensure positive Jacobians</summary>
    private static SimplexMesh CorrectQuadOrientations(SimplexMesh mesh, double[,] coords)
    {
        var output = new SimplexMesh();
        int flipped = 0;
        
        output.WithBatch(() =>
        {
            for (int i = 0; i < mesh.Count<Node>(); i++)
            {
                output.Add<Node>();
                output.Set<Node, ParentNodes>(i, mesh.Get<Node, ParentNodes>(i));
            }
            
            for (int i = 0; i < mesh.Count<Tri3>(); i++)
            {
                var n = mesh.NodesOf<Tri3, Node>(i);
                output.Add<Tri3, Node>(n[0], n[1], n[2]);
            }
            
            for (int i = 0; i < mesh.Count<Quad4>(); i++)
            {
                var n = mesh.NodesOf<Quad4, Node>(i);
                
                double x1 = coords[n[0],0], y1 = coords[n[0],1];
                double x2 = coords[n[1],0], y2 = coords[n[1],1];
                double x3 = coords[n[2],0], y3 = coords[n[2],1];
                double x4 = coords[n[3],0], y4 = coords[n[3],1];
                
                double dxdxi = 0.25 * (-x1 + x2 + x3 - x4);
                double dydxi = 0.25 * (-y1 + y2 + y3 - y4);
                double dxdeta = 0.25 * (-x1 - x2 + x3 + x4);
                double dydeta = 0.25 * (-y1 - y2 + y3 + y4);
                
                double jac = dxdxi * dydeta - dydxi * dxdeta;
                
                if (jac < 0)
                {
                    output.Add<Quad4, Node>(n[0], n[3], n[2], n[1]);
                    flipped++;
                }
                else
                    output.Add<Quad4, Node>(n[0], n[1], n[2], n[3]);
            }
        });
        
        if (flipped > 0)
            Console.WriteLine($"  → Corrected {flipped} inverted quads");
        
        return output;
    }

    /// <summary>Correct tetrahedron orientations to ensure positive volumes</summary>
    private static SimplexMesh CorrectTetOrientations(SimplexMesh mesh, double[,] coords)
    {
        var output = new SimplexMesh();
        int flipped = 0;
        
        output.WithBatch(() =>
        {
            for (int i = 0; i < mesh.Count<Node>(); i++)
            {
                output.Add<Node>();
                output.Set<Node, ParentNodes>(i, mesh.Get<Node, ParentNodes>(i));
            }
            
            for (int i = 0; i < mesh.Count<Tet4>(); i++)
            {
                var n = mesh.NodesOf<Tet4, Node>(i);
                
                double ax = coords[n[1],0] - coords[n[0],0];
                double ay = coords[n[1],1] - coords[n[0],1];
                double az = coords[n[1],2] - coords[n[0],2];
                double bx = coords[n[2],0] - coords[n[0],0];
                double by = coords[n[2],1] - coords[n[0],1];
                double bz = coords[n[2],2] - coords[n[0],2];
                double cx = coords[n[3],0] - coords[n[0],0];
                double cy = coords[n[3],1] - coords[n[0],1];
                double cz = coords[n[3],2] - coords[n[0],2];
                
                double vol6 = ax*(by*cz - bz*cy) - ay*(bx*cz - bz*cx) + az*(bx*cy - by*cx);
                
                if (vol6 < 0)
                {
                    output.Add<Tet4, Node>(n[1], n[0], n[2], n[3]);
                    flipped++;
                }
                else
                    output.Add<Tet4, Node>(n[0], n[1], n[2], n[3]);
            }
        });
        
        if (flipped > 0)
            Console.WriteLine($"  → Corrected {flipped} inverted tetrahedra");
        
        return output;
    }
    
    private static (int, int, int) CanonicalFace(int n1, int n2, int n3)
    {
        var sorted = new[] { n1, n2, n3 };
        Array.Sort(sorted);
        return (sorted[0], sorted[1], sorted[2]);
    }
    
    #endregion
}
