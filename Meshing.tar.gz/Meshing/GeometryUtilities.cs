// GeometryUtilities.cs - Fundamental geometric operations
// Point-in-polygon, distance calculations, projections, intersections
// License: GPLv3

namespace Numerical;

/// <summary>
///     Fundamental 2D/3D geometric operations: point-in-polygon tests,
///     distance calculations, point projections, and geometric queries.
/// </summary>
public static class GeometryUtilities
{
    private const double EPSILON = 1e-10;

    #region Point-in-Polygon Tests

    /// <summary>
    ///     Check if point is inside polygon using ray casting algorithm.
    ///     Works for convex and non-convex polygons.
    /// </summary>
    /// <param name="point">Query point (x, y)</param>
    /// <param name="polygon">Polygon vertices [n,2] or [n,3], must be closed (first != last)</param>
    /// <returns>True if point is inside polygon</returns>
    public static bool IsPointInPolygon((double x, double y) point, double[,] polygon)
    {
        var n = polygon.GetLength(0);
        var inside = false;

        for (int i = 0, j = n - 1; i < n; j = i++)
        {
            double xi = polygon[i, 0], yi = polygon[i, 1];
            double xj = polygon[j, 0], yj = polygon[j, 1];

            if (yi > point.y != yj > point.y &&
                point.x < (xj - xi) * (point.y - yi) / (yj - yi) + xi)
                inside = !inside;
        }

        return inside;
    }

    /// <summary>
    ///     Check if point is inside polygon (list format).
    /// </summary>
    public static bool IsPointInPolygon((double x, double y) point, List<(double x, double y)> polygon)
    {
        var n = polygon.Count;
        var inside = false;

        for (int i = 0, j = n - 1; i < n; j = i++)
        {
            double xi = polygon[i].x, yi = polygon[i].y;
            double xj = polygon[j].x, yj = polygon[j].y;

            if (yi > point.y != yj > point.y &&
                point.x < (xj - xi) * (point.y - yi) / (yj - yi) + xi)
                inside = !inside;
        }

        return inside;
    }

    /// <summary>
    ///     Check if point is on polygon boundary (within tolerance).
    /// </summary>
    public static bool IsPointOnPolygonBoundary(
        (double x, double y) point,
        double[,] polygon,
        double tolerance = EPSILON)
    {
        var n = polygon.GetLength(0);

        for (var i = 0; i < n; i++)
        {
            var j = (i + 1) % n;

            var lineStart = (polygon[i, 0], polygon[i, 1]);
            var lineEnd = (polygon[j, 0], polygon[j, 1]);

            var dist = DistancePointToSegment(point, lineStart, lineEnd);

            if (dist < tolerance)
                return true;
        }

        return false;
    }

    #endregion

    #region Distance Calculations

    /// <summary>
    ///     Compute distance from point to infinite line.
    /// </summary>
    public static double DistancePointToLine(
        (double x, double y) point,
        (double x, double y) lineStart,
        (double x, double y) lineEnd)
    {
        var dx = lineEnd.x - lineStart.x;
        var dy = lineEnd.y - lineStart.y;
        var lineLength = Math.Sqrt(dx * dx + dy * dy);

        if (lineLength < EPSILON)
            return Distance2D(point, lineStart);

        // Distance = |cross product| / line length
        var cross = Math.Abs((lineEnd.x - lineStart.x) * (lineStart.y - point.y) -
                             (lineStart.x - point.x) * (lineEnd.y - lineStart.y));

        return cross / lineLength;
    }

    /// <summary>
    ///     Compute distance from point to line segment (not infinite line).
    /// </summary>
    public static double DistancePointToSegment(
        (double x, double y) point,
        (double x, double y) segmentStart,
        (double x, double y) segmentEnd)
    {
        var dx = segmentEnd.x - segmentStart.x;
        var dy = segmentEnd.y - segmentStart.y;
        var lengthSquared = dx * dx + dy * dy;

        if (lengthSquared < EPSILON)
            return Distance2D(point, segmentStart);

        // Parameter along segment: 0 = start, 1 = end
        var t = ((point.x - segmentStart.x) * dx + (point.y - segmentStart.y) * dy) / lengthSquared;

        // Clamp to segment
        t = Math.Max(0, Math.Min(1, t));

        var closestPoint = (
            segmentStart.x + t * dx,
            segmentStart.y + t * dy
        );

        return Distance2D(point, closestPoint);
    }

    /// <summary>
    ///     Compute 2D Euclidean distance between two points.
    /// </summary>
    public static double Distance2D((double x, double y) p1, (double x, double y) p2)
    {
        var dx = p2.x - p1.x;
        var dy = p2.y - p1.y;
        return Math.Sqrt(dx * dx + dy * dy);
    }

    /// <summary>
    ///     Compute 3D Euclidean distance between two points.
    /// </summary>
    public static double Distance3D(
        (double x, double y, double z) p1,
        (double x, double y, double z) p2)
    {
        var dx = p2.x - p1.x;
        var dy = p2.y - p1.y;
        var dz = p2.z - p1.z;
        return Math.Sqrt(dx * dx + dy * dy + dz * dz);
    }

    #endregion

    #region Point Projections

    /// <summary>
    ///     Project point onto infinite line.
    /// </summary>
    public static (double x, double y) ProjectPointToLine(
        (double x, double y) point,
        (double x, double y) lineStart,
        (double x, double y) lineEnd)
    {
        var dx = lineEnd.x - lineStart.x;
        var dy = lineEnd.y - lineStart.y;
        var lengthSquared = dx * dx + dy * dy;

        if (lengthSquared < EPSILON)
            return lineStart;

        var t = ((point.x - lineStart.x) * dx + (point.y - lineStart.y) * dy) / lengthSquared;

        return (
            lineStart.x + t * dx,
            lineStart.y + t * dy
        );
    }

    /// <summary>
    ///     Project point onto line segment (clamped to segment bounds).
    /// </summary>
    public static (double x, double y) ProjectPointToSegment(
        (double x, double y) point,
        (double x, double y) segmentStart,
        (double x, double y) segmentEnd)
    {
        var dx = segmentEnd.x - segmentStart.x;
        var dy = segmentEnd.y - segmentStart.y;
        var lengthSquared = dx * dx + dy * dy;

        if (lengthSquared < EPSILON)
            return segmentStart;

        var t = ((point.x - segmentStart.x) * dx + (point.y - segmentStart.y) * dy) / lengthSquared;
        t = Math.Max(0, Math.Min(1, t));

        return (
            segmentStart.x + t * dx,
            segmentStart.y + t * dy
        );
    }

    #endregion

    #region Line Intersections

    /// <summary>
    ///     Find intersection point of two infinite lines (if it exists).
    /// </summary>
    /// <returns>Intersection point and true if lines intersect, otherwise (0,0) and false</returns>
    public static ((double x, double y) point, bool intersects) IntersectLines(
        (double x, double y) line1Start,
        (double x, double y) line1End,
        (double x, double y) line2Start,
        (double x, double y) line2End)
    {
        double x1 = line1Start.x, y1 = line1Start.y;
        double x2 = line1End.x, y2 = line1End.y;
        double x3 = line2Start.x, y3 = line2Start.y;
        double x4 = line2End.x, y4 = line2End.y;

        var denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);

        if (Math.Abs(denom) < EPSILON)
            return ((0, 0), false); // Parallel or coincident

        var t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom;

        var x = x1 + t * (x2 - x1);
        var y = y1 + t * (y2 - y1);

        return ((x, y), true);
    }

    /// <summary>
    ///     Find intersection point of two line segments (if it exists).
    /// </summary>
    public static ((double x, double y) point, bool intersects) IntersectSegments(
        (double x, double y) seg1Start,
        (double x, double y) seg1End,
        (double x, double y) seg2Start,
        (double x, double y) seg2End)
    {
        double x1 = seg1Start.x, y1 = seg1Start.y;
        double x2 = seg1End.x, y2 = seg1End.y;
        double x3 = seg2Start.x, y3 = seg2Start.y;
        double x4 = seg2End.x, y4 = seg2End.y;

        var denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);

        if (Math.Abs(denom) < EPSILON)
            return ((0, 0), false); // Parallel or coincident

        var t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom;
        var u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / denom;

        // Check if intersection is within both segments
        if (t >= 0 && t <= 1 && u >= 0 && u <= 1)
        {
            var x = x1 + t * (x2 - x1);
            var y = y1 + t * (y2 - y1);
            return ((x, y), true);
        }

        return ((0, 0), false);
    }

    #endregion

    #region Bounding Box Operations

    /// <summary>
    ///     Compute axis-aligned bounding box of a point set.
    /// </summary>
    public static (double xMin, double xMax, double yMin, double yMax) ComputeBoundingBox2D(
        double[,] points)
    {
        var n = points.GetLength(0);
        if (n == 0)
            return (0, 0, 0, 0);

        double xMin = points[0, 0], xMax = points[0, 0];
        double yMin = points[0, 1], yMax = points[0, 1];

        for (var i = 1; i < n; i++)
        {
            xMin = Math.Min(xMin, points[i, 0]);
            xMax = Math.Max(xMax, points[i, 0]);
            yMin = Math.Min(yMin, points[i, 1]);
            yMax = Math.Max(yMax, points[i, 1]);
        }

        return (xMin, xMax, yMin, yMax);
    }

    /// <summary>
    ///     Compute axis-aligned bounding box (list format).
    /// </summary>
    public static (double xMin, double xMax, double yMin, double yMax) ComputeBoundingBox2D(
        List<(double x, double y)> points)
    {
        if (points.Count == 0)
            return (0, 0, 0, 0);

        double xMin = points[0].x, xMax = points[0].x;
        double yMin = points[0].y, yMax = points[0].y;

        for (var i = 1; i < points.Count; i++)
        {
            xMin = Math.Min(xMin, points[i].x);
            xMax = Math.Max(xMax, points[i].x);
            yMin = Math.Min(yMin, points[i].y);
            yMax = Math.Max(yMax, points[i].y);
        }

        return (xMin, xMax, yMin, yMax);
    }

    /// <summary>
    ///     Check if point is inside axis-aligned bounding box.
    /// </summary>
    public static bool IsPointInBoundingBox(
        (double x, double y) point,
        (double xMin, double xMax, double yMin, double yMax) bbox)
    {
        return point.x >= bbox.xMin && point.x <= bbox.xMax &&
               point.y >= bbox.yMin && point.y <= bbox.yMax;
    }

    #endregion

    #region Angular and Vector Operations

    /// <summary>
    ///     Compute angle between two 2D vectors in radians [0, π].
    /// </summary>
    public static double AngleBetweenVectors2D(
        (double x, double y) v1,
        (double x, double y) v2)
    {
        var dot = v1.x * v2.x + v1.y * v2.y;
        var mag1 = Math.Sqrt(v1.x * v1.x + v1.y * v1.y);
        var mag2 = Math.Sqrt(v2.x * v2.x + v2.y * v2.y);

        if (mag1 < EPSILON || mag2 < EPSILON)
            return 0;

        var cosAngle = dot / (mag1 * mag2);
        cosAngle = Math.Max(-1.0, Math.Min(1.0, cosAngle)); // Clamp for numerical stability

        return Math.Acos(cosAngle);
    }

    /// <summary>
    ///     Compute signed angle from v1 to v2 in radians [-π, π].
    ///     Positive = counter-clockwise, negative = clockwise.
    /// </summary>
    public static double SignedAngleBetweenVectors2D(
        (double x, double y) v1,
        (double x, double y) v2)
    {
        var angle = AngleBetweenVectors2D(v1, v2);
        var cross = v1.x * v2.y - v1.y * v2.x;

        return cross < 0 ? -angle : angle;
    }

    /// <summary>
    ///     Compute 2D cross product (scalar, z-component of 3D cross product).
    /// </summary>
    public static double CrossProduct2D(
        (double x, double y) v1,
        (double x, double y) v2)
    {
        return v1.x * v2.y - v1.y * v2.x;
    }

    /// <summary>
    ///     Compute 2D dot product.
    /// </summary>
    public static double DotProduct2D(
        (double x, double y) v1,
        (double x, double y) v2)
    {
        return v1.x * v2.x + v1.y * v2.y;
    }

    /// <summary>
    ///     Normalize 2D vector to unit length.
    /// </summary>
    public static (double x, double y) Normalize2D((double x, double y) v)
    {
        var length = Math.Sqrt(v.x * v.x + v.y * v.y);

        if (length < EPSILON)
            return (0, 0);

        return (v.x / length, v.y / length);
    }

    /// <summary>
    ///     Rotate 2D vector by angle (radians, counter-clockwise).
    /// </summary>
    public static (double x, double y) Rotate2D((double x, double y) v, double angle)
    {
        var cos = Math.Cos(angle);
        var sin = Math.Sin(angle);

        return (
            v.x * cos - v.y * sin,
            v.x * sin + v.y * cos
        );
    }

    #endregion

    #region Interpolation

    /// <summary>
    ///     Linear interpolation between two points.
    /// </summary>
    public static (double x, double y) Lerp2D(
        (double x, double y) p1,
        (double x, double y) p2,
        double t)
    {
        return (
            p1.x + t * (p2.x - p1.x),
            p1.y + t * (p2.y - p1.y)
        );
    }

    /// <summary>
    ///     Barycentric interpolation in a triangle.
    /// </summary>
    public static (double x, double y) BarycentricInterpolation(
        (double x, double y) p0,
        (double x, double y) p1,
        (double x, double y) p2,
        double w0, double w1, double w2)
    {
        return (
            w0 * p0.x + w1 * p1.x + w2 * p2.x,
            w0 * p0.y + w1 * p1.y + w2 * p2.y
        );
    }

    /// <summary>
    ///     Compute barycentric coordinates of point in triangle.
    ///     Returns (w0, w1, w2) where point = w0*p0 + w1*p1 + w2*p2.
    /// </summary>
    public static (double w0, double w1, double w2) ComputeBarycentricCoordinates(
        (double x, double y) point,
        (double x, double y) p0,
        (double x, double y) p1,
        (double x, double y) p2)
    {
        var v0x = p1.x - p0.x;
        var v0y = p1.y - p0.y;
        var v1x = p2.x - p0.x;
        var v1y = p2.y - p0.y;
        var v2x = point.x - p0.x;
        var v2y = point.y - p0.y;

        var d00 = v0x * v0x + v0y * v0y;
        var d01 = v0x * v1x + v0y * v1y;
        var d11 = v1x * v1x + v1y * v1y;
        var d20 = v2x * v0x + v2y * v0y;
        var d21 = v2x * v1x + v2y * v1y;

        var denom = d00 * d11 - d01 * d01;

        if (Math.Abs(denom) < EPSILON)
            return (0, 0, 0); // Degenerate triangle

        var w1 = (d11 * d20 - d01 * d21) / denom;
        var w2 = (d00 * d21 - d01 * d20) / denom;
        var w0 = 1.0 - w1 - w2;

        return (w0, w1, w2);
    }

    #endregion
}
