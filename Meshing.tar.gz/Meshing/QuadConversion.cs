// QuadConversion.cs - Triangle to Quadrilateral Conversion
// Extracted from UnifiedMesher.cs for clean architecture
// Multiple strategies: quality-based, valence-based, geometry-based
// License: GPLv3

using static Numerical.MeshGeometry;

namespace Numerical;

/// <summary>
///     Convert triangular meshes to quad-dominant meshes.
///     Implements multiple pairing strategies for optimal quad generation.
/// </summary>
public static class QuadConversion
{
    private const double EPSILON = 1e-10;

    #region Public API

    /// <summary>
    ///     Convert triangular mesh to quad-dominant mesh.
    ///     Uses multi-strategy approach: quality + valence + geometry.
    /// </summary>
    /// <param name="mesh">Input triangular mesh</param>
    /// <param name="coords">Node coordinates</param>
    /// <param name="passes">Number of optimization passes (default: 2)</param>
    /// <param name="minQualityThreshold">Minimum quad quality to accept (0-1, default: 0.3)</param>
    /// <returns>Quad-dominant mesh with both Quad4 and remaining Tri3 elements</returns>
    public static (SimplexMesh mesh, double[,] coords) ConvertToQuads(
        SimplexMesh mesh,
        double[,] coords,
        int passes = 2,
        double minQualityThreshold = 0.3)
    {
        Console.WriteLine("[QuadConversion] Starting triangle-to-quad conversion...");
        Console.WriteLine($"  Input: {mesh.Count<Tri3>()} triangles");

        // Build triangle adjacency
        var adjacency = BuildTriangleAdjacency(mesh);

        // Track which triangles have been converted to quads
        var converted = new HashSet<int>();
        var quads = new List<(int n0, int n1, int n2, int n3)>();

        for (var pass = 0; pass < passes; pass++)
        {
            Console.WriteLine($"  Pass {pass + 1}/{passes}...");

            var quadsThisPass = 0;

            // Strategy 1: Quality-based pairing
            quadsThisPass += PairByQuality(mesh, coords, adjacency, converted, quads, minQualityThreshold);

            // Strategy 2: Valence-based pairing (prefer nodes with valence 4)
            quadsThisPass += PairByValence(mesh, coords, adjacency, converted, quads, minQualityThreshold);

            // Strategy 3: Geometry-based pairing (prefer aligned edges)
            quadsThisPass += PairByGeometry(mesh, coords, adjacency, converted, quads, minQualityThreshold);

            Console.WriteLine($"    → Created {quadsThisPass} quads in pass {pass + 1}");

            if (quadsThisPass == 0)
                break; // No more conversions possible
        }

        Console.WriteLine($"  Total quads created: {quads.Count}");
        Console.WriteLine($"  Remaining triangles: {mesh.Count<Tri3>() - converted.Count * 2}");

        // Build new mesh with quads and remaining triangles
        var newMesh = BuildQuadMesh(mesh, coords, quads, converted);

        return (newMesh, coords);
    }

    #endregion

    #region Node Valence

    /// <summary>
    ///     Compute node valence (number of connected elements).
    /// </summary>
    private static Dictionary<int, int> ComputeNodeValence(
        SimplexMesh mesh,
        HashSet<int> excludeTriangles)
    {
        var valence = new Dictionary<int, int>();

        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            if (excludeTriangles.Contains(i))
                continue;

            var nodes = mesh.NodesOf<Tri3, Node>(i);

            foreach (var node in nodes) valence[node] = valence.GetValueOrDefault(node, 0) + 1;
        }

        return valence;
    }

    #endregion

    #region Mesh Building

    /// <summary>
    ///     Build new mesh with quads and remaining triangles.
    /// </summary>
    private static SimplexMesh BuildQuadMesh(
        SimplexMesh oldMesh,
        double[,] coords,
        List<(int n0, int n1, int n2, int n3)> quads,
        HashSet<int> convertedTriangles)
    {
        var newMesh = new SimplexMesh();

        newMesh.WithBatch(() =>
        {
            // Add all nodes
            for (var i = 0; i < oldMesh.Count<Node>(); i++) newMesh.AddNode(i);

            // Add quads
            foreach (var (n0, n1, n2, n3) in quads) newMesh.AddQuad(n0, n1, n2, n3);

            // Add remaining triangles
            for (var i = 0; i < oldMesh.Count<Tri3>(); i++)
                if (!convertedTriangles.Contains(i))
                {
                    var nodes = oldMesh.NodesOf<Tri3, Node>(i);
                    newMesh.AddTriangle(nodes[0], nodes[1], nodes[2]);
                }
        });

        Console.WriteLine(
            $"[QuadConversion] Built mesh: {newMesh.Count<Quad4>()} quads, {newMesh.Count<Tri3>()} triangles");

        return newMesh;
    }

    #endregion

    #region Triangle Adjacency

    /// <summary>
    ///     Build triangle-to-triangle adjacency via shared edges.
    /// </summary>
    private static Dictionary<int, List<int>> BuildTriangleAdjacency(SimplexMesh mesh)
    {
        var edgeToTriangles = new Dictionary<(int, int), List<int>>();

        // Build edge → triangles map
        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);

            var edges = new[]
            {
                MakeEdge(nodes[0], nodes[1]),
                MakeEdge(nodes[1], nodes[2]),
                MakeEdge(nodes[2], nodes[0])
            };

            foreach (var edge in edges)
            {
                if (!edgeToTriangles.ContainsKey(edge))
                    edgeToTriangles[edge] = new List<int>();
                edgeToTriangles[edge].Add(i);
            }
        }

        // Build triangle → triangles adjacency
        var adjacency = new Dictionary<int, List<int>>();

        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            adjacency[i] = new List<int>();
            var nodes = mesh.NodesOf<Tri3, Node>(i);

            var edges = new[]
            {
                MakeEdge(nodes[0], nodes[1]),
                MakeEdge(nodes[1], nodes[2]),
                MakeEdge(nodes[2], nodes[0])
            };

            foreach (var edge in edges)
            foreach (var neighbor in edgeToTriangles[edge])
                if (neighbor != i && !adjacency[i].Contains(neighbor))
                    adjacency[i].Add(neighbor);
        }

        return adjacency;
    }

    private static (int, int) MakeEdge(int v0, int v1)
    {
        return v0 < v1 ? (v0, v1) : (v1, v0);
    }

    #endregion

    #region Pairing Strategies

    /// <summary>
    ///     Pair triangles based on resulting quad quality.
    /// </summary>
    private static int PairByQuality(
        SimplexMesh mesh,
        double[,] coords,
        Dictionary<int, List<int>> adjacency,
        HashSet<int> converted,
        List<(int, int, int, int)> quads,
        double minQuality)
    {
        var count = 0;

        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            if (converted.Contains(i))
                continue;

            var nodesI = mesh.NodesOf<Tri3, Node>(i);

            var bestQuality = minQuality;
            var bestNeighbor = -1;
            var bestQuad = (0, 0, 0, 0);

            foreach (var j in adjacency[i])
            {
                if (converted.Contains(j))
                    continue;

                var nodesJ = mesh.NodesOf<Tri3, Node>(j);

                // Try to form quad
                var quadNodes = TryFormQuad(nodesI, nodesJ);
                if (!quadNodes.HasValue)
                    continue;

                // Check quad quality
                var quality = ComputeQuadQuality(coords,
                    quadNodes.Value.n0, quadNodes.Value.n1,
                    quadNodes.Value.n2, quadNodes.Value.n3);

                if (quality > bestQuality)
                {
                    bestQuality = quality;
                    bestNeighbor = j;
                    bestQuad = quadNodes.Value;
                }
            }

            if (bestNeighbor >= 0)
            {
                quads.Add(bestQuad);
                converted.Add(i);
                converted.Add(bestNeighbor);
                count++;
            }
        }

        return count;
    }

    /// <summary>
    ///     Pair triangles to optimize node valence (prefer valence 4).
    /// </summary>
    private static int PairByValence(
        SimplexMesh mesh,
        double[,] coords,
        Dictionary<int, List<int>> adjacency,
        HashSet<int> converted,
        List<(int, int, int, int)> quads,
        double minQuality)
    {
        // Compute node valence
        var valence = ComputeNodeValence(mesh, converted);

        var count = 0;

        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            if (converted.Contains(i))
                continue;

            var nodesI = mesh.NodesOf<Tri3, Node>(i);

            var bestNeighbor = -1;
            var bestScore = double.MinValue;
            var bestQuad = (0, 0, 0, 0);

            foreach (var j in adjacency[i])
            {
                if (converted.Contains(j))
                    continue;

                var nodesJ = mesh.NodesOf<Tri3, Node>(j);

                var quadNodes = TryFormQuad(nodesI, nodesJ);
                if (!quadNodes.HasValue)
                    continue;

                // Check quality
                var quality = ComputeQuadQuality(coords,
                    quadNodes.Value.n0, quadNodes.Value.n1,
                    quadNodes.Value.n2, quadNodes.Value.n3);

                if (quality < minQuality)
                    continue;

                // Compute valence score (prefer creating valence 4 nodes)
                double valenceScore = 0;
                var nodes = new[]
                {
                    quadNodes.Value.n0, quadNodes.Value.n1,
                    quadNodes.Value.n2, quadNodes.Value.n3
                };

                foreach (var node in nodes)
                {
                    var v = valence.GetValueOrDefault(node, 0);
                    // Prefer valence 3 → 4 or 5 → 4
                    if (v == 3 || v == 5)
                        valenceScore += 1.0;
                }

                var score = quality + 0.2 * valenceScore;

                if (score > bestScore)
                {
                    bestScore = score;
                    bestNeighbor = j;
                    bestQuad = quadNodes.Value;
                }
            }

            if (bestNeighbor >= 0)
            {
                quads.Add(bestQuad);
                converted.Add(i);
                converted.Add(bestNeighbor);
                count++;

                // Update valence
                var nodes = new[] { bestQuad.Item1, bestQuad.Item2, bestQuad.Item3, bestQuad.Item4 };
                foreach (var node in nodes) valence[node] = valence.GetValueOrDefault(node, 0) + 1;
            }
        }

        return count;
    }

    /// <summary>
    ///     Pair triangles based on edge alignment (prefer straight diagonal).
    /// </summary>
    private static int PairByGeometry(
        SimplexMesh mesh,
        double[,] coords,
        Dictionary<int, List<int>> adjacency,
        HashSet<int> converted,
        List<(int, int, int, int)> quads,
        double minQuality)
    {
        var count = 0;

        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            if (converted.Contains(i))
                continue;

            var nodesI = mesh.NodesOf<Tri3, Node>(i);

            foreach (var j in adjacency[i])
            {
                if (converted.Contains(j))
                    continue;

                var nodesJ = mesh.NodesOf<Tri3, Node>(j);

                var quadNodes = TryFormQuad(nodesI, nodesJ);
                if (!quadNodes.HasValue)
                    continue;

                var quality = ComputeQuadQuality(coords,
                    quadNodes.Value.n0, quadNodes.Value.n1,
                    quadNodes.Value.n2, quadNodes.Value.n3);

                if (quality >= minQuality)
                {
                    quads.Add(quadNodes.Value);
                    converted.Add(i);
                    converted.Add(j);
                    count++;
                    break; // Move to next triangle
                }
            }
        }

        return count;
    }

    #endregion

    #region Quad Formation and Quality

    /// <summary>
    ///     Try to form a quad from two adjacent triangles.
    ///     Returns quad nodes in CCW order if successful.
    /// </summary>
    private static (int n0, int n1, int n2, int n3)? TryFormQuad(
        IReadOnlyList<int> tri1,
        IReadOnlyList<int> tri2)
    {
        // Find shared edge
        var shared = FindSharedEdge(tri1, tri2);
        if (!shared.HasValue)
            return null;

        var (s0, s1) = shared.Value;

        // Find the two unique vertices
        int unique1 = -1, unique2 = -1;

        foreach (var v in tri1)
            if (v != s0 && v != s1)
            {
                unique1 = v;
                break;
            }

        foreach (var v in tri2)
            if (v != s0 && v != s1)
            {
                unique2 = v;
                break;
            }

        if (unique1 < 0 || unique2 < 0)
            return null;

        // Form quad in CCW order
        return (s0, unique1, s1, unique2);
    }

    /// <summary>
    ///     Find shared edge between two triangles.
    /// </summary>
    private static (int, int)? FindSharedEdge(
        IReadOnlyList<int> tri1,
        IReadOnlyList<int> tri2)
    {
        var edges1 = new[]
        {
            MakeEdge(tri1[0], tri1[1]),
            MakeEdge(tri1[1], tri1[2]),
            MakeEdge(tri1[2], tri1[0])
        };

        var edges2 = new[]
        {
            MakeEdge(tri2[0], tri2[1]),
            MakeEdge(tri2[1], tri2[2]),
            MakeEdge(tri2[2], tri2[0])
        };

        foreach (var e1 in edges1)
        foreach (var e2 in edges2)
            if (e1 == e2)
                return e1;

        return null;
    }

    /// <summary>
    ///     Compute quad quality metric (0-1, 1 = perfect square).
    ///     Based on aspect ratio and internal angles.
    /// </summary>
    private static double ComputeQuadQuality(
        double[,] coords,
        int n0, int n1, int n2, int n3)
    {
        // Check if quad is convex
        if (!IsQuadConvex(coords, n0, n1, n2, n3))
            return 0.0;

        // Compute edge lengths
        var e0 = Distance(coords, n0, n1);
        var e1 = Distance(coords, n1, n2);
        var e2 = Distance(coords, n2, n3);
        var e3 = Distance(coords, n3, n0);

        // Aspect ratio quality
        var minEdge = Math.Min(Math.Min(e0, e1), Math.Min(e2, e3));
        var maxEdge = Math.Max(Math.Max(e0, e1), Math.Max(e2, e3));

        if (maxEdge < EPSILON)
            return 0.0;

        var aspectRatio = minEdge / maxEdge;

        // Angle quality (prefer right angles)
        var angles = new double[4];
        angles[0] = ComputeAngle(coords, n3, n0, n1);
        angles[1] = ComputeAngle(coords, n0, n1, n2);
        angles[2] = ComputeAngle(coords, n1, n2, n3);
        angles[3] = ComputeAngle(coords, n2, n3, n0);

        double angleQuality = 0;
        foreach (var angle in angles)
        {
            var dev = Math.Abs(angle - 90.0);
            angleQuality += Math.Max(0, 1.0 - dev / 90.0);
        }

        angleQuality /= 4.0;

        // Combined quality
        return 0.5 * aspectRatio + 0.5 * angleQuality;
    }

    private static double Distance(double[,] coords, int n0, int n1)
    {
        var dx = coords[n1, 0] - coords[n0, 0];
        var dy = coords[n1, 1] - coords[n0, 1];
        return Math.Sqrt(dx * dx + dy * dy);
    }

    private static double ComputeAngle(double[,] coords, int a, int center, int b)
    {
        var ax = coords[a, 0] - coords[center, 0];
        var ay = coords[a, 1] - coords[center, 1];
        var bx = coords[b, 0] - coords[center, 0];
        var by = coords[b, 1] - coords[center, 1];

        var dot = ax * bx + ay * by;
        var lenA = Math.Sqrt(ax * ax + ay * ay);
        var lenB = Math.Sqrt(bx * bx + by * by);

        if (lenA < EPSILON || lenB < EPSILON)
            return 90.0;

        var cosAngle = Math.Clamp(dot / (lenA * lenB), -1.0, 1.0);
        return Math.Acos(cosAngle) * 180.0 / Math.PI;
    }

    #endregion
}