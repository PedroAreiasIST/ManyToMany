// CurveUtilities.cs - Unified curve and boundary operations
// Eliminates code duplication between UnifiedMesher and GeneralizedInterfaceMesher
// License: GPLv3

namespace Numerical;

/// <summary>
///     Curve and boundary manipulation utilities: refinement, resampling,
///     arc length computation, centroid calculation, orientation checking.
/// </summary>
public static class CurveUtilities
{
    private const double EPSILON = 1e-10;

    #region Boundary Refinement

    /// <summary>
    ///     Refines boundary edges to ensure good mesh quality.
    ///     Only subdivides edges that are too long relative to neighbors.
    ///     Preserves existing good points.
    /// </summary>
    /// <param name="boundary">Input boundary coordinates [n,2] or [n,3]</param>
    /// <param name="maxEdgeRatio">Maximum edge length ratio (default: 2.0)</param>
    /// <param name="minEdgeCount">Minimum total boundary edges (default: 200)</param>
    /// <returns>Refined boundary with additional points</returns>
    public static double[,] RefineBoundary(
        double[,] boundary,
        double maxEdgeRatio = 2.0,
        int minEdgeCount = 200)
    {
        var n = boundary.GetLength(0);
        var dim = boundary.GetLength(1);

        if (n < 3)
            return boundary;

        // Calculate all edge lengths
        var edgeLengths = new double[n];
        var totalLength = 0.0;
        var minLength = double.MaxValue;

        for (var i = 0; i < n; i++)
        {
            var j = (i + 1) % n;
            var length = Distance2D(boundary, i, j);
            edgeLengths[i] = length;
            totalLength += length;

            if (length > EPSILON && length < minLength)
                minLength = length;
        }

        if (totalLength < EPSILON)
            return boundary;

        // Calculate target edge length to meet minimum count
        var targetFromCount = totalLength / minEdgeCount;
        var targetFromRatio = maxEdgeRatio * minLength;
        var targetLength = Math.Min(targetFromCount, targetFromRatio);

        // Build refined boundary - subdivide only long edges
        var refinedPoints = new List<double[]>();

        for (var i = 0; i < n; i++)
        {
            var j = (i + 1) % n;

            // Always add the current point
            var currentPoint = new double[dim];
            for (var d = 0; d < dim; d++)
                currentPoint[d] = boundary[i, d];
            refinedPoints.Add(currentPoint);

            var edgeLength = edgeLengths[i];

            if (edgeLength < EPSILON)
                continue;

            // Subdivide if edge is too long
            if (edgeLength > targetLength * 1.01) // Small tolerance
            {
                var nSegments = Math.Max(1, (int)Math.Round(edgeLength / targetLength));

                // Add intermediate points
                for (var k = 1; k < nSegments; k++)
                {
                    var t = (double)k / nSegments;
                    var interpPoint = new double[dim];

                    for (var d = 0; d < dim; d++)
                        interpPoint[d] = boundary[i, d] + t * (boundary[j, d] - boundary[i, d]);

                    refinedPoints.Add(interpPoint);
                }
            }
        }

        // Convert to array
        var nRefined = refinedPoints.Count;
        var result = new double[nRefined, dim];

        for (var i = 0; i < nRefined; i++)
        for (var d = 0; d < dim; d++)
            result[i, d] = refinedPoints[i][d];

        return result;
    }

    #endregion

    #region Helper Functions

    private static double Distance2D(double[,] coords, int i, int j)
    {
        var dx = coords[j, 0] - coords[i, 0];
        var dy = coords[j, 1] - coords[i, 1];
        return Math.Sqrt(dx * dx + dy * dy);
    }

    #endregion

    #region Curve Resampling

    /// <summary>
    ///     Resample curve to have specified number of points uniformly distributed by arc length.
    /// </summary>
    public static List<(double x, double y)> ResampleCurve(
        List<(double x, double y)> curve,
        int targetPoints,
        bool closedCurve = false)
    {
        if (curve.Count >= targetPoints)
            return new List<(double x, double y)>(curve);

        // Compute total arc length
        double totalLength = 0;
        for (var i = 0; i < curve.Count - 1; i++)
        {
            var dx = curve[i + 1].x - curve[i].x;
            var dy = curve[i + 1].y - curve[i].y;
            totalLength += Math.Sqrt(dx * dx + dy * dy);
        }

        if (closedCurve)
        {
            var dx = curve[0].x - curve[^1].x;
            var dy = curve[0].y - curve[^1].y;
            totalLength += Math.Sqrt(dx * dx + dy * dy);
        }

        if (totalLength < EPSILON)
            return new List<(double x, double y)>(curve);

        // Resample at uniform arc length
        var targetSpacing = totalLength / (closedCurve ? targetPoints : targetPoints - 1);
        var resampled = new List<(double x, double y)> { curve[0] };

        double accumulatedLength = 0;
        var nextTarget = targetSpacing;

        for (var i = 0; i < curve.Count - 1; i++)
        {
            var dx = curve[i + 1].x - curve[i].x;
            var dy = curve[i + 1].y - curve[i].y;
            var segLength = Math.Sqrt(dx * dx + dy * dy);

            while (accumulatedLength + segLength >= nextTarget && resampled.Count < targetPoints - 1)
            {
                // Interpolate point
                var t = (nextTarget - accumulatedLength) / segLength;
                resampled.Add((
                    curve[i].x + t * dx,
                    curve[i].y + t * dy
                ));
                nextTarget += targetSpacing;
            }

            accumulatedLength += segLength;
        }

        // Add last point if not closed or if we haven't reached target count
        if (!closedCurve || resampled.Count < targetPoints) resampled.Add(curve[^1]);

        return resampled;
    }

    /// <summary>
    ///     Resample curve from array format.
    /// </summary>
    public static double[,] ResampleCurveArray(
        double[,] curve,
        int targetPoints,
        bool closedCurve = false)
    {
        var curveList = ExtractCurve2D(curve);
        var resampled = ResampleCurve(curveList, targetPoints, closedCurve);

        var result = new double[resampled.Count, 2];
        for (var i = 0; i < resampled.Count; i++)
        {
            result[i, 0] = resampled[i].x;
            result[i, 1] = resampled[i].y;
        }

        return result;
    }

    #endregion

    #region Arc Length and Geometry

    /// <summary>
    ///     Compute total arc length of a curve.
    /// </summary>
    public static double ComputeArcLength(List<(double x, double y)> curve, bool closedCurve = false)
    {
        double length = 0;

        for (var i = 0; i < curve.Count - 1; i++)
        {
            var dx = curve[i + 1].x - curve[i].x;
            var dy = curve[i + 1].y - curve[i].y;
            length += Math.Sqrt(dx * dx + dy * dy);
        }

        if (closedCurve && curve.Count > 0)
        {
            var dx = curve[0].x - curve[^1].x;
            var dy = curve[0].y - curve[^1].y;
            length += Math.Sqrt(dx * dx + dy * dy);
        }

        return length;
    }

    /// <summary>
    ///     Compute average edge length of a boundary.
    /// </summary>
    public static double ComputeAverageEdgeLength(double[,] boundary)
    {
        var n = boundary.GetLength(0);
        if (n < 2)
            return 0;

        double totalLength = 0;
        for (var i = 0; i < n; i++)
        {
            var j = (i + 1) % n;
            totalLength += Distance2D(boundary, i, j);
        }

        return totalLength / n;
    }

    /// <summary>
    ///     Compute centroid of a boundary.
    /// </summary>
    public static (double x, double y) ComputeCentroid(double[,] boundary)
    {
        var n = boundary.GetLength(0);
        if (n == 0)
            return (0, 0);

        double sumX = 0, sumY = 0;
        for (var i = 0; i < n; i++)
        {
            sumX += boundary[i, 0];
            sumY += boundary[i, 1];
        }

        return (sumX / n, sumY / n);
    }

    /// <summary>
    ///     Compute signed area of a boundary (2D).
    ///     Positive = CCW, negative = CW.
    /// </summary>
    public static double ComputeSignedArea(double[,] boundary)
    {
        var n = boundary.GetLength(0);
        if (n < 3)
            return 0;

        double area = 0;
        for (var i = 0; i < n; i++)
        {
            var j = (i + 1) % n;
            area += boundary[i, 0] * boundary[j, 1] - boundary[j, 0] * boundary[i, 1];
        }

        return area / 2.0;
    }

    #endregion

    #region Orientation

    /// <summary>
    ///     Check if boundary has counter-clockwise (CCW) orientation.
    /// </summary>
    public static bool IsBoundaryCCW(double[,] boundary)
    {
        return ComputeSignedArea(boundary) > 0;
    }

    /// <summary>
    ///     Reverse boundary orientation.
    /// </summary>
    public static double[,] ReverseBoundary(double[,] boundary)
    {
        var n = boundary.GetLength(0);
        var dim = boundary.GetLength(1);
        var reversed = new double[n, dim];

        for (var i = 0; i < n; i++)
        for (var d = 0; d < dim; d++)
            reversed[i, d] = boundary[n - 1 - i, d];

        return reversed;
    }

    /// <summary>
    ///     Ensure boundary has CCW orientation (reverse if needed).
    /// </summary>
    public static double[,] EnsureCCW(double[,] boundary)
    {
        return IsBoundaryCCW(boundary) ? boundary : ReverseBoundary(boundary);
    }

    /// <summary>
    ///     Ensure boundary has CW orientation (reverse if needed).
    /// </summary>
    public static double[,] EnsureCW(double[,] boundary)
    {
        return IsBoundaryCCW(boundary) ? ReverseBoundary(boundary) : boundary;
    }

    #endregion

    #region Conversion Utilities

    /// <summary>
    ///     Extract 2D curve from array format to list of tuples.
    /// </summary>
    public static List<(double x, double y)> ExtractCurve2D(double[,] curve)
    {
        var points = new List<(double x, double y)>();
        var n = curve.GetLength(0);

        for (var i = 0; i < n; i++) points.Add((curve[i, 0], curve[i, 1]));

        return points;
    }

    /// <summary>
    ///     Convert list of tuples to array format.
    /// </summary>
    public static double[,] ConvertToArray(List<(double x, double y)> curve, int dim = 2)
    {
        var n = curve.Count;
        var result = new double[n, dim];

        for (var i = 0; i < n; i++)
        {
            result[i, 0] = curve[i].x;
            result[i, 1] = curve[i].y;

            if (dim > 2)
                for (var d = 2; d < dim; d++)
                    result[i, d] = 0;
        }

        return result;
    }

    #endregion
}
