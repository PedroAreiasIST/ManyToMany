// MeshGeneration.cs - Standard mesh generation patterns
// Rectangular, box, and structured mesh generators
// License: GPLv3

using System;

namespace Numerical;

/// <summary>
/// Standard structured mesh generation: rectangular 2D meshes, box 3D meshes.
/// Provides common mesh patterns for testing and simple geometries.
/// </summary>
public static class MeshGeneration
{
    #region 2D Rectangular Meshes
    
    /// <summary>
    /// Creates a rectangular triangular mesh.
    /// Generates a structured grid with 2 triangles per quad cell.
    /// </summary>
    /// <param name="nx">Number of divisions in x direction</param>
    /// <param name="ny">Number of divisions in y direction</param>
    /// <param name="xMin">Minimum x coordinate</param>
    /// <param name="xMax">Maximum x coordinate</param>
    /// <param name="yMin">Minimum y coordinate</param>
    /// <param name="yMax">Maximum y coordinate</param>
    /// <returns>Mesh and coordinates array [n,3] (z=0)</returns>
    public static (SimplexMesh Mesh, double[,] Coordinates) CreateRectangularMesh(
        int nx, int ny,
        double xMin, double xMax,
        double yMin, double yMax)
    {
        var mesh = new SimplexMesh();
        var coords = new double[(nx + 1) * (ny + 1), 3];
        
        double dx = (xMax - xMin) / nx;
        double dy = (yMax - yMin) / ny;
        
        mesh.WithBatch(() =>
        {
            // Create nodes
            for (int j = 0; j <= ny; j++)
            {
                for (int i = 0; i <= nx; i++)
                {
                    int idx = j * (nx + 1) + i;
                    coords[idx, 0] = xMin + i * dx;
                    coords[idx, 1] = yMin + j * dy;
                    coords[idx, 2] = 0.0;
                    mesh.AddNode(idx);
                }
            }
            
            // Create triangles (2 per quad cell)
            for (int j = 0; j < ny; j++)
            {
                for (int i = 0; i < nx; i++)
                {
                    int n0 = j * (nx + 1) + i;        // bottom-left
                    int n1 = n0 + 1;                   // bottom-right
                    int n2 = n0 + (nx + 1);            // top-left
                    int n3 = n2 + 1;                   // top-right
                    
                    // Standard 2-triangle quad with diagonal n1-n2
                    mesh.AddTriangle(n0, n1, n2);
                    mesh.AddTriangle(n1, n3, n2);
                }
            }
        });
        
        return (mesh, coords);
    }
    
    /// <summary>
    /// Creates a rectangular quadrilateral mesh.
    /// </summary>
    public static (SimplexMesh Mesh, double[,] Coordinates) CreateRectangularQuadMesh(
        int nx, int ny,
        double xMin, double xMax,
        double yMin, double yMax)
    {
        var mesh = new SimplexMesh();
        var coords = new double[(nx + 1) * (ny + 1), 3];
        
        double dx = (xMax - xMin) / nx;
        double dy = (yMax - yMin) / ny;
        
        mesh.WithBatch(() =>
        {
            // Create nodes
            for (int j = 0; j <= ny; j++)
            {
                for (int i = 0; i <= nx; i++)
                {
                    int idx = j * (nx + 1) + i;
                    coords[idx, 0] = xMin + i * dx;
                    coords[idx, 1] = yMin + j * dy;
                    coords[idx, 2] = 0.0;
                    mesh.AddNode(idx);
                }
            }
            
            // Create quads
            for (int j = 0; j < ny; j++)
            {
                for (int i = 0; i < nx; i++)
                {
                    int n0 = j * (nx + 1) + i;        // bottom-left
                    int n1 = n0 + 1;                   // bottom-right
                    int n2 = n0 + (nx + 1);            // top-left
                    int n3 = n2 + 1;                   // top-right
                    
                    mesh.AddQuad(n0, n1, n3, n2);      // CCW order
                }
            }
        });
        
        return (mesh, coords);
    }
    
    #endregion
    
    #region 3D Box Meshes
    
    /// <summary>
    /// Creates a 3D box mesh with tetrahedral elements using prismatic extrusion.
    /// The base is a 2D triangular mesh that is extruded in the z-direction.
    /// Each triangular prism is split into 3 tetrahedra.
    /// This ensures horizontal (xy) faces are clean triangles - perfect for horizontal crack planes.
    /// </summary>
    /// <param name="nx">Number of divisions in x direction</param>
    /// <param name="ny">Number of divisions in y direction</param>
    /// <param name="nz">Number of divisions in z direction</param>
    public static (SimplexMesh Mesh, double[,] Coordinates) CreateBoxMesh(
        int nx, int ny, int nz,
        double xMin, double xMax,
        double yMin, double yMax,
        double zMin, double zMax)
    {
        var mesh = new SimplexMesh();
        int nodeCount = (nx + 1) * (ny + 1) * (nz + 1);
        var coords = new double[nodeCount, 3];
        
        double dx = (xMax - xMin) / nx;
        double dy = (yMax - yMin) / ny;
        double dz = (zMax - zMin) / nz;
        
        // Node indexing: node(i, j, k) = k * (nx+1)*(ny+1) + j * (nx+1) + i
        int NodeIndex(int i, int j, int k) => k * (nx + 1) * (ny + 1) + j * (nx + 1) + i;
        
        mesh.WithBatch(() =>
        {
            // Create nodes
            for (int k = 0; k <= nz; k++)
            {
                for (int j = 0; j <= ny; j++)
                {
                    for (int i = 0; i <= nx; i++)
                    {
                        int idx = NodeIndex(i, j, k);
                        coords[idx, 0] = xMin + i * dx;
                        coords[idx, 1] = yMin + j * dy;
                        coords[idx, 2] = zMin + k * dz;
                        mesh.AddNode(idx);
                    }
                }
            }
            
            // Create tetrahedra - body-diagonal Kuhn subdivision (6 tets per cube)
            // Splits along body diagonal n0 to n7, guarantees positive Jacobians
            for (int k = 0; k < nz; k++)
            {
                for (int j = 0; j < ny; j++)
                {
                    for (int i = 0; i < nx; i++)
                    {
                        // Cube vertices (standard numbering)
                        int n0 = NodeIndex(i, j, k);
                        int n1 = NodeIndex(i + 1, j, k);
                        int n2 = NodeIndex(i, j + 1, k);
                        int n3 = NodeIndex(i + 1, j + 1, k);
                        int n4 = NodeIndex(i, j, k + 1);
                        int n5 = NodeIndex(i + 1, j, k + 1);
                        int n6 = NodeIndex(i, j + 1, k + 1);
                        int n7 = NodeIndex(i + 1, j + 1, k + 1);
                        
                        // Body-diagonal subdivision (6 tets, all with positive Jacobian)
                        mesh.AddTetrahedron(n0, n1, n3, n7);
                        mesh.AddTetrahedron(n0, n3, n2, n7);
                        mesh.AddTetrahedron(n0, n2, n6, n7);
                        mesh.AddTetrahedron(n0, n6, n4, n7);
                        mesh.AddTetrahedron(n0, n4, n5, n7);
                        mesh.AddTetrahedron(n0, n5, n1, n7);
                    }
                }
            }
        });
        
        // Fix any inverted tets by swapping nodes
        FixInvertedTetrahedra(mesh, coords);
        
        Console.WriteLine($"[CreateBoxMesh] Created {mesh.Count<Node>()} nodes, {mesh.Count<Tet4>()} tetrahedra");
        Console.WriteLine($"[CreateBoxMesh] Dimensions: [{xMin},{xMax}] × [{yMin},{yMax}] × [{zMin},{zMax}]");
        Console.WriteLine($"[CreateBoxMesh] Resolution: {nx} × {ny} × {nz} cells");
        
        return (mesh, coords);
    }
    
    private static void FixInvertedTetrahedra(SimplexMesh mesh, double[,] coords)
    {
        int fixedCount = 0;
        var tetsToFix = new List<(int index, int[] nodes)>();
        
        // First pass: identify inverted tets
        for (int i = 0; i < mesh.Count<Tet4>(); i++)
        {
            var nodes = mesh.NodesOf<Tet4, Node>(i);
            double jac = ComputeTetrahedronJacobian(coords, nodes[0], nodes[1], nodes[2], nodes[3]);
            
            if (jac <= 0)
            {
                // Store inverted tet with swapped nodes
                tetsToFix.Add((i, new[] { nodes[1], nodes[0], nodes[2], nodes[3] }));
            }
        }
        
        // Second pass: remove and recreate inverted tets
        // Note: We need to remove from highest index to lowest to avoid index shifting
        tetsToFix.Sort((a, b) => b.index.CompareTo(a.index));
        
        foreach (var (index, swappedNodes) in tetsToFix)
        {
            mesh.Remove<Tet4>(index);
            mesh.AddTetrahedron(swappedNodes[0], swappedNodes[1], swappedNodes[2], swappedNodes[3]);
            fixedCount++;
        }
        
        if (fixedCount > 0)
            Console.WriteLine($"[CreateBoxMesh] Fixed {fixedCount} inverted tetrahedra by swapping nodes");
    }

    private static double ComputeTetrahedronJacobian(double[,] coords, int n0, int n1, int n2, int n3)
    {
        // Compute signed volume * 6 (Jacobian determinant)
        double x0 = coords[n0, 0], y0 = coords[n0, 1], z0 = coords[n0, 2];
        double x1 = coords[n1, 0], y1 = coords[n1, 1], z1 = coords[n1, 2];
        double x2 = coords[n2, 0], y2 = coords[n2, 1], z2 = coords[n2, 2];
        double x3 = coords[n3, 0], y3 = coords[n3, 1], z3 = coords[n3, 2];
        
        // Edge vectors from n0
        double v1x = x1 - x0, v1y = y1 - y0, v1z = z1 - z0;
        double v2x = x2 - x0, v2y = y2 - y0, v2z = z2 - z0;
        double v3x = x3 - x0, v3y = y3 - y0, v3z = z3 - z0;
        
        // Determinant = v1 · (v2 × v3)
        return v1x * (v2y * v3z - v2z * v3y)
             - v1y * (v2x * v3z - v2z * v3x)
             + v1z * (v2x * v3y - v2y * v3x);
    }
    
    #endregion
    
    #region Utility Methods
    
    /// <summary>
    /// Create a unit square mesh [0,1] × [0,1].
    /// </summary>
    public static (SimplexMesh Mesh, double[,] Coordinates) CreateUnitSquareMesh(int n)
    {
        return CreateRectangularMesh(n, n, 0.0, 1.0, 0.0, 1.0);
    }
    
    /// <summary>
    /// Create a unit cube mesh [0,1]³.
    /// </summary>
    public static (SimplexMesh Mesh, double[,] Coordinates) CreateUnitCubeMesh(int n)
    {
        return CreateBoxMesh(n, n, n, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0);
    }
    
    #endregion
}
