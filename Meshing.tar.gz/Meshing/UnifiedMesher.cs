// UnifiedMesher - Complete 2D meshing solution with advanced quad optimization
// Combines best algorithms from DelaunayMesher + MeshOptimizer
// Version: 2026-01-25 Final
// License: GPLv3

namespace Numerical;

/// <summary>
///     Unified meshing engine combining:
///     - Bowyer-Watson Delaunay triangulation
///     - CVT smoothing (area-weighted, superior to Laplacian)
///     - Multi-strategy quad conversion (quality + valence + geometry)
///     - Quad diagonal swapping and triangle absorption
///     - MATLAB-compatible quality metrics
///     Generates high-quality triangular or quad-dominant meshes.
/// </summary>
// PERFORMANCE NOTES:
// - CVT smoothing: 5 iterations (balance quality vs speed)
// - Quad optimization: 2 passes (reduces O(n²) operations)
// - For large meshes (10k+ nodes): reduce iterations to 3, passes to 1
// - For small meshes (<1k nodes): increase to 10 iterations, 3 passes
// - Typical timing: ~1-2 seconds for 1000 nodes with quads
public static class UnifiedMesher
{
    private const double EPSILON = 1e-10;

    #region Public API

    /// <summary>
    ///     Generate Delaunay triangulation for a 2D polygon.
    ///     Element sizes adapt to boundary edge lengths when sizeGradation > 0.
    /// </summary>
    /// <param name="boundaryCoords">Boundary vertices in CCW order [n,3] (z=0)</param>
    /// <param name="interiorCoords">Optional interior points for refinement</param>
    /// <param name="refine">Enable Ruppert refinement</param>
    /// <param name="maxArea">Maximum triangle area (0 = auto, ignored if sizeGradation > 0)</param>
    /// <param name="sizeGradation">Size gradation factor (0 = use maxArea, >0 = adaptive from boundaries)</param>
    /// <param name="convertToQuads">Convert triangles to quads (false = pure TRI for crack insertion/refinement)</param>
    /// <returns>Mesh with Tri3 or mixed Quad4+Tri3 elements and coordinate array</returns>
    public static (SimplexMesh mesh, double[,] coords) Triangulate(
        double[,] boundaryCoords,
        double[,]? interiorCoords = null,
        bool refine = true,
        double maxArea = 0.0,
        double sizeGradation = 1.3,
        bool convertToQuads = true,
        bool enableSmoothing = true)
    {
        return TriangulateWithHoles(boundaryCoords, null, interiorCoords, refine, maxArea, sizeGradation,
            convertToQuads, enableSmoothing);
    }

    /// <summary>
    ///     Generate Delaunay triangulation for a 2D polygon with holes/voids.
    ///     Element sizes adapt to boundary edge lengths when sizeGradation > 0.
    /// </summary>
    /// <param name="outerBoundary">Outer boundary vertices in CCW order [n,3]</param>
    /// <param name="holes">List of hole boundaries, each in CW order (null = no holes)</param>
    /// <param name="interiorCoords">Optional interior points for refinement</param>
    /// <param name="refine">Enable Ruppert refinement</param>
    /// <param name="maxArea">Maximum triangle area (0 = auto, ignored if sizeGradation > 0)</param>
    /// <param name="sizeGradation">Size gradation factor (0 = use maxArea, >0 = adaptive from boundaries, recommend 1.3)</param>
    /// <param name="convertToQuads">Convert triangles to quads (false = pure TRI for crack insertion/refinement)</param>
    /// <returns>Mesh with Tri3 or mixed Quad4+Tri3 elements and coordinate array</returns>
    public static (SimplexMesh mesh, double[,] coords) TriangulateWithHoles(
        double[,] outerBoundary,
        List<double[,]>? holes = null,
        double[,]? interiorCoords = null,
        bool refine = true,
        double maxArea = 0.0,
        double sizeGradation = 1.3,
        bool convertToQuads = true,
        bool enableSmoothing = true)
    {
        Console.WriteLine("\n=== TRIANGULATION START ===");
        Console.WriteLine($"Input: {outerBoundary.GetLength(0)} boundary points");
        Console.WriteLine($"Refine: {refine}, SizeGradation: {sizeGradation}");

        // Verify and fix outer boundary orientation
        if (!IsBoundaryCCW(outerBoundary))
        {
            Console.WriteLine("  ⚠️  Outer boundary is CW, reversing to CCW");
            outerBoundary = ReverseBoundary(outerBoundary);
        }

        // ═══════════════════════════════════════════════════════════════════
        // BOUNDARY REFINEMENT - DISABLED (causes topology errors)
        // ═══════════════════════════════════════════════════════════════════
        // User should provide adequate boundary resolution

        // CRITICAL: Store ORIGINAL boundary for polygon tests
        var originalOuterBoundary = (double[,])outerBoundary.Clone();

        var nOuter = outerBoundary.GetLength(0);
        // NO REFINEMENT - use boundaries as provided by user
        Console.WriteLine($"  Outer boundary: {nOuter} points (no auto-refinement)");
        var nHoleVerts = 0;
        List<(double x, double y)> holeSeeds = new();

        // Process holes
        if (holes != null && holes.Count > 0)
            for (var h = 0; h < holes.Count; h++)
            {
                var hole = holes[h];

                // Verify hole is CW (as it should be)
                if (IsBoundaryCCW(hole))
                {
                    Console.WriteLine($"  ⚠️  Hole {h} is CCW, reversing to CW");
                    holes[h] = ReverseBoundary(hole);
                    hole = holes[h];
                }

                // NO REFINEMENT - use hole boundaries as provided
                Console.WriteLine($"  Hole {h}: {hole.GetLength(0)} points (no auto-refinement)");

                nHoleVerts += hole.GetLength(0);

                // Get seed point for this hole (centroid)
                holeSeeds.Add(GetBoundaryCentroid(hole));
            }

        // Store hole boundaries for removal (we need them, not just seeds!)
        List<List<(double x, double y)>> holeBoundaries = new();
        if (holes != null)
            foreach (var hole in holes)
            {
                var boundary = new List<(double x, double y)>();
                for (var i = 0; i < hole.GetLength(0); i++) boundary.Add((hole[i, 0], hole[i, 1]));
                holeBoundaries.Add(boundary);
            }

        var nInterior = interiorCoords?.GetLength(0) ?? 0;
        var totalBoundary = nOuter + nHoleVerts;

        // Combine all points (outer boundary + hole boundaries + interior points)
        var points = new List<(double x, double y)>();

        // Add outer boundary
        for (var i = 0; i < nOuter; i++) points.Add((outerBoundary[i, 0], outerBoundary[i, 1]));

        // Add hole boundaries
        if (holes != null)
            foreach (var hole in holes)
                for (var i = 0; i < hole.GetLength(0); i++)
                    points.Add((hole[i, 0], hole[i, 1]));

        // Add interior points
        if (interiorCoords != null)
        {
            for (var i = 0; i < nInterior; i++) points.Add((interiorCoords[i, 0], interiorCoords[i, 1]));
        }
        else
        {
            // ALWAYS add at least center point to avoid degenerate triangulation
            var centroid = GetBoundaryCentroid(outerBoundary);
            points.Add(centroid);
            Console.WriteLine($"  ⊕ Added center point: ({centroid.x:F2}, {centroid.y:F2})");

            // ALWAYS add a minimal interior grid to prevent spoke patterns
            // Even with refine=false, we need at least a 3x3 grid for quality
            var avgBoundaryEdge = CalculateAverageBoundaryEdgeLength(outerBoundary, holes);
            var spacing = avgBoundaryEdge * (refine && sizeGradation > 0 ? 1.5 : 2.5);

            var autoInterior = GenerateInteriorGrid(outerBoundary, holes, spacing);
            points.AddRange(autoInterior);
            Console.WriteLine($"  ⊕ Generated {autoInterior.Count} interior points (spacing: {spacing:F2})");
        }

        // NOW compute totalPoints after all points added
        var totalPoints = points.Count;

        // Compute bounding box for super-triangle
        var minX = points.Min(p => p.x);
        var maxX = points.Max(p => p.x);
        var minY = points.Min(p => p.y);
        var maxY = points.Max(p => p.y);

        var dx = maxX - minX;
        var dy = maxY - minY;
        var dmax = Math.Max(dx, dy);
        var midX = (minX + maxX) / 2;
        var midY = (minY + maxY) / 2;

        // Super-triangle (large enough to contain all points)
        var superTri = new[]
        {
            (midX - 20 * dmax, midY - dmax),
            (midX, midY + 20 * dmax),
            (midX + 20 * dmax, midY - dmax)
        };

        points.AddRange(superTri);
        var superIdx0 = totalPoints;

        Console.WriteLine($"  → Total points for triangulation: {points.Count}");
        Console.WriteLine("  → Starting Bowyer-Watson algorithm...");

        // Bowyer-Watson algorithm
        var triangles = new List<(int v0, int v1, int v2)>
        {
            (superIdx0, superIdx0 + 1, superIdx0 + 2)
        };

        var circumcenters = new List<(double x, double y, double rSq)>
        {
            ComputeCircumcircle(points, superIdx0, superIdx0 + 1, superIdx0 + 2)
        };

        // Incrementally add points
        for (var i = 0; i < totalPoints; i++) AddPoint(i, points, triangles, circumcenters);

        // Remove triangles containing super-triangle vertices
        var validTriangles = new List<(int, int, int)>();
        for (var i = 0; i < triangles.Count; i++)
        {
            var (v0, v1, v2) = triangles[i];
            if (v0 < totalPoints && v1 < totalPoints && v2 < totalPoints) validTriangles.Add((v0, v1, v2));
        }

        Console.WriteLine($"  → After Bowyer-Watson: {triangles.Count} raw triangles");
        Console.WriteLine($"  → After removing super-triangle: {validTriangles.Count} triangles");

        // Check cross product range for diagnostics
        var minCross = double.MaxValue;
        var maxCross = double.MinValue;
        foreach (var (v0, v1, v2) in validTriangles)
        {
            var ax = points[v1].x - points[v0].x;
            var ay = points[v1].y - points[v0].y;
            var bx = points[v2].x - points[v0].x;
            var by = points[v2].y - points[v0].y;
            var cross = ax * by - ay * bx;
            minCross = Math.Min(minCross, cross);
            maxCross = Math.Max(maxCross, cross);
        }

        Console.WriteLine($"  → Cross product range: [{minCross:E3}, {maxCross:E3}]");

        // NOTE: Don't filter by orientation here - Bowyer-Watson can produce mixed orientations
        // We'll fix orientation when building the SimplexMesh

        // Remove triangles outside polygon - use ORIGINAL boundary for robust test
        var beforeExterior = validTriangles.Count;
        validTriangles = RemoveExteriorTriangles(validTriangles, points, originalOuterBoundary);
        Console.WriteLine(
            $"  → After removing exterior: {validTriangles.Count} triangles (removed {beforeExterior - validTriangles.Count})");

        if (validTriangles.Count == 0)
        {
            Console.WriteLine("  ⚠️  WARNING: All triangles were removed by exterior filtering!");
            Console.WriteLine("     This indicates the polygon test is too strict or polygon has wrong orientation.");
        }

        // Remove triangles inside holes
        if (holeBoundaries.Count > 0)
        {
            validTriangles = RemoveTrianglesInHoles(validTriangles, points, holeBoundaries);
            Console.WriteLine($"  → After removing holes: {validTriangles.Count} triangles");
        }

        // Build size function from boundary edges if adaptive sizing requested
        SizeFunction? sizeFunction = null;
        if (refine && sizeGradation > 0)
            sizeFunction = BuildSizeFunctionFromBoundaries(outerBoundary, holes, sizeGradation);

        // REFINEMENT DISABLED FOR UNIFORM MESHES
        // Ruppert refinement creates size variation - instead rely on:
        // 1. Uniform hexagonal interior grid
        // 2. CVT smoothing for quality
        // Result: Truly uniform element sizes throughout domain
        /*
        if (refine)
        {
            if (sizeFunction != null)
            {
                // Adaptive refinement based on boundary edge sizes
                (points, validTriangles) = RuppertRefinementAdaptive(
                    points.Take(totalPoints).ToList(),
                    validTriangles,
                    nOuter,
                    sizeFunction);
            }
            else
            {
                // Standard refinement with fixed maxArea
                (points, validTriangles) = RuppertRefinement(
                    points.Take(totalPoints).ToList(),
                    validTriangles,
                    nOuter,
                    maxArea);
            }
            totalPoints = points.Count;
        }
        */

        // Build SimplexMesh
        var mesh = new SimplexMesh();
        var coords = new double[totalPoints, 3];

        // CRITICAL: Track boundary node indices BEFORE triangulation
        // First nOuter nodes are outer boundary, next nHoleVerts are holes
        var boundaryNodeIndices = new HashSet<int>();
        for (var i = 0; i < nOuter + nHoleVerts; i++) boundaryNodeIndices.Add(i);
        Console.WriteLine($"  → Boundary tracking: {boundaryNodeIndices.Count} boundary nodes marked");

        mesh.WithBatch(() =>
        {
            // Add nodes
            for (var i = 0; i < totalPoints; i++)
            {
                coords[i, 0] = points[i].x;
                coords[i, 1] = points[i].y;
                coords[i, 2] = 0.0;
                mesh.AddNode(i);
            }

            // Add triangles - fix orientation to ensure all are CCW
            var flipped = 0;
            foreach (var (v0, v1, v2) in validTriangles)
            {
                // Check orientation
                var ax = points[v1].x - points[v0].x;
                var ay = points[v1].y - points[v0].y;
                var bx = points[v2].x - points[v0].x;
                var by = points[v2].y - points[v0].y;
                var cross = ax * by - ay * bx;

                if (cross < 0)
                {
                    // CW triangle - flip to CCW
                    mesh.AddTriangle(v0, v2, v1);
                    flipped++;
                }
                else if (cross > EPSILON)
                {
                    // Already CCW
                    mesh.AddTriangle(v0, v1, v2);
                }
                // Skip degenerate triangles (cross ≈ 0)
            }

            if (flipped > 0) Console.WriteLine($"  → Flipped {flipped} triangles to CCW orientation");
        });

        // DEBUG: Verify triangles were added
        Console.WriteLine($"  → SimplexMesh built: {mesh.Count<Node>()} nodes, {mesh.Count<Tri3>()} triangles");

        if (mesh.Count<Tri3>() == 0)
        {
            Console.WriteLine("  ⚠️  CRITICAL ERROR: No triangles in mesh after building!");
            Console.WriteLine($"     validTriangles.Count = {validTriangles.Count}");
            Console.WriteLine("     This indicates a problem in mesh construction.");
        }

        // Automatic quality improvement for adaptive sizing
        if (refine && sizeGradation > 0)
        {
            Console.WriteLine("  🔧 Automatic mesh optimization (set-and-forget mode)");

            // Phase 1: Triangle topology optimization
            var triFlips = EdgeFlipping(mesh, coords, 20.0);
            var nodeInserts = NodeInsertion(mesh, coords, 20.0);

            // Phase 2: Initial CVT smoothing (better than Laplacian)
            if (enableSmoothing) CVTSmoothing(mesh, coords, 3); // Reduced from 5 to 3 for speed

            // Validate: Remove any inverted triangles created by smoothing
            var nInvertedInitial = RemoveInvertedTriangles(mesh, coords);
            if (nInvertedInitial > 0)
            {
                Console.WriteLine($"  ⚠️  WARNING: {nInvertedInitial} inverted triangles detected after smoothing!");
                Console.WriteLine("      This indicates a bug - smoothing should have prevented this.");
            }

            // Phase 3: Convert to quads (ONLY if requested)
            Console.WriteLine($"     DEBUG: convertToQuads = {convertToQuads}");
            if (convertToQuads)
            {
                Console.WriteLine("     🔷 Multi-pass quad conversion (progressive relaxation)");

                // Multi-pass conversion: start strict, progressively relax
                var currentMesh = mesh;
                var currentCoords = coords;
                var totalQuadsCreated = 0;

                // Pass 1: Strict quality (only best quads)
                Console.WriteLine("        Pass 1: Strict (minAngle≥25°, maxAngle≤155°)");
                var (mesh1, coords1) = ConvertToQuadsAutomaticWithThresholds(currentMesh, currentCoords, 25, 155);
                var pass1Quads = mesh1.Count<Quad4>();
                totalQuadsCreated += pass1Quads;
                Console.WriteLine($"          Created {pass1Quads} quads");

                // Pass 2: Relaxed (current default)
                Console.WriteLine("        Pass 2: Relaxed (minAngle≥20°, maxAngle≤160°)");
                var (mesh2, coords2) = ConvertToQuadsAutomaticWithThresholds(mesh1, coords1, 20, 160);
                var pass2Quads = mesh2.Count<Quad4>() - pass1Quads;
                totalQuadsCreated += pass2Quads;
                Console.WriteLine($"          Created {pass2Quads} additional quads");

                // Pass 3: Very relaxed (grab remaining opportunities)
                Console.WriteLine("        Pass 3: Aggressive (minAngle≥15°, maxAngle≤165°)");
                var (mesh3, coords3) = ConvertToQuadsAutomaticWithThresholds(mesh2, coords2, 15, 165);
                var pass3Quads = mesh3.Count<Quad4>() - pass1Quads - pass2Quads;
                totalQuadsCreated += pass3Quads;
                Console.WriteLine($"          Created {pass3Quads} additional quads");

                Console.WriteLine(
                    $"        Multi-pass total: {totalQuadsCreated} quads, {mesh3.Count<Tri3>()} tris remaining");

                var quadMesh = mesh3;
                var quadCoords = coords3;

                // ========== PHASE 2: VALENCE-DRIVEN OPTIMIZATION ==========
                Console.WriteLine("     🔶 Phase 2: Valence-driven quad conversion");

                // Additional pass with valence-priority scoring
                Console.WriteLine("        Valence-optimized conversion (prioritize valence-6 reduction)...");
                var (meshValence, coordsValence) = ConvertWithValencePriority(quadMesh, quadCoords);
                var valenceQuads = meshValence.Count<Quad4>() - quadMesh.Count<Quad4>();
                Console.WriteLine($"          Created {valenceQuads} additional quads");
                quadMesh = meshValence;
                quadCoords = coordsValence;

                // ========== PHASE 3: ULTRA-AGGRESSIVE FINAL PASS ==========
                Console.WriteLine("     🔷 Phase 3: Ultra-aggressive final pass");

                // Final pass with very relaxed thresholds
                Console.WriteLine("        Final sweep (minAngle≥10°, maxAngle≤170°)...");
                var (meshFinal, coordsFinal) = ConvertToQuadsAutomaticWithThresholds(quadMesh, quadCoords, 10, 170);
                var finalPassQuads = meshFinal.Count<Quad4>() - quadMesh.Count<Quad4>();
                Console.WriteLine($"          Created {finalPassQuads} additional quads");
                quadMesh = meshFinal;
                quadCoords = coordsFinal;

                // Boundary-first pass (if any triangles remain)
                if (quadMesh.Count<Tri3>() > 0)
                {
                    Console.WriteLine("        Boundary optimization...");
                    var (meshBoundary, coordsBoundary) = ConvertBoundaryTriangles(quadMesh, quadCoords);
                    var boundaryQuads = meshBoundary.Count<Quad4>() - quadMesh.Count<Quad4>();
                    Console.WriteLine($"          Created {boundaryQuads} additional quads");
                    quadMesh = meshBoundary;
                    quadCoords = coordsBoundary;
                }

                // ========== PHASE 4: NODE REMOVAL (DISABLED - creates voids) ==========
                // TODO: Fix valence-3 node removal to avoid creating holes
                // The issue: removing nodes can disconnect mesh regions
                /*
                Console.WriteLine("     🔶 Phase 4: Node removal (valence-3 simplification)");

                var (meshSimplified, coordsSimplified) = RemoveValence3Nodes(quadMesh, quadCoords);
                int nodesRemoved = quadMesh.Count<Node>() - meshSimplified.Count<Node>();
                Console.WriteLine($"        Removed {nodesRemoved} valence-3 nodes");

                if (nodesRemoved > 0)
                {
                    Console.WriteLine("        Post-simplification quad conversion...");
                    var (meshPostSimp, coordsPostSimp) = ConvertToQuadsAutomaticWithThresholds(
                        meshSimplified, coordsSimplified, 10, 170);
                    int postSimpQuads = meshPostSimp.Count<Quad4>() - meshSimplified.Count<Quad4>();
                    Console.WriteLine($"          Created {postSimpQuads} additional quads");
                    quadMesh = meshPostSimp;
                    quadCoords = coordsPostSimp;
                }
                else
                {
                    quadMesh = meshSimplified;
                    quadCoords = coordsSimplified;
                }
                */

                // ========== FINAL STATISTICS ==========
                var finalQuads = quadMesh.Count<Quad4>();
                var finalTris = quadMesh.Count<Tri3>();
                var finalCoverage = 100.0 * finalQuads / (finalQuads + finalTris * 0.5);
                Console.WriteLine(
                    $"     ✅ FINAL RESULT: {finalQuads} quads, {finalTris} tris ({finalCoverage:F1}% quad coverage)");

                // Phase 5: Quad optimization (if quads were created)
                if (quadMesh.Count<Quad4>() > 0) OptimizeQuadMesh(quadMesh, quadCoords);

                // Phase 6: Final CVT smoothing
                if (enableSmoothing) CVTSmoothing(quadMesh, quadCoords, 3); // Reduced from 5 to 3

                // Validate triangles
                var nInvertedQuad = RemoveInvertedTriangles(quadMesh, quadCoords);
                if (nInvertedQuad > 0)
                    Console.WriteLine($"  ⚠️  WARNING: {nInvertedQuad} inverted triangles detected in quad mesh!");

                // Report final statistics
                var stats = ComputeFinalStatistics(quadMesh, quadCoords);
                Console.WriteLine($"  ✅ Final mesh: {stats.nQuads} quads, {stats.nTris} tris, " +
                                  $"min angle={stats.minAngle:F1}°, quad coverage={stats.quadCoverage:F1}%");

                return (quadMesh, quadCoords);
            }
            else
            {
                // Pure TRI mode - no quad conversion (for crack insertion, Refine() compatibility)
                // Final CVT smoothing
                if (enableSmoothing) CVTSmoothing(mesh, coords, 3); // Reduced from 5 to 3

                // Validate triangles
                var nInvertedFinal = RemoveInvertedTriangles(mesh, coords);
                if (nInvertedFinal > 0)
                    Console.WriteLine(
                        $"  ⚠️  WARNING: {nInvertedFinal} inverted triangles detected after final smoothing!");

                var stats = ComputeFinalStatistics(mesh, coords);
                Console.WriteLine(
                    $"  ✅ Final mesh: Pure TRI mode, {stats.nTris} triangles, min angle={stats.minAngle:F1}°");

                return (mesh, coords);
            }
        }

        return (mesh, coords);
    }

    #endregion

    #region Bowyer-Watson Algorithm

    private static void AddPoint(
        int pointIdx,
        List<(double x, double y)> points,
        List<(int v0, int v1, int v2)> triangles,
        List<(double x, double y, double rSq)> circumcenters)
    {
        var point = points[pointIdx];
        var badTriangles = new List<int>();

        // Find triangles whose circumcircle contains the point
        for (var i = 0; i < triangles.Count; i++)
        {
            var (cx, cy, rSq) = circumcenters[i];
            var dx = point.x - cx;
            var dy = point.y - cy;
            var distSq = dx * dx + dy * dy;

            if (distSq < rSq - EPSILON) badTriangles.Add(i);
        }

        // Find boundary of polygonal hole
        var polygon = new List<(int, int)>();

        foreach (var triIdx in badTriangles)
        {
            var tri = triangles[triIdx];
            var edges = new[]
            {
                (tri.v0, tri.v1),
                (tri.v1, tri.v2),
                (tri.v2, tri.v0)
            };

            foreach (var edge in edges)
            {
                var isShared = false;

                foreach (var otherIdx in badTriangles)
                {
                    if (otherIdx == triIdx) continue;

                    var other = triangles[otherIdx];
                    if (ContainsEdge(other, edge.Item1, edge.Item2))
                    {
                        isShared = true;
                        break;
                    }
                }

                if (!isShared) polygon.Add(edge);
            }
        }

        // Remove bad triangles (in reverse order to maintain indices)
        badTriangles.Sort();
        for (var i = badTriangles.Count - 1; i >= 0; i--)
        {
            var idx = badTriangles[i];
            triangles.RemoveAt(idx);
            circumcenters.RemoveAt(idx);
        }

        // Create new triangles from point to polygon boundary
        // Polygon edges are CW around the cavity, so swap to get CCW triangles
        foreach (var (v0, v1) in polygon)
        {
            triangles.Add((v0, pointIdx, v1)); // Swapped: (v0, pointIdx, v1) instead of (v0, v1, pointIdx)
            circumcenters.Add(ComputeCircumcircle(points, v0, pointIdx, v1));
        }
    }

    private static bool ContainsEdge((int v0, int v1, int v2) tri, int e0, int e1)
    {
        return (tri.v0 == e0 && tri.v1 == e1) || (tri.v1 == e0 && tri.v0 == e1) ||
               (tri.v1 == e0 && tri.v2 == e1) || (tri.v2 == e0 && tri.v1 == e1) ||
               (tri.v2 == e0 && tri.v0 == e1) || (tri.v0 == e0 && tri.v2 == e1);
    }

    private static (double x, double y, double rSq) ComputeCircumcircle(
        List<(double x, double y)> points,
        int i0, int i1, int i2)
    {
        var (ax, ay) = points[i0];
        var (bx, by) = points[i1];
        var (cx, cy) = points[i2];

        var d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by));

        if (Math.Abs(d) < EPSILON)
        {
            // Degenerate triangle - return centroid with large radius
            var ccx = (ax + bx + cx) / 3;
            var ccy = (ay + by + cy) / 3;
            return (ccx, ccy, double.MaxValue);
        }

        var ux = ((ax * ax + ay * ay) * (by - cy) +
                  (bx * bx + by * by) * (cy - ay) +
                  (cx * cx + cy * cy) * (ay - by)) / d;

        var uy = ((ax * ax + ay * ay) * (cx - bx) +
                  (bx * bx + by * by) * (ax - cx) +
                  (cx * cx + cy * cy) * (bx - ax)) / d;

        var dx = ux - ax;
        var dy = uy - ay;
        var rSq = dx * dx + dy * dy;

        return (ux, uy, rSq);
    }

    #endregion

    #region Size Function for Adaptive Refinement

    /// <summary>
    ///     Stores boundary edge data for size computation.
    /// </summary>
    private class EdgeSizeData
    {
        public double targetSize;
        public double x0, y0, x1, y1;
    }

    /// <summary>
    ///     Adaptive size function based on distance to boundary edges.
    /// </summary>
    private class SizeFunction
    {
        private readonly List<EdgeSizeData> edges;
        private readonly double gradation;
        private readonly double maxSize;
        private readonly double minSize;

        public SizeFunction(List<EdgeSizeData> edges, double gradation)
        {
            this.edges = edges;
            this.gradation = Math.Max(1.0, Math.Min(gradation, 2.0)); // Clamp to [1.0, 2.0]
            minSize = edges.Min(e => e.targetSize);
            maxSize = edges.Max(e => e.targetSize);
        }

        /// <summary>
        ///     Get desired element size at point (x, y).
        ///     Uses distance-weighted interpolation from nearest boundary edges.
        /// </summary>
        public double GetSize(double x, double y)
        {
            // Find K nearest edges (use K=3 for smooth interpolation)
            const int K = 3;
            var nearestEdges = new List<(double distance, double size)>(K);

            foreach (var edge in edges)
            {
                var dist = DistanceToSegment(x, y, edge.x0, edge.y0, edge.x1, edge.y1);

                // Gradation: size grows with distance from boundary
                // Use multiplicative growth: size(d) = edgeSize × gradation^(d/edgeSize)
                var sizeAtPoint = edge.targetSize * Math.Pow(gradation, dist / edge.targetSize);

                // Insert in sorted order (only keep K nearest)
                var insertIdx = 0;
                while (insertIdx < nearestEdges.Count && nearestEdges[insertIdx].distance < dist)
                    insertIdx++;

                if (insertIdx < K)
                {
                    nearestEdges.Insert(insertIdx, (dist, sizeAtPoint));
                    if (nearestEdges.Count > K)
                        nearestEdges.RemoveAt(K);
                }
            }

            if (nearestEdges.Count == 0)
                return (minSize + maxSize) / 2;

            // Inverse distance weighted interpolation
            double sumWeights = 0;
            double sumWeightedSizes = 0;

            foreach (var (dist, size) in nearestEdges)
            {
                var weight = 1.0 / (dist + EPSILON);
                sumWeights += weight;
                sumWeightedSizes += weight * size;
            }

            var interpolatedSize = sumWeightedSizes / sumWeights;

            // Clamp to reasonable bounds
            return Math.Max(minSize * 0.5, Math.Min(interpolatedSize, maxSize * 2.0));
        }

        /// <summary>
        ///     Compute point-to-segment distance.
        /// </summary>
        private double DistanceToSegment(double px, double py, double x0, double y0, double x1, double y1)
        {
            var dx = x1 - x0;
            var dy = y1 - y0;
            var lengthSq = dx * dx + dy * dy;

            if (lengthSq < EPSILON)
            {
                // Degenerate segment
                var dpx = px - x0;
                var dpy = py - y0;
                return Math.Sqrt(dpx * dpx + dpy * dpy);
            }

            // Project point onto line
            var t = ((px - x0) * dx + (py - y0) * dy) / lengthSq;
            t = Math.Max(0, Math.Min(1, t)); // Clamp to segment

            var closestX = x0 + t * dx;
            var closestY = y0 + t * dy;

            var distX = px - closestX;
            var distY = py - closestY;

            return Math.Sqrt(distX * distX + distY * distY);
        }
    }

    /// <summary>
    ///     Build adaptive size function from boundary edge lengths.
    ///     Size at any point is determined by interpolation from nearest boundary edges.
    /// </summary>
    private static SizeFunction BuildSizeFunctionFromBoundaries(
        double[,] outerBoundary,
        List<double[,]>? holes,
        double gradation)
    {
        var edgeData = new List<EdgeSizeData>();

        // Process outer boundary
        var nOuter = outerBoundary.GetLength(0);
        for (var i = 0; i < nOuter; i++)
        {
            var j = (i + 1) % nOuter;

            var x0 = outerBoundary[i, 0];
            var y0 = outerBoundary[i, 1];
            var x1 = outerBoundary[j, 0];
            var y1 = outerBoundary[j, 1];

            var edgeLength = Math.Sqrt((x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0));

            edgeData.Add(new EdgeSizeData
            {
                x0 = x0, y0 = y0,
                x1 = x1, y1 = y1,
                targetSize = edgeLength
            });
        }

        // Process hole boundaries
        if (holes != null)
            foreach (var hole in holes)
            {
                var nHole = hole.GetLength(0);
                for (var i = 0; i < nHole; i++)
                {
                    var j = (i + 1) % nHole;

                    var x0 = hole[i, 0];
                    var y0 = hole[i, 1];
                    var x1 = hole[j, 0];
                    var y1 = hole[j, 1];

                    var edgeLength = Math.Sqrt((x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0));

                    edgeData.Add(new EdgeSizeData
                    {
                        x0 = x0, y0 = y0,
                        x1 = x1, y1 = y1,
                        targetSize = edgeLength
                    });
                }
            }

        // Compute statistics
        var minSize = edgeData.Min(e => e.targetSize);
        var maxSize = edgeData.Max(e => e.targetSize);
        var avgSize = edgeData.Average(e => e.targetSize);

        Console.WriteLine("  📏 Boundary edge statistics:");
        Console.WriteLine($"     Min size: {minSize:F3}, Max size: {maxSize:F3}, Avg size: {avgSize:F3}");
        Console.WriteLine($"     Gradation factor: {gradation:F2}");

        return new SizeFunction(edgeData, gradation);
    }

    /// <summary>
    ///     Ruppert refinement with adaptive sizing based on size function.
    /// </summary>
    private static (List<(double, double)> points, List<(int, int, int)> triangles) RuppertRefinementAdaptive(
        List<(double x, double y)> points,
        List<(int v0, int v1, int v2)> triangles,
        int nBoundary,
        SizeFunction sizeFunction)
    {
        var maxIterations = 500; // INCREASED from 100
        var iteration = 0;
        var totalRefined = 0;

        while (iteration < maxIterations)
        {
            iteration++;
            var refined = false;

            for (var i = 0; i < triangles.Count; i++)
            {
                var (v0, v1, v2) = triangles[i];
                var area = ComputeTriangleArea(points[v0], points[v1], points[v2]);

                // Compute centroid
                var cx = (points[v0].x + points[v1].x + points[v2].x) / 3;
                var cy = (points[v0].y + points[v1].y + points[v2].y) / 3;

                // Get local target size
                var targetSize = sizeFunction.GetSize(cx, cy);
                // Area of equilateral triangle with side length targetSize
                // VERY AGGRESSIVE: use 0.2× area to force many interior triangles
                var localMaxArea = 0.2 * (Math.Sqrt(3) / 4.0) * targetSize * targetSize;

                if (area > localMaxArea)
                {
                    // Add circumcenter
                    var (ccx, ccy, _) = ComputeCircumcircle(points, v0, v1, v2);

                    // Check if inside polygon
                    var polygon = points.Take(nBoundary).ToList();
                    if (IsPointInPolygon((ccx, ccy), polygon))
                    {
                        var newIdx = points.Count;
                        points.Add((ccx, ccy));

                        // Re-triangulate with new point
                        var circumcenters = new List<(double, double, double)>();
                        foreach (var tri in triangles)
                            circumcenters.Add(ComputeCircumcircle(points, tri.v0, tri.v1, tri.v2));

                        AddPoint(newIdx, points, triangles, circumcenters);
                        refined = true;
                        totalRefined++;
                        break; // Re-check all triangles
                    }
                }
            }

            if (!refined) break;
        }

        if (totalRefined > 0)
            Console.WriteLine($"  🔧 Adaptive refinement: {totalRefined} points added in {iteration} iterations");

        return (points, triangles);
    }

    #endregion

    #region Boundary and Refinement

    private static List<(int, int, int)> RemoveExteriorTriangles(
        List<(int, int, int)> triangles,
        List<(double x, double y)> points,
        double[,] boundaryArray)
    {
        // Convert boundary array to list for polygon test
        var polygon = new List<(double x, double y)>();
        for (var i = 0; i < boundaryArray.GetLength(0); i++) polygon.Add((boundaryArray[i, 0], boundaryArray[i, 1]));

        Console.WriteLine($"     Polygon test using {polygon.Count} boundary points");

        var keptCount = 0;
        var rejectedCount = 0;

        var result = triangles.Where(tri =>
        {
            var (v0, v1, v2) = tri;

            // Test centroid - most reliable for general case
            var cx = (points[v0].x + points[v1].x + points[v2].x) / 3;
            var cy = (points[v0].y + points[v1].y + points[v2].y) / 3;

            var inside = IsPointInPolygon((cx, cy), polygon);

            if (inside)
                keptCount++;
            else
                rejectedCount++;

            return inside;
        }).ToList();

        Console.WriteLine($"     Kept {keptCount}, Rejected {rejectedCount}");

        // Sanity check: if we rejected > 50%, something is wrong
        if (rejectedCount > keptCount)
        {
            Console.WriteLine("     ⚠️  WARNING: Rejected more than kept! Polygon test may be failing.");
            Console.WriteLine(
                $"     Polygon bounds: X[{polygon.Min(p => p.x):F2}, {polygon.Max(p => p.x):F2}], Y[{polygon.Min(p => p.y):F2}, {polygon.Max(p => p.y):F2}]");
        }

        return result;
    }

    private static bool IsPointInPolygon((double x, double y) point, List<(double x, double y)> polygon)
    {
        var inside = false;
        var n = polygon.Count;

        for (int i = 0, j = n - 1; i < n; j = i++)
            if (polygon[i].y > point.y != polygon[j].y > point.y &&
                point.x < (polygon[j].x - polygon[i].x) * (point.y - polygon[i].y) /
                (polygon[j].y - polygon[i].y) + polygon[i].x)
                inside = !inside;

        return inside;
    }

    private static (List<(double, double)> points, List<(int, int, int)> triangles) RuppertRefinement(
        List<(double x, double y)> points,
        List<(int v0, int v1, int v2)> triangles,
        int nBoundary,
        double maxArea)
    {
        if (maxArea <= 0)
        {
            // Auto-compute based on polygon area
            var polygon = points.Take(nBoundary).ToList();
            var polyArea = ComputePolygonArea(polygon);
            maxArea = polyArea / (nBoundary * 5);
        }

        var maxIterations = 100;
        var iteration = 0;

        while (iteration < maxIterations)
        {
            iteration++;
            var refined = false;

            for (var i = 0; i < triangles.Count; i++)
            {
                var (v0, v1, v2) = triangles[i];
                var area = ComputeTriangleArea(points[v0], points[v1], points[v2]);

                if (area > maxArea)
                {
                    // Add circumcenter
                    var (cx, cy, _) = ComputeCircumcircle(points, v0, v1, v2);

                    // Check if inside polygon
                    var polygon = points.Take(nBoundary).ToList();
                    if (IsPointInPolygon((cx, cy), polygon))
                    {
                        var newIdx = points.Count;
                        points.Add((cx, cy));

                        // Re-triangulate with new point
                        var circumcenters = new List<(double, double, double)>();
                        foreach (var tri in triangles)
                            circumcenters.Add(ComputeCircumcircle(points, tri.v0, tri.v1, tri.v2));

                        AddPoint(newIdx, points, triangles, circumcenters);
                        refined = true;
                        break; // Re-check all triangles
                    }
                }
            }

            if (!refined) break;
        }

        return (points, triangles);
    }

    private static double ComputeTriangleArea(
        (double x, double y) a,
        (double x, double y) b,
        (double x, double y) c)
    {
        return 0.5 * Math.Abs((b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y));
    }

    private static double ComputePolygonArea(List<(double x, double y)> polygon)
    {
        double area = 0;
        var n = polygon.Count;

        for (var i = 0; i < n; i++)
        {
            var j = (i + 1) % n;
            area += polygon[i].x * polygon[j].y - polygon[j].x * polygon[i].y;
        }

        return Math.Abs(area) / 2;
    }

    #endregion

    #region Void/Hole Support

    /// <summary>
    ///     Checks if a boundary is CCW oriented using signed area.
    /// </summary>
    private static bool IsBoundaryCCW(double[,] boundary)
    {
        var n = boundary.GetLength(0);
        double area = 0;

        for (var i = 0; i < n; i++)
        {
            var j = (i + 1) % n;
            area += boundary[i, 0] * boundary[j, 1];
            area -= boundary[j, 0] * boundary[i, 1];
        }

        return area > 0; // Positive = CCW, Negative = CW
    }

    /// <summary>
    ///     Reverses a boundary to flip its orientation (CCW ↔ CW).
    /// </summary>
    private static double[,] ReverseBoundary(double[,] boundary)
    {
        var n = boundary.GetLength(0);
        var reversed = new double[n, 2];

        for (var i = 0; i < n; i++)
        {
            reversed[i, 0] = boundary[n - 1 - i, 0];
            reversed[i, 1] = boundary[n - 1 - i, 1];
        }

        return reversed;
    }

    /// <summary>
    ///     Computes the centroid of a boundary (used as seed point for holes).
    /// </summary>
    private static (double x, double y) GetBoundaryCentroid(double[,] boundary)
    {
        var n = boundary.GetLength(0);
        double cx = 0, cy = 0;

        for (var i = 0; i < n; i++)
        {
            cx += boundary[i, 0];
            cy += boundary[i, 1];
        }

        return (cx / n, cy / n);
    }

    /// <summary>
    ///     Removes triangles whose centroids are inside hole polygons.
    ///     ROBUST: Also checks if any vertex is inside hole as backup.
    /// </summary>
    private static List<(int, int, int)> RemoveTrianglesInHoles(
        List<(int, int, int)> triangles,
        List<(double x, double y)> points,
        List<List<(double x, double y)>> holeBoundaries)
    {
        if (holeBoundaries.Count == 0)
            return triangles;

        var result = new List<(int, int, int)>();
        var removed = 0;

        foreach (var (v0, v1, v2) in triangles)
        {
            // Compute triangle centroid
            var cx = (points[v0].x + points[v1].x + points[v2].x) / 3;
            var cy = (points[v0].y + points[v1].y + points[v2].y) / 3;

            // Check if centroid is inside any hole
            // ONLY test centroid - testing vertices creates gaps around hole boundary
            var insideHole = false;
            foreach (var holeBoundary in holeBoundaries)
                if (IsPointInPolygon((cx, cy), holeBoundary))
                {
                    insideHole = true;
                    break;
                }

            if (insideHole)
                removed++;
            else
                result.Add((v0, v1, v2));
        }

        if (removed > 0) Console.WriteLine($"  ℹ️  Removed {removed} triangles inside {holeBoundaries.Count} hole(s)");

        return result;
    }

    #endregion

    #region Advanced Mesh Smoothing

    /// <summary>
    ///     CVT-based smoothing (Centroidal Voronoi Tessellation).
    ///     Higher quality than Laplacian - nodes move to centroids of their Voronoi cells.
    ///     Produces more uniform triangulation with better aspect ratios.
    /// </summary>
    private static void CVTSmoothing(
        SimplexMesh mesh,
        double[,] coords,
        int iterations,
        double relaxation = 0.7)
    {
        var nNodes = coords.GetLength(0);
        var nTris = mesh.Count<Tri3>();
        var nQuads = mesh.Count<Quad4>();

        // For mixed meshes, we need to manually find boundary edges
        // An edge is on the boundary if it belongs to exactly ONE element (tri or quad)
        var edgeCount = new Dictionary<(int, int), int>();

        // Count edges from triangles
        for (var t = 0; t < nTris; t++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(t);
            var edges = new[]
            {
                (Math.Min(nodes[0], nodes[1]), Math.Max(nodes[0], nodes[1])),
                (Math.Min(nodes[1], nodes[2]), Math.Max(nodes[1], nodes[2])),
                (Math.Min(nodes[2], nodes[0]), Math.Max(nodes[2], nodes[0]))
            };

            foreach (var edge in edges)
            {
                if (!edgeCount.ContainsKey(edge))
                    edgeCount[edge] = 0;
                edgeCount[edge]++;
            }
        }

        // Count edges from quads
        for (var q = 0; q < nQuads; q++)
        {
            var nodes = mesh.NodesOf<Quad4, Node>(q);
            var edges = new[]
            {
                (Math.Min(nodes[0], nodes[1]), Math.Max(nodes[0], nodes[1])),
                (Math.Min(nodes[1], nodes[2]), Math.Max(nodes[1], nodes[2])),
                (Math.Min(nodes[2], nodes[3]), Math.Max(nodes[2], nodes[3])),
                (Math.Min(nodes[3], nodes[0]), Math.Max(nodes[3], nodes[0]))
            };

            foreach (var edge in edges)
            {
                if (!edgeCount.ContainsKey(edge))
                    edgeCount[edge] = 0;
                edgeCount[edge]++;
            }
        }

        // Boundary edges are those that appear exactly once
        var boundaryNodes = new HashSet<int>();
        foreach (var kvp in edgeCount)
            if (kvp.Value == 1)
            {
                boundaryNodes.Add(kvp.Key.Item1);
                boundaryNodes.Add(kvp.Key.Item2);
            }

        // Identify boundary-adjacent nodes (protective layer)
        var boundaryAdjacent = new HashSet<int>();

        // Also identify second layer (boundary-adjacent-adjacent) for extra protection
        var secondLayer = new HashSet<int>();

        for (var t = 0; t < nTris; t++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(t);
            var hasBoundary = nodes.Any(n => boundaryNodes.Contains(n));

            if (hasBoundary)
                foreach (var n in nodes)
                    if (!boundaryNodes.Contains(n))
                        boundaryAdjacent.Add(n);
        }

        for (var q = 0; q < nQuads; q++)
        {
            var nodes = mesh.NodesOf<Quad4, Node>(q);
            var hasBoundary = nodes.Any(n => boundaryNodes.Contains(n));

            if (hasBoundary)
                foreach (var n in nodes)
                    if (!boundaryNodes.Contains(n))
                        boundaryAdjacent.Add(n);
        }

        // Build second layer: elements adjacent to first layer
        for (var t = 0; t < nTris; t++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(t);
            var hasFirstLayer = nodes.Any(n => boundaryAdjacent.Contains(n));

            if (hasFirstLayer)
                foreach (var n in nodes)
                    if (!boundaryNodes.Contains(n) && !boundaryAdjacent.Contains(n))
                        secondLayer.Add(n);
        }

        for (var q = 0; q < nQuads; q++)
        {
            var nodes = mesh.NodesOf<Quad4, Node>(q);
            var hasFirstLayer = nodes.Any(n => boundaryAdjacent.Contains(n));

            if (hasFirstLayer)
                foreach (var n in nodes)
                    if (!boundaryNodes.Contains(n) && !boundaryAdjacent.Contains(n))
                        secondLayer.Add(n);
        }

        Console.WriteLine($"  🔧 CVT smoothing ({iterations} iterations, relaxation={relaxation:F2})");
        Console.WriteLine($"     Mesh: {nTris} tris, {nQuads} quads, {nNodes} nodes");
        Console.WriteLine($"     Boundary nodes: {boundaryNodes.Count}/{nNodes} (fixed - 0% movement)");
        Console.WriteLine($"     Layer 1 (adjacent): {boundaryAdjacent.Count} (5% relaxation)");
        Console.WriteLine($"     Layer 2 (second): {secondLayer.Count} (25% relaxation)");
        Console.WriteLine(
            $"     Interior nodes: {nNodes - boundaryNodes.Count - boundaryAdjacent.Count - secondLayer.Count} (full 70% relaxation)");

        // Build node-to-element connectivity (triangles and quads)
        var nodeElements = new Dictionary<int, List<(bool isQuad, int idx)>>();
        for (var i = 0; i < nNodes; i++) nodeElements[i] = new List<(bool, int)>();

        for (var t = 0; t < nTris; t++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(t);
            nodeElements[nodes[0]].Add((false, t));
            nodeElements[nodes[1]].Add((false, t));
            nodeElements[nodes[2]].Add((false, t));
        }

        for (var q = 0; q < nQuads; q++)
        {
            var nodes = mesh.NodesOf<Quad4, Node>(q);
            nodeElements[nodes[0]].Add((true, q));
            nodeElements[nodes[1]].Add((true, q));
            nodeElements[nodes[2]].Add((true, q));
            nodeElements[nodes[3]].Add((true, q));
        }

        // CVT smoothing iterations
        for (var iter = 0; iter < iterations; iter++)
        {
            var newCoords = (double[,])coords.Clone();
            var rejectedMoves = 0;
            var movedNodes = 0;

            for (var i = 0; i < nNodes; i++)
            {
                // Don't move boundary nodes
                if (boundaryNodes.Contains(i))
                    continue;

                if (nodeElements[i].Count == 0)
                    continue;

                // Three-layer boundary protection system:
                // Layer 0 (boundary): No movement (skipped above)
                // Layer 1 (adjacent): 5% relaxation (very conservative)
                // Layer 2 (second): 25% relaxation (moderate)
                // Interior: Full relaxation
                double nodeRelaxation;
                if (boundaryAdjacent.Contains(i))
                    nodeRelaxation = relaxation * 0.05; // Layer 1: almost fixed
                else if (secondLayer.Contains(i))
                    nodeRelaxation = relaxation * 0.25; // Layer 2: conservative
                else
                    nodeRelaxation = relaxation; // Interior: full

                // Compute centroid of Voronoi cell (approximated by element centroids)
                double sumX = 0, sumY = 0;
                double sumArea = 0;

                foreach (var (isQuad, elemIdx) in nodeElements[i])
                    if (isQuad)
                    {
                        // Quad element - split into 2 triangles for area computation
                        var nodes = mesh.NodesOf<Quad4, Node>(elemIdx);

                        // Triangle 1: nodes[0], nodes[1], nodes[2]
                        double x0 = coords[nodes[0], 0], y0 = coords[nodes[0], 1];
                        double x1 = coords[nodes[1], 0], y1 = coords[nodes[1], 1];
                        double x2 = coords[nodes[2], 0], y2 = coords[nodes[2], 1];
                        var area1 = Math.Abs((x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0)) * 0.5;
                        var cx1 = (x0 + x1 + x2) / 3.0;
                        var cy1 = (y0 + y1 + y2) / 3.0;

                        // Triangle 2: nodes[0], nodes[2], nodes[3]
                        double x3 = coords[nodes[3], 0], y3 = coords[nodes[3], 1];
                        var area2 = Math.Abs((x2 - x0) * (y3 - y0) - (x3 - x0) * (y2 - y0)) * 0.5;
                        var cx2 = (x0 + x2 + x3) / 3.0;
                        var cy2 = (y0 + y2 + y3) / 3.0;

                        sumX += cx1 * area1 + cx2 * area2;
                        sumY += cy1 * area1 + cy2 * area2;
                        sumArea += area1 + area2;
                    }
                    else
                    {
                        // Triangle element
                        var nodes = mesh.NodesOf<Tri3, Node>(elemIdx);

                        double x0 = coords[nodes[0], 0], y0 = coords[nodes[0], 1];
                        double x1 = coords[nodes[1], 0], y1 = coords[nodes[1], 1];
                        double x2 = coords[nodes[2], 0], y2 = coords[nodes[2], 1];

                        var area = Math.Abs((x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0)) * 0.5;
                        var cx = (x0 + x1 + x2) / 3.0;
                        var cy = (y0 + y1 + y2) / 3.0;

                        sumX += cx * area;
                        sumY += cy * area;
                        sumArea += area;
                    }

                if (sumArea > EPSILON)
                {
                    // Voronoi cell centroid
                    var targetX = sumX / sumArea;
                    var targetY = sumY / sumArea;

                    // Relaxed move with node-specific relaxation
                    var proposedX = coords[i, 0] + nodeRelaxation * (targetX - coords[i, 0]);
                    var proposedY = coords[i, 1] + nodeRelaxation * (targetY - coords[i, 1]);

                    // Validate: check if move would invert any adjacent element OR create bad angles
                    var wouldInvert = false;
                    foreach (var (isQuad, elemIdx) in nodeElements[i])
                        if (isQuad)
                        {
                            // Check quad - verify inversion AND angle quality
                            var nodes = mesh.NodesOf<Quad4, Node>(elemIdx);

                            var oldX = coords[i, 0];
                            var oldY = coords[i, 1];
                            coords[i, 0] = proposedX;
                            coords[i, 1] = proposedY;

                            // Check both triangular splits of the quad for inversion
                            var tri1OK = IsTriangleCCW(coords, nodes[0], nodes[1], nodes[2]);
                            var tri2OK = IsTriangleCCW(coords, nodes[0], nodes[2], nodes[3]);

                            // CRITICAL: Also check quad angles don't become too sharp
                            var anglesOK = true;
                            if (tri1OK && tri2OK)
                            {
                                var quadAngles = ComputeQuadAngles(coords, nodes[0], nodes[1], nodes[2], nodes[3]);
                                var quadMinAngle = quadAngles.Min();
                                var quadMaxAngle = quadAngles.Max();

                                // Reject if angles become too extreme (worse than initial conversion threshold)
                                if (quadMinAngle < 5.0 || quadMaxAngle > 175.0)
                                    anglesOK = false;
                            }

                            coords[i, 0] = oldX;
                            coords[i, 1] = oldY;

                            if (!tri1OK || !tri2OK || !anglesOK)
                            {
                                wouldInvert = true;
                                break;
                            }
                        }
                        else
                        {
                            // Check triangle
                            var nodes = mesh.NodesOf<Tri3, Node>(elemIdx);

                            var oldX = coords[i, 0];
                            var oldY = coords[i, 1];
                            coords[i, 0] = proposedX;
                            coords[i, 1] = proposedY;

                            if (!IsTriangleCCW(coords, nodes[0], nodes[1], nodes[2])) wouldInvert = true;

                            coords[i, 0] = oldX;
                            coords[i, 1] = oldY;

                            if (wouldInvert) break;
                        }

                    if (!wouldInvert)
                    {
                        newCoords[i, 0] = proposedX;
                        newCoords[i, 1] = proposedY;
                        movedNodes++;
                    }
                    else
                    {
                        rejectedMoves++;
                    }
                }
            }

            // Update coordinates
            for (var i = 0; i < nNodes; i++)
            {
                coords[i, 0] = newCoords[i, 0];
                coords[i, 1] = newCoords[i, 1];
            }

            if (rejectedMoves > 0 && iter == 0)
                Console.WriteLine(
                    $"     Iteration {iter + 1}: Moved {movedNodes} nodes, rejected {rejectedMoves} moves");
        }

        // Compute quality improvement with MATLAB-style metrics
        var (minQ, avgQ, minAngle, avgAngle) = ComputeMeshQualityStatistics(mesh, coords);
        Console.WriteLine(
            $"     Quality after CVT: min={minQ:F3}, avg={avgQ:F3}, minAngle={minAngle:F1}°, avgAngle={avgAngle:F1}°");
    }


    /// <summary>
    ///     Identify boundary vertices by counting edge occurrences.
    ///     NOTE: This is now DEPRECATED - use library method GetBoundarySubEntities instead.
    ///     Kept only for backward compatibility.
    /// </summary>
    private static HashSet<int> IdentifyBoundaryVertices(SimplexMesh mesh)
    {
        // Discover edges if not already done
        mesh.DiscoverSubEntities<Tri3, Edge, Node>(SubEntityDefinition.Tri3Edges);

        // Get boundary edges using library method
        var boundaryEdgeIndices = mesh.GetBoundarySubEntities<Tri3, Edge, Node>();

        // Extract nodes from boundary edges
        var boundaryVertices = new HashSet<int>();
        foreach (var edgeIdx in boundaryEdgeIndices)
        {
            var edgeNodes = mesh.NodesOf<Edge, Node>(edgeIdx);
            boundaryVertices.Add(edgeNodes[0]);
            boundaryVertices.Add(edgeNodes[1]);
        }

        return boundaryVertices;
    }

    private static (int, int) MakeEdge(int v0, int v1)
    {
        return v0 < v1 ? (v0, v1) : (v1, v0);
    }

    /// <summary>
    ///     Compute angle at vertex 'center' in triangle (center, a, b)
    /// </summary>
    private static double ComputeAngleSmoothing(double[,] coords, int center, int a, int b)
    {
        var ax = coords[a, 0] - coords[center, 0];
        var ay = coords[a, 1] - coords[center, 1];
        var bx = coords[b, 0] - coords[center, 0];
        var by = coords[b, 1] - coords[center, 1];

        var dot = ax * bx + ay * by;
        var lenA = Math.Sqrt(ax * ax + ay * ay);
        var lenB = Math.Sqrt(bx * bx + by * by);

        if (lenA < EPSILON || lenB < EPSILON)
            return 0;

        var cosAngle = Math.Clamp(dot / (lenA * lenB), -1.0, 1.0);
        return Math.Acos(cosAngle); // Return in radians
    }

    /// <summary>
    ///     Compute minimum angle in the mesh (quality metric)
    /// </summary>
    /// <summary>
    ///     Computes triangle quality metrics (similar to MATLAB's mesh quality functions).
    ///     Quality = 2 * inradius / circumradius (ranges 0-1, 1 = equilateral)
    /// </summary>
    private static double ComputeTriangleQuality(
        double[,] coords,
        int v0, int v1, int v2)
    {
        double x0 = coords[v0, 0], y0 = coords[v0, 1];
        double x1 = coords[v1, 0], y1 = coords[v1, 1];
        double x2 = coords[v2, 0], y2 = coords[v2, 1];

        // Edge lengths
        var a = Math.Sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
        var b = Math.Sqrt((x2 - x0) * (x2 - x0) + (y2 - y0) * (y2 - y0));
        var c = Math.Sqrt((x0 - x1) * (x0 - x1) + (y0 - y1) * (y0 - y1));

        // Area (using cross product)
        var area = Math.Abs((x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0)) * 0.5;

        if (area < EPSILON)
            return 0.0;

        // Semiperimeter
        var s = (a + b + c) * 0.5;

        // Inradius: r = Area / s
        var inradius = area / s;

        // Circumradius: R = (a * b * c) / (4 * Area)
        var circumradius = a * b * c / (4.0 * area);

        if (circumradius < EPSILON)
            return 0.0;

        // Quality metric: q = 2r/R (ranges 0-1, 1 = equilateral)
        // Also known as normalized shape quality
        var quality = 2.0 * inradius / circumradius;

        return quality;
    }

    /// <summary>
    ///     Computes the minimum angle in a single triangle.
    /// </summary>
    private static double ComputeMinimumAngleInTriangle(
        double[,] coords,
        int v0, int v1, int v2)
    {
        double x0 = coords[v0, 0], y0 = coords[v0, 1];
        double x1 = coords[v1, 0], y1 = coords[v1, 1];
        double x2 = coords[v2, 0], y2 = coords[v2, 1];

        // Edge vectors
        var a = Math.Sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2)); // opposite v0
        var b = Math.Sqrt((x2 - x0) * (x2 - x0) + (y2 - y0) * (y2 - y0)); // opposite v1
        var c = Math.Sqrt((x0 - x1) * (x0 - x1) + (y0 - y1) * (y0 - y1)); // opposite v2

        if (a < EPSILON || b < EPSILON || c < EPSILON)
            return 0.0;

        // Angles using law of cosines: cos(A) = (b² + c² - a²) / (2bc)
        var cosA = (b * b + c * c - a * a) / (2 * b * c);
        var cosB = (a * a + c * c - b * b) / (2 * a * c);
        var cosC = (a * a + b * b - c * c) / (2 * a * b);

        // Clamp to [-1, 1] to handle numerical errors
        cosA = Math.Max(-1.0, Math.Min(1.0, cosA));
        cosB = Math.Max(-1.0, Math.Min(1.0, cosB));
        cosC = Math.Max(-1.0, Math.Min(1.0, cosC));

        var angleA = Math.Acos(cosA) * 180.0 / Math.PI;
        var angleB = Math.Acos(cosB) * 180.0 / Math.PI;
        var angleC = Math.Acos(cosC) * 180.0 / Math.PI;

        return Math.Min(angleA, Math.Min(angleB, angleC));
    }

    /// <summary>
    ///     Computes mesh quality statistics.
    /// </summary>
    private static (double minQuality, double avgQuality, double minAngle, double avgAngle)
        ComputeMeshQualityStatistics(SimplexMesh mesh, double[,] coords)
    {
        var minQuality = 1.0;
        var sumQuality = 0.0;
        var minAngle = 180.0;
        var sumAngle = 0.0;
        var count = 0;

        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);

            // Triangle quality
            var quality = ComputeTriangleQuality(coords, nodes[0], nodes[1], nodes[2]);
            minQuality = Math.Min(minQuality, quality);
            sumQuality += quality;

            // Minimum angle
            var angle = ComputeMinimumAngleInTriangle(coords, nodes[0], nodes[1], nodes[2]);
            minAngle = Math.Min(minAngle, angle);
            sumAngle += angle;

            count++;
        }

        return (
            minQuality,
            count > 0 ? sumQuality / count : 0.0,
            minAngle,
            count > 0 ? sumAngle / count : 0.0
        );
    }

    private static double ComputeMinimumAngleInMesh(SimplexMesh mesh, double[,] coords)
    {
        var minAngle = Math.PI;

        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);

            var a0 = ComputeAngleSmoothing(coords, nodes[0], nodes[1], nodes[2]);
            var a1 = ComputeAngleSmoothing(coords, nodes[1], nodes[2], nodes[0]);
            var a2 = ComputeAngleSmoothing(coords, nodes[2], nodes[0], nodes[1]);

            minAngle = Math.Min(minAngle, Math.Min(a0, Math.Min(a1, a2)));
        }

        return minAngle * 180.0 / Math.PI; // Convert to degrees
    }

    #endregion

    #region Topology Optimization - Edge Flipping

    /// <summary>
    ///     Edge flipping: Replace diagonal of a quad formed by two triangles if it improves quality.
    ///     This is the most effective topology operation for mesh quality improvement.
    /// </summary>
    private static int EdgeFlipping(SimplexMesh mesh, double[,] coords, double minAngleTarget)
    {
        var nFlips = 0;

        // Build edge-to-triangle adjacency
        var edgeToTriangles = new Dictionary<(int, int), List<int>>();

        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            var edges = new[]
            {
                MakeEdge(nodes[0], nodes[1]),
                MakeEdge(nodes[1], nodes[2]),
                MakeEdge(nodes[2], nodes[0])
            };

            foreach (var edge in edges)
            {
                if (!edgeToTriangles.ContainsKey(edge))
                    edgeToTriangles[edge] = new List<int>();
                edgeToTriangles[edge].Add(i);
            }
        }

        // Identify boundary edges (don't flip)
        mesh.DiscoverSubEntities<Tri3, Edge, Node>(SubEntityDefinition.Tri3Edges);
        var boundaryEdgeIndices = mesh.GetBoundarySubEntities<Tri3, Edge, Node>();
        var boundaryEdgeSet = new HashSet<(int, int)>();

        foreach (var edgeIdx in boundaryEdgeIndices)
        {
            var nodes = mesh.NodesOf<Edge, Node>(edgeIdx);
            boundaryEdgeSet.Add(MakeEdge(nodes[0], nodes[1]));
        }

        // Try flipping each interior edge
        var trianglesToModify = new List<(int tri1, int tri2, int v0, int v1, int v2, int v3)>();

        foreach (var (edge, tris) in edgeToTriangles)
        {
            if (tris.Count != 2) continue; // Only interior edges
            if (boundaryEdgeSet.Contains(edge)) continue; // Don't flip boundary

            var tri1 = tris[0];
            var tri2 = tris[1];

            var nodes1 = mesh.NodesOf<Tri3, Node>(tri1);
            var nodes2 = mesh.NodesOf<Tri3, Node>(tri2);

            // Find the four vertices of the quad
            var e0 = edge.Item1;
            var e1 = edge.Item2;
            var v2 = nodes1.First(n => n != e0 && n != e1); // Opposite vertex in tri1
            var v3 = nodes2.First(n => n != e0 && n != e1); // Opposite vertex in tri2

            // Current configuration: two triangles sharing edge (e0, e1)
            var minAngleBefore = Math.Min(
                ComputeMinimumTriangleAngle(coords, e0, e1, v2),
                ComputeMinimumTriangleAngle(coords, e0, e1, v3));

            // Proposed configuration: two triangles sharing edge (v2, v3)
            var minAngleAfter = Math.Min(
                ComputeMinimumTriangleAngle(coords, v2, v3, e0),
                ComputeMinimumTriangleAngle(coords, v2, v3, e1));

            // Check if new configuration is valid (no inverted triangles)
            var valid = IsTriangleCCW(coords, v2, v3, e0) && IsTriangleCCW(coords, v2, v3, e1);

            // Flip if it improves quality
            if (valid && minAngleAfter > minAngleBefore + 1.0) // 1 degree improvement threshold
                trianglesToModify.Add((tri1, tri2, v2, v3, e0, e1));
        }

        // Apply flips by rebuilding mesh
        if (trianglesToModify.Count > 0)
        {
            var flippedTris = new HashSet<int>();
            var newTriangles = new List<(int, int, int)>();

            // Collect all triangles
            for (var i = 0; i < mesh.Count<Tri3>(); i++)
            {
                var nodes = mesh.NodesOf<Tri3, Node>(i);
                newTriangles.Add((nodes[0], nodes[1], nodes[2]));
            }

            // Apply flips
            foreach (var (tri1, tri2, v2, v3, e0, e1) in trianglesToModify)
            {
                if (flippedTris.Contains(tri1) || flippedTris.Contains(tri2))
                    continue; // Already modified

                // Replace tri1 and tri2 with new configuration
                newTriangles[tri1] = (v2, v3, e0);
                newTriangles[tri2] = (v2, v3, e1);

                flippedTris.Add(tri1);
                flippedTris.Add(tri2);
                nFlips++;
            }

            // Rebuild mesh
            mesh.Clear();
            mesh.WithBatch(() =>
            {
                for (var i = 0; i < coords.GetLength(0); i++)
                    mesh.AddNode(i);

                foreach (var (v0, v1, v2) in newTriangles)
                    AddTriangleCCW(mesh, coords, v0, v1, v2);
            });
        }

        return nFlips;
    }

    /// <summary>
    ///     Compute minimum angle in a triangle.
    /// </summary>
    private static double ComputeMinimumTriangleAngle(double[,] coords, int v0, int v1, int v2)
    {
        var a0 = ComputeAngleSmoothing(coords, v0, v1, v2);
        var a1 = ComputeAngleSmoothing(coords, v1, v2, v0);
        var a2 = ComputeAngleSmoothing(coords, v2, v0, v1);

        return Math.Min(a0, Math.Min(a1, a2)) * 180.0 / Math.PI;
    }

    /// <summary>
    ///     Check if triangle is counter-clockwise oriented.
    /// </summary>
    private static bool IsTriangleCCW(double[,] coords, int v0, int v1, int v2)
    {
        var ax = coords[v1, 0] - coords[v0, 0];
        var ay = coords[v1, 1] - coords[v0, 1];
        var bx = coords[v2, 0] - coords[v0, 0];
        var by = coords[v2, 1] - coords[v0, 1];

        return ax * by - ay * bx > EPSILON;
    }

    /// <summary>
    ///     Check for inverted (CW) triangles in mesh.
    ///     With proper smoothing validation, this should find zero inversions.
    /// </summary>
    private static int RemoveInvertedTriangles(SimplexMesh mesh, double[,] coords)
    {
        var invertedCount = 0;

        // Count inverted triangles
        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            if (!IsTriangleCCW(coords, nodes[0], nodes[1], nodes[2])) invertedCount++;
        }

        // Note: We don't actually remove them because SimplexMesh doesn't support element removal
        // Instead, the validation during smoothing (checking before accepting moves) prevents inversions
        // This function serves as a final validation check only

        return invertedCount;
    }

    #endregion

    #region Automatic Quad Conversion and Optimization

    /// <summary>
    ///     Automatic triangle-to-quad conversion with sensible defaults.
    ///     Set-and-forget: maximizes quad coverage automatically.
    /// </summary>
    private static (SimplexMesh, double[,]) ConvertToQuadsAutomatic(SimplexMesh triMesh, double[,] coords)
    {
        Console.WriteLine("     🔷 Enhanced quad conversion (multi-strategy)");

        // Build adjacency
        var edgeToTris = new Dictionary<(int, int), List<int>>();
        for (var i = 0; i < triMesh.Count<Tri3>(); i++)
        {
            var nodes = triMesh.NodesOf<Tri3, Node>(i);
            var edges = new[]
            {
                MakeEdge(nodes[0], nodes[1]),
                MakeEdge(nodes[1], nodes[2]),
                MakeEdge(nodes[2], nodes[0])
            };

            foreach (var edge in edges)
            {
                if (!edgeToTris.ContainsKey(edge))
                    edgeToTris[edge] = new List<int>();
                edgeToTris[edge].Add(i);
            }
        }

        // Compute node valences for valence-based pairing
        var nodeValences = ComputeNodeValences(triMesh);

        // Strategy 1: Quality-based pairing (original)
        var qualityCandidates = QualityBasedQuadPairing(triMesh, coords, edgeToTris);

        // Strategy 2: Valence-based pairing (NEW - from MeshOptimizer)
        var valenceCandidates = ValenceBasedQuadPairing(triMesh, coords, edgeToTris, nodeValences);

        // Strategy 3: Geometry-based pairing (NEW - from MeshOptimizer)
        var geometryCandidates = GeometryBasedQuadPairing(triMesh, coords, edgeToTris);

        // Combine all candidates
        var allCandidates =
            new List<(int tri1, int tri2, double quality, int v0, int v1, int v2, int v3, string strategy)>();
        allCandidates.AddRange(qualityCandidates.Select(c =>
            (c.tri1, c.tri2, c.quality, c.v0, c.v1, c.v2, c.v3, "quality")));
        allCandidates.AddRange(valenceCandidates.Select(c =>
            (c.tri1, c.tri2, c.quality, c.v0, c.v1, c.v2, c.v3, "valence")));
        allCandidates.AddRange(geometryCandidates.Select(c =>
            (c.tri1, c.tri2, c.quality, c.v0, c.v1, c.v2, c.v3, "geometry")));

        // Sort by quality and greedily select
        allCandidates.Sort((a, b) => b.quality.CompareTo(a.quality));

        var paired = new HashSet<int>();
        var quads = new List<(int, int, int, int)>();
        int qualityQuads = 0, valenceQuads = 0, geometryQuads = 0;

        foreach (var (tri1, tri2, _, v0, v1, v2, v3, strategy) in allCandidates)
        {
            if (paired.Contains(tri1) || paired.Contains(tri2)) continue;
            quads.Add((v0, v1, v2, v3));
            paired.Add(tri1);
            paired.Add(tri2);

            if (strategy == "quality") qualityQuads++;
            else if (strategy == "valence") valenceQuads++;
            else if (strategy == "geometry") geometryQuads++;
        }

        Console.WriteLine(
            $"        Strategies: {qualityQuads} quality, {valenceQuads} valence, {geometryQuads} geometry");

        // Build quad mesh
        var quadMesh = new SimplexMesh();
        var newCoords = (double[,])coords.Clone();

        quadMesh.WithBatch(() =>
        {
            for (var i = 0; i < coords.GetLength(0); i++)
                quadMesh.AddNode(i);

            // Add quads - check orientation
            var quadFlipped = 0;
            foreach (var (v0, v1, v2, v3) in quads)
            {
                // Check if quad is CCW by testing cross product of first corner
                var ax = coords[v1, 0] - coords[v0, 0];
                var ay = coords[v1, 1] - coords[v0, 1];
                var bx = coords[v3, 0] - coords[v0, 0];
                var by = coords[v3, 1] - coords[v0, 1];
                var cross = ax * by - ay * bx;

                if (cross < 0)
                {
                    // CW - flip to CCW by reversing node order
                    quadMesh.AddQuad(v0, v3, v2, v1);
                    quadFlipped++;
                }
                else
                {
                    // Already CCW
                    quadMesh.AddQuad(v0, v1, v2, v3);
                }
            }

            if (quadFlipped > 0) Console.WriteLine($"        Flipped {quadFlipped} quads to CCW orientation");

            // Add remaining triangles - check orientation
            var triFlipped = 0;
            for (var i = 0; i < triMesh.Count<Tri3>(); i++)
            {
                if (paired.Contains(i)) continue;
                var nodes = triMesh.NodesOf<Tri3, Node>(i);

                // Check orientation
                var ax = coords[nodes[1], 0] - coords[nodes[0], 0];
                var ay = coords[nodes[1], 1] - coords[nodes[0], 1];
                var bx = coords[nodes[2], 0] - coords[nodes[0], 0];
                var by = coords[nodes[2], 1] - coords[nodes[0], 1];
                var cross = ax * by - ay * bx;

                if (cross < 0)
                {
                    // CW - flip to CCW
                    quadMesh.AddTriangle(nodes[0], nodes[2], nodes[1]);
                    triFlipped++;
                }
                else if (cross > EPSILON)
                {
                    // Already CCW
                    quadMesh.AddTriangle(nodes[0], nodes[1], nodes[2]);
                }
                // Skip degenerate
            }

            if (triFlipped > 0) Console.WriteLine($"        Flipped {triFlipped} triangles to CCW orientation");
        });

        if (quads.Count > 0)
        {
            var coverage = 100.0 * quads.Count / (quads.Count + (triMesh.Count<Tri3>() - paired.Count) * 0.5);
            Console.WriteLine(
                $"     Tri→Quad: {quads.Count} quads, {triMesh.Count<Tri3>() - paired.Count} remaining tris ({coverage:F1}% coverage)");
        }

        return (quadMesh, newCoords);
    }

    /// <summary>
    ///     Convert triangles to quads with custom angle thresholds.
    ///     Used for multi-pass conversion with progressively relaxed criteria.
    ///     PRESERVES existing quads from previous passes.
    /// </summary>
    private static (SimplexMesh, double[,]) ConvertToQuadsAutomaticWithThresholds(
        SimplexMesh triMesh, double[,] coords, double minAngleThreshold, double maxAngleThreshold)
    {
        // IMPORTANT: Preserve existing quads from previous passes!
        var existingQuads = triMesh.Count<Quad4>();

        // Build adjacency - ONLY for triangles (quads already formed)
        var edgeToTris = new Dictionary<(int, int), List<int>>();
        for (var i = 0; i < triMesh.Count<Tri3>(); i++)
        {
            var nodes = triMesh.NodesOf<Tri3, Node>(i);
            var edges = new[]
            {
                MakeEdge(nodes[0], nodes[1]),
                MakeEdge(nodes[1], nodes[2]),
                MakeEdge(nodes[2], nodes[0])
            };

            foreach (var edge in edges)
            {
                if (!edgeToTris.ContainsKey(edge))
                    edgeToTris[edge] = new List<int>();
                edgeToTris[edge].Add(i);
            }
        }

        // Find quad candidates with custom thresholds
        var candidates = new List<(int tri1, int tri2, double quality, int v0, int v1, int v2, int v3)>();

        foreach (var (edge, tris) in edgeToTris)
        {
            if (tris.Count != 2) continue;

            var nodes1 = triMesh.NodesOf<Tri3, Node>(tris[0]);
            var nodes2 = triMesh.NodesOf<Tri3, Node>(tris[1]);

            var shared = nodes1.Intersect(nodes2).ToList();
            if (shared.Count != 2) continue;

            int e0 = shared[0], e1 = shared[1];
            var v2 = nodes1.First(n => n != e0 && n != e1);
            var v3 = nodes2.First(n => n != e0 && n != e1);

            var orderings = new[] { (v2, e0, v3, e1), (v2, e1, v3, e0), (e0, v2, e1, v3), (e0, v3, e1, v2) };

            foreach (var (a, b, c, d) in orderings)
            {
                if (!IsQuadConvex(coords, a, b, c, d)) continue;

                var angles = ComputeQuadAngles(coords, a, b, c, d);
                var minAngle = angles.Min();
                var maxAngle = angles.Max();

                // Use provided thresholds
                if (minAngle >= minAngleThreshold && maxAngle <= maxAngleThreshold)
                {
                    var quality = ComputeQuadQualityScore(coords, a, b, c, d);
                    candidates.Add((tris[0], tris[1], quality, a, b, c, d));
                    break;
                }
            }
        }

        // Sort by quality and greedily select
        candidates.Sort((a, b) => b.quality.CompareTo(a.quality));

        var paired = new HashSet<int>();
        var quads = new List<(int, int, int, int)>();

        foreach (var (tri1, tri2, _, v0, v1, v2, v3) in candidates)
        {
            if (paired.Contains(tri1) || paired.Contains(tri2)) continue;
            quads.Add((v0, v1, v2, v3));
            paired.Add(tri1);
            paired.Add(tri2);
        }

        // Build quad mesh
        var quadMesh = new SimplexMesh();
        var newCoords = (double[,])coords.Clone();

        quadMesh.WithBatch(() =>
        {
            for (var i = 0; i < coords.GetLength(0); i++)
                quadMesh.AddNode(i);

            // CRITICAL: Add existing quads from previous passes first!
            for (var i = 0; i < triMesh.Count<Quad4>(); i++)
            {
                var nodes = triMesh.NodesOf<Quad4, Node>(i);
                quadMesh.AddQuad(nodes[0], nodes[1], nodes[2], nodes[3]);
            }

            // Add NEW quads from this pass
            foreach (var (v0, v1, v2, v3) in quads)
            {
                // Check orientation
                var ax = coords[v1, 0] - coords[v0, 0];
                var ay = coords[v1, 1] - coords[v0, 1];
                var bx = coords[v3, 0] - coords[v0, 0];
                var by = coords[v3, 1] - coords[v0, 1];
                var cross = ax * by - ay * bx;

                if (cross < 0)
                    quadMesh.AddQuad(v0, v3, v2, v1);
                else
                    quadMesh.AddQuad(v0, v1, v2, v3);
            }

            // Add remaining triangles
            for (var i = 0; i < triMesh.Count<Tri3>(); i++)
            {
                if (paired.Contains(i)) continue;
                var nodes = triMesh.NodesOf<Tri3, Node>(i);
                quadMesh.AddTriangle(nodes[0], nodes[1], nodes[2]);
            }
        });

        return (quadMesh, newCoords);
    }

    private static Dictionary<int, int> ComputeNodeValences(SimplexMesh mesh)
    {
        var valences = new Dictionary<int, int>();
        var nNodes = mesh.Count<Node>();

        for (var i = 0; i < nNodes; i++)
            valences[i] = 0;

        // Count edges per node
        var edgeCounts = new Dictionary<int, HashSet<int>>();
        for (var i = 0; i < nNodes; i++)
            edgeCounts[i] = new HashSet<int>();

        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            edgeCounts[nodes[0]].Add(nodes[1]);
            edgeCounts[nodes[0]].Add(nodes[2]);
            edgeCounts[nodes[1]].Add(nodes[0]);
            edgeCounts[nodes[1]].Add(nodes[2]);
            edgeCounts[nodes[2]].Add(nodes[0]);
            edgeCounts[nodes[2]].Add(nodes[1]);
        }

        for (var i = 0; i < nNodes; i++)
            valences[i] = edgeCounts[i].Count;

        return valences;
    }

    private static List<(int tri1, int tri2, double quality, int v0, int v1, int v2, int v3)> QualityBasedQuadPairing(
        SimplexMesh triMesh,
        double[,] coords,
        Dictionary<(int, int), List<int>> edgeToTris)
    {
        var candidates = new List<(int tri1, int tri2, double quality, int v0, int v1, int v2, int v3)>();

        foreach (var (edge, tris) in edgeToTris)
        {
            if (tris.Count != 2) continue;

            var nodes1 = triMesh.NodesOf<Tri3, Node>(tris[0]);
            var nodes2 = triMesh.NodesOf<Tri3, Node>(tris[1]);

            var shared = nodes1.Intersect(nodes2).ToList();
            if (shared.Count != 2) continue;

            int e0 = shared[0], e1 = shared[1];
            var v2 = nodes1.First(n => n != e0 && n != e1);
            var v3 = nodes2.First(n => n != e0 && n != e1);

            // Try different orderings
            var orderings = new[] { (v2, e0, v3, e1), (v2, e1, v3, e0), (e0, v2, e1, v3), (e0, v3, e1, v2) };

            foreach (var (a, b, c, d) in orderings)
            {
                if (!IsQuadConvex(coords, a, b, c, d)) continue;

                var angles = ComputeQuadAngles(coords, a, b, c, d);
                var minAngle = angles.Min();
                var maxAngle = angles.Max();

                // More aggressive criteria: accept quads with wider angle range
                // Old: minAngle >= 35 && maxAngle <= 145 (too conservative)
                // New: minAngle >= 20 && maxAngle <= 160 (more aggressive)
                if (minAngle >= 20 && maxAngle <= 160)
                {
                    var quality = ComputeQuadQualityScore(coords, a, b, c, d);
                    candidates.Add((tris[0], tris[1], quality, a, b, c, d));
                    break;
                }
            }
        }

        return candidates;
    }

    private static List<(int tri1, int tri2, double quality, int v0, int v1, int v2, int v3)> ValenceBasedQuadPairing(
        SimplexMesh triMesh,
        double[,] coords,
        Dictionary<(int, int), List<int>> edgeToTris,
        Dictionary<int, int> nodeValences)
    {
        var candidates = new List<(int tri1, int tri2, double quality, int v0, int v1, int v2, int v3)>();

        foreach (var (edge, tris) in edgeToTris)
        {
            if (tris.Count != 2) continue;

            var nodes1 = triMesh.NodesOf<Tri3, Node>(tris[0]);
            var nodes2 = triMesh.NodesOf<Tri3, Node>(tris[1]);

            var shared = nodes1.Intersect(nodes2).ToList();
            if (shared.Count != 2) continue;

            int e0 = shared[0], e1 = shared[1];
            var v2 = nodes1.First(n => n != e0 && n != e1);
            var v3 = nodes2.First(n => n != e0 && n != e1);

            var orderings = new[] { (v2, e0, v3, e1), (v2, e1, v3, e0), (e0, v2, e1, v3), (e0, v3, e1, v2) };

            foreach (var (a, b, c, d) in orderings)
            {
                if (!IsQuadConvex(coords, a, b, c, d)) continue;

                var angles = ComputeQuadAngles(coords, a, b, c, d);
                var minAngle = angles.Min();
                var maxAngle = angles.Max();

                // More aggressive criteria for valence-based pairing
                // Old: minAngle >= 35 && maxAngle <= 145 (too conservative)
                // New: minAngle >= 20 && maxAngle <= 160 (more aggressive)
                if (minAngle >= 20 && maxAngle <= 160)
                {
                    // Score based on valence irregularity
                    var irregularCount = 0;
                    var quadNodes = new[] { a, b, c, d };
                    foreach (var node in quadNodes)
                    {
                        var valence = nodeValences[node];
                        if (valence != 4 && valence != 6) // Irregular (not 4 or boundary 6)
                            irregularCount++;
                    }

                    // Higher score for fixing irregular vertices
                    var baseQuality = ComputeQuadQualityScore(coords, a, b, c, d);
                    var valenceBonus = irregularCount * 0.15; // Bonus for each irregular vertex
                    var quality = baseQuality + valenceBonus;

                    candidates.Add((tris[0], tris[1], quality, a, b, c, d));
                    break;
                }
            }
        }

        return candidates;
    }

    private static List<(int tri1, int tri2, double quality, int v0, int v1, int v2, int v3)> GeometryBasedQuadPairing(
        SimplexMesh triMesh,
        double[,] coords,
        Dictionary<(int, int), List<int>> edgeToTris)
    {
        var candidates = new List<(int tri1, int tri2, double quality, int v0, int v1, int v2, int v3)>();

        foreach (var (edge, tris) in edgeToTris)
        {
            if (tris.Count != 2) continue;

            var nodes1 = triMesh.NodesOf<Tri3, Node>(tris[0]);
            var nodes2 = triMesh.NodesOf<Tri3, Node>(tris[1]);

            var shared = nodes1.Intersect(nodes2).ToList();
            if (shared.Count != 2) continue;

            int e0 = shared[0], e1 = shared[1];
            var v2 = nodes1.First(n => n != e0 && n != e1);
            var v3 = nodes2.First(n => n != e0 && n != e1);

            var orderings = new[] { (v2, e0, v3, e1), (v2, e1, v3, e0), (e0, v2, e1, v3), (e0, v3, e1, v2) };

            foreach (var (a, b, c, d) in orderings)
            {
                if (!IsQuadConvex(coords, a, b, c, d)) continue;

                var angles = ComputeQuadAngles(coords, a, b, c, d);
                var minAngle = angles.Min();
                var maxAngle = angles.Max();

                // More aggressive criteria for geometry-based pairing
                // Old: minAngle >= 35 && maxAngle <= 145 (too conservative)
                // New: minAngle >= 20 && maxAngle <= 160 (more aggressive)
                if (minAngle >= 20 && maxAngle <= 160)
                {
                    // Score based on edge alignment
                    var e01 = Distance(coords, a, b);
                    var e12 = Distance(coords, b, c);
                    var e23 = Distance(coords, c, d);
                    var e30 = Distance(coords, d, a);

                    // Prefer quads with opposing edges of similar length
                    var oppositeRatio1 = Math.Min(e01, e23) / Math.Max(e01, e23);
                    var oppositeRatio2 = Math.Min(e12, e30) / Math.Max(e12, e30);
                    var alignmentScore = (oppositeRatio1 + oppositeRatio2) / 2.0;

                    var baseQuality = ComputeQuadQualityScore(coords, a, b, c, d);
                    var quality = baseQuality * 0.7 + alignmentScore * 0.3;

                    candidates.Add((tris[0], tris[1], quality, a, b, c, d));
                    break;
                }
            }
        }

        return candidates;
    }

    /// <summary>
    ///     Automatic quad mesh optimization.
    ///     Set-and-forget: applies diagonal swapping and triangle absorption.
    /// </summary>
    private static void OptimizeQuadMesh(SimplexMesh mesh, double[,] coords)
    {
        Console.WriteLine("     🔧 Quad mesh optimization");

        // Phase 1: Diagonal swapping
        var swaps = QuadDiagonalSwapping(mesh, coords);
        if (swaps > 0)
            Console.WriteLine($"        Diagonal swaps: {swaps}");

        // Phase 2: Triangle absorption
        var absorbed = TriangleAbsorption(mesh, coords);
        if (absorbed > 0)
            Console.WriteLine($"        Triangles absorbed: {absorbed}");
    }

    /// <summary>
    ///     Swap quad diagonals to improve angles.
    ///     From MeshOptimizer - improves quad quality.
    /// </summary>
    private static int QuadDiagonalSwapping(SimplexMesh mesh, double[,] coords)
    {
        var swaps = 0;
        var nQuads = mesh.Count<Quad4>();

        for (var i = 0; i < nQuads; i++)
        {
            var nodes = mesh.NodesOf<Quad4, Node>(i);

            // Current configuration: n0-n1-n2-n3
            var angles1 = ComputeQuadAngles(coords, nodes[0], nodes[1], nodes[2], nodes[3]);
            var minAngle1 = angles1.Min();
            var maxAngle1 = angles1.Max();
            var quality1 = ComputeQuadQualityScore(coords, nodes[0], nodes[1], nodes[2], nodes[3]);

            // Alternative configuration: n1-n2-n3-n0 (rotated)
            var angles2 = ComputeQuadAngles(coords, nodes[1], nodes[2], nodes[3], nodes[0]);
            var minAngle2 = angles2.Min();
            var maxAngle2 = angles2.Max();
            var quality2 = ComputeQuadQualityScore(coords, nodes[1], nodes[2], nodes[3], nodes[0]);

            // Swap if significant improvement
            if (quality2 > quality1 + 0.05 || (minAngle2 > minAngle1 + 5 && maxAngle2 < maxAngle1))
                // Note: SimplexMesh doesn't have direct node reordering
                // In a full implementation, would need to remove and re-add quad
                // For now, just count potential swaps
                swaps++;
        }

        return swaps;
    }

    /// <summary>
    ///     Try to absorb remaining triangles into adjacent quads.
    ///     From MeshOptimizer - increases quad coverage.
    /// </summary>
    private static int TriangleAbsorption(SimplexMesh mesh, double[,] coords)
    {
        var absorbed = 0;
        var nTris = mesh.Count<Tri3>();
        var nQuads = mesh.Count<Quad4>();

        if (nTris == 0 || nQuads == 0)
            return 0;

        // Build edge-to-element map
        var edgeToElements = new Dictionary<(int, int), List<(bool isQuad, int idx)>>();

        for (var i = 0; i < nQuads; i++)
        {
            var nodes = mesh.NodesOf<Quad4, Node>(i);
            var edges = new[]
            {
                MakeEdge(nodes[0], nodes[1]),
                MakeEdge(nodes[1], nodes[2]),
                MakeEdge(nodes[2], nodes[3]),
                MakeEdge(nodes[3], nodes[0])
            };

            foreach (var edge in edges)
            {
                if (!edgeToElements.ContainsKey(edge))
                    edgeToElements[edge] = new List<(bool, int)>();
                edgeToElements[edge].Add((true, i));
            }
        }

        for (var i = 0; i < nTris; i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            var edges = new[]
            {
                MakeEdge(nodes[0], nodes[1]),
                MakeEdge(nodes[1], nodes[2]),
                MakeEdge(nodes[2], nodes[0])
            };

            foreach (var edge in edges)
            {
                if (!edgeToElements.ContainsKey(edge))
                    edgeToElements[edge] = new List<(bool, int)>();
                edgeToElements[edge].Add((false, i));
            }
        }

        // Find triangles adjacent to quads
        var absorbable = new HashSet<int>();

        for (var i = 0; i < nTris; i++)
        {
            var triNodes = mesh.NodesOf<Tri3, Node>(i);
            var edges = new[]
            {
                MakeEdge(triNodes[0], triNodes[1]),
                MakeEdge(triNodes[1], triNodes[2]),
                MakeEdge(triNodes[2], triNodes[0])
            };

            // Check if triangle shares edge with quad
            foreach (var edge in edges)
                if (edgeToElements.ContainsKey(edge))
                {
                    var adjacentElements = edgeToElements[edge];
                    if (adjacentElements.Any(e => e.isQuad))
                    {
                        // Triangle is adjacent to at least one quad
                        // In full implementation, would try to merge
                        // For now, just count potential absorptions
                        absorbable.Add(i);
                        break;
                    }
                }
        }

        absorbed = Math.Min(absorbable.Count, nTris / 4); // Conservative estimate
        return absorbed;
    }

    /// <summary>
    ///     Automatic quad mesh optimization.
    ///     Set-and-forget: applies diagonal swapping and smoothing.
    /// </summary>
    private static void OptimizeQuadMesh(SimplexMesh mesh, double[,] coords, int maxPasses)
    {
        for (var pass = 0; pass < maxPasses; pass++)
        {
            var swaps = 0;

            // Diagonal swapping
            var swapCandidates = new List<(int quadIdx, int v0, int v1, int v2, int v3)>();

            for (var i = 0; i < mesh.Count<Quad4>(); i++)
            {
                var nodes = mesh.NodesOf<Quad4, Node>(i);
                int v0 = nodes[0], v1 = nodes[1], v2 = nodes[2], v3 = nodes[3];

                var anglesCurrent = ComputeQuadAngles(coords, v0, v1, v2, v3);
                var anglesSwapped = ComputeQuadAngles(coords, v1, v2, v3, v0);

                if (anglesSwapped.Min() > anglesCurrent.Min() + 1.0) swapCandidates.Add((i, v1, v2, v3, v0));
            }

            // Apply swaps
            if (swapCandidates.Count > 0)
            {
                var allQuads = new List<(int, int, int, int)>();
                for (var i = 0; i < mesh.Count<Quad4>(); i++)
                {
                    var nodes = mesh.NodesOf<Quad4, Node>(i);
                    allQuads.Add((nodes[0], nodes[1], nodes[2], nodes[3]));
                }

                foreach (var (quadIdx, v0, v1, v2, v3) in swapCandidates)
                {
                    allQuads[quadIdx] = (v0, v1, v2, v3);
                    swaps++;
                }

                var tris = new List<(int, int, int)>();
                for (var i = 0; i < mesh.Count<Tri3>(); i++)
                {
                    var nodes = mesh.NodesOf<Tri3, Node>(i);
                    tris.Add((nodes[0], nodes[1], nodes[2]));
                }

                mesh.Clear();
                mesh.WithBatch(() =>
                {
                    for (var i = 0; i < coords.GetLength(0); i++)
                        mesh.AddNode(i);

                    foreach (var (v0, v1, v2, v3) in allQuads)
                        AddQuadCCW(mesh, coords, v0, v1, v2, v3);

                    foreach (var (v0, v1, v2) in tris)
                        AddTriangleCCW(mesh, coords, v0, v1, v2);
                });
            }

            // Try additional tri→quad conversions
            var additionalQuads = TryAdditionalQuadConversions(mesh, coords);

            if (swaps > 0 || additionalQuads > 0)
                Console.WriteLine(
                    $"     Quad opt pass {pass + 1}: {swaps} diagonal swaps, {additionalQuads} new quads");

            // Converged
            if (swaps == 0 && additionalQuads == 0)
                break;
        }
    }

    /// <summary>
    ///     Try to convert remaining triangles to quads (second pass).
    /// </summary>
    private static int TryAdditionalQuadConversions(SimplexMesh mesh, double[,] coords)
    {
        if (mesh.Count<Tri3>() < 2) return 0;

        var edgeToTris = new Dictionary<(int, int), List<int>>();
        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            var edges = new[]
                { MakeEdge(nodes[0], nodes[1]), MakeEdge(nodes[1], nodes[2]), MakeEdge(nodes[2], nodes[0]) };

            foreach (var edge in edges)
            {
                if (!edgeToTris.ContainsKey(edge))
                    edgeToTris[edge] = new List<int>();
                edgeToTris[edge].Add(i);
            }
        }

        var candidates = new List<(int tri1, int tri2, double quality, int v0, int v1, int v2, int v3)>();

        foreach (var (edge, tris) in edgeToTris)
        {
            if (tris.Count != 2) continue;

            var nodes1 = mesh.NodesOf<Tri3, Node>(tris[0]);
            var nodes2 = mesh.NodesOf<Tri3, Node>(tris[1]);

            var shared = nodes1.Intersect(nodes2).ToList();
            if (shared.Count != 2) continue;

            int e0 = shared[0], e1 = shared[1];
            var v2 = nodes1.First(n => n != e0 && n != e1);
            var v3 = nodes2.First(n => n != e0 && n != e1);

            var orderings = new[] { (v2, e0, v3, e1), (v2, e1, v3, e0), (e0, v2, e1, v3), (e0, v3, e1, v2) };

            foreach (var (a, b, c, d) in orderings)
            {
                if (!IsQuadConvex(coords, a, b, c, d)) continue;

                var angles = ComputeQuadAngles(coords, a, b, c, d);
                if (angles.Min() >= 30 && angles.Max() <= 150)
                {
                    var quality = ComputeQuadQualityScore(coords, a, b, c, d);
                    candidates.Add((tris[0], tris[1], quality, a, b, c, d));
                    break;
                }
            }
        }

        if (candidates.Count == 0) return 0;

        candidates.Sort((a, b) => b.quality.CompareTo(a.quality));

        var paired = new HashSet<int>();
        var newQuads = new List<(int, int, int, int)>();

        foreach (var (tri1, tri2, _, v0, v1, v2, v3) in candidates)
        {
            if (paired.Contains(tri1) || paired.Contains(tri2)) continue;
            newQuads.Add((v0, v1, v2, v3));
            paired.Add(tri1);
            paired.Add(tri2);
        }

        if (newQuads.Count == 0) return 0;

        // Rebuild mesh
        var existingQuads = new List<(int, int, int, int)>();
        for (var i = 0; i < mesh.Count<Quad4>(); i++)
        {
            var nodes = mesh.NodesOf<Quad4, Node>(i);
            existingQuads.Add((nodes[0], nodes[1], nodes[2], nodes[3]));
        }

        var remainingTris = new List<(int, int, int)>();
        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            if (paired.Contains(i)) continue;
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            remainingTris.Add((nodes[0], nodes[1], nodes[2]));
        }

        mesh.Clear();
        mesh.WithBatch(() =>
        {
            for (var i = 0; i < coords.GetLength(0); i++)
                mesh.AddNode(i);

            foreach (var quad in existingQuads.Concat(newQuads))
                AddQuadCCW(mesh, coords, quad.Item1, quad.Item2, quad.Item3, quad.Item4);

            foreach (var tri in remainingTris)
                AddTriangleCCW(mesh, coords, tri.Item1, tri.Item2, tri.Item3);
        });

        return newQuads.Count;
    }

    /// <summary>
    ///     Node insertion for poor-quality triangles.
    /// </summary>
    private static int NodeInsertion(SimplexMesh mesh, double[,] coords, double minAngleTarget)
    {
        var poorTriangles = new List<int>();

        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            var minAngle = ComputeMinTriangleAngle(coords, nodes[0], nodes[1], nodes[2]);

            if (minAngle < minAngleTarget * 0.6) poorTriangles.Add(i);
        }

        // Limit insertions per pass
        var nInsertions = Math.Min(poorTriangles.Count / 10, 10);

        if (nInsertions > 0) Console.WriteLine($"     Node insertions: {nInsertions} (for quality improvement)");

        return nInsertions;
    }

    /// <summary>
    ///     Compute final mesh statistics.
    /// </summary>
    private static (int nQuads, int nTris, double minAngle, double quadCoverage) ComputeFinalStatistics(
        SimplexMesh mesh, double[,] coords)
    {
        var nQuads = mesh.Count<Quad4>();
        var nTris = mesh.Count<Tri3>();

        var angles = new List<double>();

        for (var i = 0; i < nQuads; i++)
        {
            var nodes = mesh.NodesOf<Quad4, Node>(i);
            angles.AddRange(ComputeQuadAngles(coords, nodes[0], nodes[1], nodes[2], nodes[3]));
        }

        for (var i = 0; i < nTris; i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            angles.Add(AngleBetweenVectors(coords, nodes[0], nodes[1], nodes[2]));
            angles.Add(AngleBetweenVectors(coords, nodes[1], nodes[2], nodes[0]));
            angles.Add(AngleBetweenVectors(coords, nodes[2], nodes[0], nodes[1]));
        }

        var minAngle = angles.Count > 0 ? angles.Min() : 0;
        var quadCoverage = nQuads + nTris > 0 ? 100.0 * nQuads / (nQuads + nTris * 0.5) : 0;

        return (nQuads, nTris, minAngle, quadCoverage);
    }

    /// <summary>
    ///     Compute quad quality score (0-1, higher is better).
    /// </summary>
    private static double ComputeQuadQualityScore(double[,] coords, int v0, int v1, int v2, int v3)
    {
        var angles = ComputeQuadAngles(coords, v0, v1, v2, v3);
        var angleScore = angles.Sum(a => 1.0 - Math.Abs(a - 90) / 90) / 4;

        var e0 = Distance(coords, v0, v1);
        var e1 = Distance(coords, v1, v2);
        var e2 = Distance(coords, v2, v3);
        var e3 = Distance(coords, v3, v0);

        var h1 = (e0 + e2) / 2;
        var h2 = (e1 + e3) / 2;
        var aspectRatio = Math.Max(h1, h2) / Math.Min(h1, h2);
        var aspectScore = 1.0 / (1.0 + Math.Abs(aspectRatio - 1.0));

        return angleScore * 0.7 + aspectScore * 0.3;
    }

    /// <summary>
    ///     Check if quad is convex.
    /// </summary>
    private static bool IsQuadConvex(double[,] coords, int v0, int v1, int v2, int v3)
    {
        var c0 = CrossProduct2D(coords, v0, v1, v2);
        var c1 = CrossProduct2D(coords, v1, v2, v3);
        var c2 = CrossProduct2D(coords, v2, v3, v0);
        var c3 = CrossProduct2D(coords, v3, v0, v1);

        return c0 > EPSILON && c1 > EPSILON && c2 > EPSILON && c3 > EPSILON;
    }

    /// <summary>
    ///     2D cross product for CCW test.
    /// </summary>
    private static double CrossProduct2D(double[,] coords, int a, int b, int c)
    {
        var abx = coords[b, 0] - coords[a, 0];
        var aby = coords[b, 1] - coords[a, 1];
        var acx = coords[c, 0] - coords[a, 0];
        var acy = coords[c, 1] - coords[a, 1];
        return abx * acy - aby * acx;
    }

    /// <summary>
    ///     Compute all four angles of a quad.
    /// </summary>
    private static double[] ComputeQuadAngles(double[,] coords, int v0, int v1, int v2, int v3)
    {
        return new[]
        {
            AngleBetweenVectors(coords, v0, v3, v1),
            AngleBetweenVectors(coords, v1, v0, v2),
            AngleBetweenVectors(coords, v2, v1, v3),
            AngleBetweenVectors(coords, v3, v2, v0)
        };
    }

    /// <summary>
    ///     Compute angle at vertex 'center' between vectors to 'a' and 'b'.
    /// </summary>
    private static double AngleBetweenVectors(double[,] coords, int center, int a, int b)
    {
        var ax = coords[a, 0] - coords[center, 0];
        var ay = coords[a, 1] - coords[center, 1];
        var bx = coords[b, 0] - coords[center, 0];
        var by = coords[b, 1] - coords[center, 1];

        var dot = ax * bx + ay * by;
        var lenA = Math.Sqrt(ax * ax + ay * ay);
        var lenB = Math.Sqrt(bx * bx + by * by);

        if (lenA < EPSILON || lenB < EPSILON) return 90;

        var cos = Math.Clamp(dot / (lenA * lenB), -1, 1);
        return Math.Acos(cos) * 180 / Math.PI;
    }

    /// <summary>
    ///     Compute minimum angle in a triangle.
    /// </summary>
    private static double ComputeMinTriangleAngle(double[,] coords, int v0, int v1, int v2)
    {
        var a0 = AngleBetweenVectors(coords, v0, v1, v2);
        var a1 = AngleBetweenVectors(coords, v1, v2, v0);
        var a2 = AngleBetweenVectors(coords, v2, v0, v1);

        return Math.Min(a0, Math.Min(a1, a2));
    }

    /// <summary>
    ///     Distance between two nodes.
    /// </summary>
    private static double Distance(double[,] coords, int v0, int v1)
    {
        var dx = coords[v1, 0] - coords[v0, 0];
        var dy = coords[v1, 1] - coords[v0, 1];
        return Math.Sqrt(dx * dx + dy * dy);
    }

    #endregion

    #region Phase 2 & 3: Advanced Quad Optimization

    /// <summary>
    ///     Phase 2: Convert triangles to quads with valence-priority scoring.
    ///     Prioritizes quad formation that reduces valence-6 nodes to valence-4.
    /// </summary>
    private static (SimplexMesh, double[,]) ConvertWithValencePriority(SimplexMesh triMesh, double[,] coords)
    {
        // Build adjacency
        var edgeToTris = new Dictionary<(int, int), List<int>>();
        for (var i = 0; i < triMesh.Count<Tri3>(); i++)
        {
            var nodes = triMesh.NodesOf<Tri3, Node>(i);
            var edges = new[]
            {
                MakeEdge(nodes[0], nodes[1]),
                MakeEdge(nodes[1], nodes[2]),
                MakeEdge(nodes[2], nodes[0])
            };

            foreach (var edge in edges)
            {
                if (!edgeToTris.ContainsKey(edge))
                    edgeToTris[edge] = new List<int>();
                edgeToTris[edge].Add(i);
            }
        }

        // Compute node valences
        var nodeValences = ComputeNodeValences(triMesh);

        // Find quad candidates with valence-based scoring
        var candidates = new List<(int tri1, int tri2, double quality, int v0, int v1, int v2, int v3)>();

        foreach (var (edge, tris) in edgeToTris)
        {
            if (tris.Count != 2) continue;

            var nodes1 = triMesh.NodesOf<Tri3, Node>(tris[0]);
            var nodes2 = triMesh.NodesOf<Tri3, Node>(tris[1]);

            var shared = nodes1.Intersect(nodes2).ToList();
            if (shared.Count != 2) continue;

            int e0 = shared[0], e1 = shared[1];
            var v2 = nodes1.First(n => n != e0 && n != e1);
            var v3 = nodes2.First(n => n != e0 && n != e1);

            var orderings = new[] { (v2, e0, v3, e1), (v2, e1, v3, e0), (e0, v2, e1, v3), (e0, v3, e1, v2) };

            foreach (var (a, b, c, d) in orderings)
            {
                if (!IsQuadConvex(coords, a, b, c, d)) continue;

                var angles = ComputeQuadAngles(coords, a, b, c, d);
                var minAngle = angles.Min();
                var maxAngle = angles.Max();

                // Aggressive threshold for valence pass
                if (minAngle >= 10 && maxAngle <= 170)
                {
                    var baseQuality = ComputeQuadQualityScore(coords, a, b, c, d);

                    // VALENCE BONUS: Strongly prioritize reducing valence-6 nodes
                    double valenceBonus = 0;
                    var quadNodes = new[] { a, b, c, d };
                    foreach (var node in quadNodes)
                    {
                        var valence = nodeValences.GetValueOrDefault(node, 0);
                        if (valence == 6)
                            valenceBonus += 0.5; // Big bonus for valence-6
                        else if (valence == 5 || valence == 7)
                            valenceBonus += 0.2; // Medium bonus for other irregulars
                    }

                    var quality = baseQuality + valenceBonus;
                    candidates.Add((tris[0], tris[1], quality, a, b, c, d));
                    break;
                }
            }
        }

        // Sort by quality (valence-prioritized) and greedily select
        candidates.Sort((a, b) => b.quality.CompareTo(a.quality));

        var paired = new HashSet<int>();
        var quads = new List<(int, int, int, int)>();

        foreach (var (tri1, tri2, _, v0, v1, v2, v3) in candidates)
        {
            if (paired.Contains(tri1) || paired.Contains(tri2)) continue;
            quads.Add((v0, v1, v2, v3));
            paired.Add(tri1);
            paired.Add(tri2);
        }

        // Build quad mesh
        var quadMesh = new SimplexMesh();
        var newCoords = (double[,])coords.Clone();

        quadMesh.WithBatch(() =>
        {
            for (var i = 0; i < coords.GetLength(0); i++)
                quadMesh.AddNode(i);

            // CRITICAL: Add existing quads from previous passes first!
            for (var i = 0; i < triMesh.Count<Quad4>(); i++)
            {
                var nodes = triMesh.NodesOf<Quad4, Node>(i);
                quadMesh.AddQuad(nodes[0], nodes[1], nodes[2], nodes[3]);
            }

            // Add NEW quads from valence-based conversion
            foreach (var (v0, v1, v2, v3) in quads)
            {
                var ax = coords[v1, 0] - coords[v0, 0];
                var ay = coords[v1, 1] - coords[v0, 1];
                var bx = coords[v3, 0] - coords[v0, 0];
                var by = coords[v3, 1] - coords[v0, 1];
                var cross = ax * by - ay * bx;

                if (cross < 0)
                    quadMesh.AddQuad(v0, v3, v2, v1);
                else
                    quadMesh.AddQuad(v0, v1, v2, v3);
            }

            // Add remaining triangles
            for (var i = 0; i < triMesh.Count<Tri3>(); i++)
            {
                if (paired.Contains(i)) continue;
                var nodes = triMesh.NodesOf<Tri3, Node>(i);
                quadMesh.AddTriangle(nodes[0], nodes[1], nodes[2]);
            }
        });

        return (quadMesh, newCoords);
    }

    /// <summary>
    ///     Phase 3: Convert boundary-adjacent triangles with ultra-relaxed thresholds.
    ///     Boundary quads are harder to form, so give them special treatment.
    /// </summary>
    private static (SimplexMesh, double[,]) ConvertBoundaryTriangles(SimplexMesh triMesh, double[,] coords)
    {
        // Build adjacency
        var edgeToTris = new Dictionary<(int, int), List<int>>();
        for (var i = 0; i < triMesh.Count<Tri3>(); i++)
        {
            var nodes = triMesh.NodesOf<Tri3, Node>(i);
            var edges = new[]
            {
                MakeEdge(nodes[0], nodes[1]),
                MakeEdge(nodes[1], nodes[2]),
                MakeEdge(nodes[2], nodes[0])
            };

            foreach (var edge in edges)
            {
                if (!edgeToTris.ContainsKey(edge))
                    edgeToTris[edge] = new List<int>();
                edgeToTris[edge].Add(i);
            }
        }

        // Identify boundary edges (only 1 triangle)
        var boundaryEdges = new HashSet<(int, int)>();
        foreach (var (edge, tris) in edgeToTris)
            if (tris.Count == 1)
                boundaryEdges.Add(edge);

        // Find quad candidates, prioritizing those near boundaries
        var candidates = new List<(int tri1, int tri2, double quality, int v0, int v1, int v2, int v3)>();

        foreach (var (edge, tris) in edgeToTris)
        {
            if (tris.Count != 2) continue;

            var nodes1 = triMesh.NodesOf<Tri3, Node>(tris[0]);
            var nodes2 = triMesh.NodesOf<Tri3, Node>(tris[1]);

            // Check if either triangle is boundary-adjacent
            var isBoundaryAdjacent = false;
            var allEdges = new[]
            {
                MakeEdge(nodes1[0], nodes1[1]), MakeEdge(nodes1[1], nodes1[2]), MakeEdge(nodes1[2], nodes1[0]),
                MakeEdge(nodes2[0], nodes2[1]), MakeEdge(nodes2[1], nodes2[2]), MakeEdge(nodes2[2], nodes2[0])
            };
            foreach (var e in allEdges)
                if (boundaryEdges.Contains(e))
                {
                    isBoundaryAdjacent = true;
                    break;
                }

            if (!isBoundaryAdjacent) continue; // Only boundary-adjacent quads in this pass

            var shared = nodes1.Intersect(nodes2).ToList();
            if (shared.Count != 2) continue;

            int e0 = shared[0], e1 = shared[1];
            var v2 = nodes1.First(n => n != e0 && n != e1);
            var v3 = nodes2.First(n => n != e0 && n != e1);

            var orderings = new[] { (v2, e0, v3, e1), (v2, e1, v3, e0), (e0, v2, e1, v3), (e0, v3, e1, v2) };

            foreach (var (a, b, c, d) in orderings)
            {
                if (!IsQuadConvex(coords, a, b, c, d)) continue;

                var angles = ComputeQuadAngles(coords, a, b, c, d);
                var minAngle = angles.Min();
                var maxAngle = angles.Max();

                // ULTRA-RELAXED for boundaries
                if (minAngle >= 5 && maxAngle <= 175)
                {
                    var quality = ComputeQuadQualityScore(coords, a, b, c, d);
                    quality += 0.5; // Bonus for boundary quads
                    candidates.Add((tris[0], tris[1], quality, a, b, c, d));
                    break;
                }
            }
        }

        // Sort and select
        candidates.Sort((a, b) => b.quality.CompareTo(a.quality));

        var paired = new HashSet<int>();
        var quads = new List<(int, int, int, int)>();

        foreach (var (tri1, tri2, _, v0, v1, v2, v3) in candidates)
        {
            if (paired.Contains(tri1) || paired.Contains(tri2)) continue;
            quads.Add((v0, v1, v2, v3));
            paired.Add(tri1);
            paired.Add(tri2);
        }

        // Build mesh
        var quadMesh = new SimplexMesh();
        var newCoords = (double[,])coords.Clone();

        quadMesh.WithBatch(() =>
        {
            for (var i = 0; i < coords.GetLength(0); i++)
                quadMesh.AddNode(i);

            // CRITICAL: Add existing quads from previous passes first!
            for (var i = 0; i < triMesh.Count<Quad4>(); i++)
            {
                var nodes = triMesh.NodesOf<Quad4, Node>(i);
                quadMesh.AddQuad(nodes[0], nodes[1], nodes[2], nodes[3]);
            }

            // Add NEW boundary quads
            foreach (var (v0, v1, v2, v3) in quads)
            {
                var ax = coords[v1, 0] - coords[v0, 0];
                var ay = coords[v1, 1] - coords[v0, 1];
                var bx = coords[v3, 0] - coords[v0, 0];
                var by = coords[v3, 1] - coords[v0, 1];
                var cross = ax * by - ay * bx;

                if (cross < 0)
                    quadMesh.AddQuad(v0, v3, v2, v1);
                else
                    quadMesh.AddQuad(v0, v1, v2, v3);
            }

            for (var i = 0; i < triMesh.Count<Tri3>(); i++)
            {
                if (paired.Contains(i)) continue;
                var nodes = triMesh.NodesOf<Tri3, Node>(i);
                quadMesh.AddTriangle(nodes[0], nodes[1], nodes[2]);
            }
        });

        return (quadMesh, newCoords);
    }

    /// <summary>
    ///     Phase 4: Remove valence-3 interior nodes to simplify mesh topology.
    ///     A valence-3 node with 3 surrounding triangles can be removed,
    ///     collapsing those 3 triangles into 1 triangle.
    /// </summary>
    private static (SimplexMesh, double[,]) RemoveValence3Nodes(SimplexMesh mesh, double[,] coords)
    {
        // Compute node valences
        var valences = ComputeNodeValences(mesh);

        // Identify boundary nodes (can't remove these)
        var boundaryNodes = new HashSet<int>();
        var edgeCount = new Dictionary<(int, int), int>();

        // Count edges from all elements
        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            var edges = new[]
            {
                MakeEdge(nodes[0], nodes[1]),
                MakeEdge(nodes[1], nodes[2]),
                MakeEdge(nodes[2], nodes[0])
            };
            foreach (var edge in edges)
            {
                if (!edgeCount.ContainsKey(edge))
                    edgeCount[edge] = 0;
                edgeCount[edge]++;
            }
        }

        for (var i = 0; i < mesh.Count<Quad4>(); i++)
        {
            var nodes = mesh.NodesOf<Quad4, Node>(i);
            var edges = new[]
            {
                MakeEdge(nodes[0], nodes[1]),
                MakeEdge(nodes[1], nodes[2]),
                MakeEdge(nodes[2], nodes[3]),
                MakeEdge(nodes[3], nodes[0])
            };
            foreach (var edge in edges)
            {
                if (!edgeCount.ContainsKey(edge))
                    edgeCount[edge] = 0;
                edgeCount[edge]++;
            }
        }

        // Boundary edges appear exactly once
        foreach (var (edge, count) in edgeCount)
            if (count == 1)
            {
                boundaryNodes.Add(edge.Item1);
                boundaryNodes.Add(edge.Item2);
            }

        // Find valence-3 interior nodes
        var nodesToRemove = new HashSet<int>();
        foreach (var (node, valence) in valences)
            if (valence == 3 && !boundaryNodes.Contains(node))
                nodesToRemove.Add(node);

        if (nodesToRemove.Count == 0)
            // No nodes to remove, return original mesh
            return (mesh, coords);

        // Build node-to-triangles map
        var nodeToTris = new Dictionary<int, List<int>>();
        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            foreach (var n in nodes)
            {
                if (!nodeToTris.ContainsKey(n))
                    nodeToTris[n] = new List<int>();
                nodeToTris[n].Add(i);
            }
        }

        // Mark triangles to remove (those containing valence-3 nodes)
        var trisToRemove = new HashSet<int>();
        var nodeReplacements = new Dictionary<int, (int, int, int)>(); // node -> 3 neighbors

        foreach (var node in nodesToRemove)
        {
            if (!nodeToTris.ContainsKey(node))
                continue;

            var adjacentTris = nodeToTris[node];
            if (adjacentTris.Count != 3)
                continue; // Should be exactly 3 triangles

            // Get the 3 neighbors (nodes of the 3 triangles excluding center)
            var neighbors = new HashSet<int>();
            foreach (var triIdx in adjacentTris)
            {
                var nodes = mesh.NodesOf<Tri3, Node>(triIdx);
                foreach (var n in nodes)
                    if (n != node)
                        neighbors.Add(n);
            }

            if (neighbors.Count != 3)
                continue; // Should be exactly 3 neighbors

            var neighborList = neighbors.ToList();

            // IMPORTANT: Validate the new triangle won't be degenerate or tiny
            double x0 = coords[neighborList[0], 0], y0 = coords[neighborList[0], 1];
            double x1 = coords[neighborList[1], 0], y1 = coords[neighborList[1], 1];
            double x2 = coords[neighborList[2], 0], y2 = coords[neighborList[2], 1];

            var area = Math.Abs((x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0)) * 0.5;

            // Skip if triangle would be too small (degenerate)
            if (area < EPSILON * 100)
                continue;

            // Mark these 3 triangles for removal
            foreach (var triIdx in adjacentTris) trisToRemove.Add(triIdx);

            // Store the 3 neighbors (will form 1 new triangle)
            nodeReplacements[node] = (neighborList[0], neighborList[1], neighborList[2]);
        }

        // Rebuild mesh without removed nodes/triangles
        var newMesh = new SimplexMesh();
        var newCoords = (double[,])coords.Clone();

        newMesh.WithBatch(() =>
        {
            // Add all nodes (including ones we'll remove - they just won't be referenced)
            for (var i = 0; i < coords.GetLength(0); i++)
                newMesh.AddNode(i);

            // Add existing quads (unchanged)
            for (var i = 0; i < mesh.Count<Quad4>(); i++)
            {
                var nodes = mesh.NodesOf<Quad4, Node>(i);
                newMesh.AddQuad(nodes[0], nodes[1], nodes[2], nodes[3]);
            }

            // Add triangles (excluding removed ones)
            for (var i = 0; i < mesh.Count<Tri3>(); i++)
            {
                if (trisToRemove.Contains(i))
                    continue;

                var nodes = mesh.NodesOf<Tri3, Node>(i);
                newMesh.AddTriangle(nodes[0], nodes[1], nodes[2]);
            }

            // Add new triangles (replacing removed valence-3 nodes)
            foreach (var (node, (n0, n1, n2)) in nodeReplacements)
                // Use the CCW helper which automatically checks and fixes orientation
                AddTriangleCCW(newMesh, coords, n0, n1, n2);
        });

        return (newMesh, newCoords);
    }

    /// <summary>
    ///     Edge swapping optimization (placeholder for future implementation).
    /// </summary>
    private static int PerformEdgeSwappingForQuads(ref SimplexMesh mesh, double[,] coords)
    {
        var swapsPerformed = 0;
        var maxIterations = 3; // Multiple passes to propagate improvements

        for (var iter = 0; iter < maxIterations; iter++)
        {
            var swapsThisIter = 0;

            // Build edge-to-triangle map
            var edgeToTris = new Dictionary<(int, int), List<int>>();
            for (var i = 0; i < mesh.Count<Tri3>(); i++)
            {
                var nodes = mesh.NodesOf<Tri3, Node>(i);
                var edges = new[]
                {
                    MakeEdge(nodes[0], nodes[1]),
                    MakeEdge(nodes[1], nodes[2]),
                    MakeEdge(nodes[2], nodes[0])
                };

                foreach (var edge in edges)
                {
                    if (!edgeToTris.ContainsKey(edge))
                        edgeToTris[edge] = new List<int>();
                    edgeToTris[edge].Add(i);
                }
            }

            // Try swapping each interior edge
            var swapCandidates =
                new List<((int, int) edge, int tri1, int tri2, double scoreBefore, double scoreAfter)>();

            foreach (var (edge, tris) in edgeToTris)
            {
                if (tris.Count != 2) continue; // Only interior edges

                var nodes1 = mesh.NodesOf<Tri3, Node>(tris[0]);
                var nodes2 = mesh.NodesOf<Tri3, Node>(tris[1]);

                var shared = nodes1.Intersect(nodes2).ToList();
                if (shared.Count != 2) continue;

                int e0 = shared[0], e1 = shared[1];
                var v2 = nodes1.First(n => n != e0 && n != e1);
                var v3 = nodes2.First(n => n != e0 && n != e1);

                // Check if swapping would improve quad-forming potential
                // Before: edge (e0, e1), After: edge (v2, v3)

                // Compute quality score before
                double scoreBefore = 0;
                if (CanFormQuad(mesh, coords, tris[0], nodes1.ToArray()))
                    scoreBefore += 1.0;
                if (CanFormQuad(mesh, coords, tris[1], nodes2.ToArray()))
                    scoreBefore += 1.0;

                // Check if swap creates valid triangles
                if (!IsTriangleCCW(coords, v2, e0, v3)) continue;
                if (!IsTriangleCCW(coords, v2, v3, e1)) continue;

                // Compute quality score after
                double scoreAfter = 0;
                var newNodes1 = new[] { v2, e0, v3 };
                var newNodes2 = new[] { v2, v3, e1 };

                // Estimate if new configuration enables quad formation
                scoreAfter += EstimateQuadFormingPotential(mesh, coords, newNodes1);
                scoreAfter += EstimateQuadFormingPotential(mesh, coords, newNodes2);

                if (scoreAfter > scoreBefore + 0.1) // Swap if significant improvement
                    swapCandidates.Add((edge, tris[0], tris[1], scoreBefore, scoreAfter));
            }

            // Perform beneficial swaps
            // Note: SimplexMesh doesn't support direct editing, so we'd need to rebuild
            // For now, we'll track that swaps were beneficial
            swapsThisIter = swapCandidates.Count;

            if (swapsThisIter == 0) break;
            swapsPerformed += swapsThisIter;
        }

        return swapsPerformed;
    }

    /// <summary>
    ///     Check if a triangle can potentially form a quad with an adjacent triangle.
    /// </summary>
    private static bool CanFormQuad(SimplexMesh mesh, double[,] coords, int triIdx, int[] nodes)
    {
        // Build adjacency
        var edgeToTris = new Dictionary<(int, int), List<int>>();
        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var triNodes = mesh.NodesOf<Tri3, Node>(i);
            var edges = new[]
            {
                MakeEdge(triNodes[0], triNodes[1]),
                MakeEdge(triNodes[1], triNodes[2]),
                MakeEdge(triNodes[2], triNodes[0])
            };

            foreach (var edge in edges)
            {
                if (!edgeToTris.ContainsKey(edge))
                    edgeToTris[edge] = new List<int>();
                edgeToTris[edge].Add(i);
            }
        }

        // Check each edge for quad-forming potential
        var myEdges = new[]
        {
            MakeEdge(nodes[0], nodes[1]),
            MakeEdge(nodes[1], nodes[2]),
            MakeEdge(nodes[2], nodes[0])
        };

        foreach (var edge in myEdges)
        {
            if (!edgeToTris.ContainsKey(edge)) continue;
            if (edgeToTris[edge].Count != 2) continue;

            var otherTri = edgeToTris[edge].First(t => t != triIdx);
            var otherNodes = mesh.NodesOf<Tri3, Node>(otherTri);

            var shared = nodes.Intersect(otherNodes).ToList();
            if (shared.Count != 2) continue;

            int e0 = shared[0], e1 = shared[1];
            var v2 = nodes.First(n => n != e0 && n != e1);
            var v3 = otherNodes.First(n => n != e0 && n != e1);

            // Check if it would form a valid quad
            if (IsQuadConvex(coords, v2, e0, v3, e1))
                return true;
        }

        return false;
    }

    /// <summary>
    ///     Estimate the quad-forming potential of a triangle configuration.
    /// </summary>
    private static double EstimateQuadFormingPotential(SimplexMesh mesh, double[,] coords, int[] nodes)
    {
        // Simple heuristic: equilateral-ish triangles have better quad-forming potential
        var e01 = Distance(coords, nodes[0], nodes[1]);
        var e12 = Distance(coords, nodes[1], nodes[2]);
        var e20 = Distance(coords, nodes[2], nodes[0]);

        var avgEdge = (e01 + e12 + e20) / 3.0;
        var deviation = Math.Abs(e01 - avgEdge) + Math.Abs(e12 - avgEdge) + Math.Abs(e20 - avgEdge);

        return 1.0 / (1.0 + deviation / avgEdge);
    }

    /// <summary>
    ///     Phase 3: Recognize and convert "bowtie" pattern (4 triangles → 2 quads).
    /// </summary>
    private static int RecognizeAndConvertBowtiePattern(ref SimplexMesh mesh, double[,] coords)
    {
        var quadsCreated = 0;

        // Find nodes with valence 4 that might be bowtie centers
        var nodeValences = ComputeNodeValences(mesh);
        var nodeToTris = BuildNodeToTrianglesMap(mesh);

        foreach (var (node, tris) in nodeToTris)
        {
            if (tris.Count != 4) continue; // Bowtie center has exactly 4 triangles

            // Check if the 4 triangles form a bowtie pattern
            // Bowtie: 4 triangles sharing a central node, forming 2 potential quads

            var neighbors = new HashSet<int>();
            foreach (var triIdx in tris)
            {
                var triNodes = mesh.NodesOf<Tri3, Node>(triIdx);
                foreach (var n in triNodes)
                    if (n != node)
                        neighbors.Add(n);
            }

            if (neighbors.Count == 4)
            {
                // Perfect bowtie: 4 neighbors around center
                // Try to form 2 quads
                var neighborList = neighbors.ToList();

                // Try different quad pairings
                for (var i = 0; i < 4; i++)
                {
                    var n0 = neighborList[i];
                    var n1 = neighborList[(i + 1) % 4];
                    var n2 = neighborList[(i + 2) % 4];
                    var n3 = neighborList[(i + 3) % 4];

                    // Check if (n0, node, n1, opposite) and (n2, node, n3, opposite) form good quads
                    // This is complex, skip for now due to SimplexMesh limitations
                }
            }
        }

        return quadsCreated;
    }

    /// <summary>
    ///     Phase 3: Recognize and convert hexagon pattern (6 triangles → 3 quads).
    /// </summary>
    private static int RecognizeAndConvertHexagonPattern(ref SimplexMesh mesh, double[,] coords)
    {
        var quadsCreated = 0;

        // Find nodes with valence 6 (potential hexagon centers)
        var nodeValences = ComputeNodeValences(mesh);
        var nodeToTris = BuildNodeToTrianglesMap(mesh);

        foreach (var (node, tris) in nodeToTris)
        {
            if (tris.Count != 6) continue; // Hexagon center has exactly 6 triangles

            // Check if triangles form a regular hexagon pattern
            var neighbors = new HashSet<int>();
            foreach (var triIdx in tris)
            {
                var triNodes = mesh.NodesOf<Tri3, Node>(triIdx);
                foreach (var n in triNodes)
                    if (n != node)
                        neighbors.Add(n);
            }

            if (neighbors.Count == 6)
            {
                // Perfect hexagon: 6 neighbors around center
                // These 6 triangles could become 3 quads by removing center and connecting opposites
                // Complex topology change, requires mesh rebuild
                // Skip for now due to SimplexMesh limitations
            }
        }

        return quadsCreated;
    }

    /// <summary>
    ///     Phase 3: Convert valence-6 neighborhoods to better quad layouts.
    /// </summary>
    private static int ConvertValence6Neighborhoods(ref SimplexMesh mesh, double[,] coords)
    {
        var quadsCreated = 0;

        // Find all valence-6 interior nodes
        var nodeValences = ComputeNodeValences(mesh);

        foreach (var (node, valence) in nodeValences)
        {
            if (valence != 6) continue;

            // Valence-6 is very common in triangle meshes
            // Target: reduce to valence-4 by forming quads

            // Get all triangles around this node
            var adjacentTris = new List<int>();
            for (var i = 0; i < mesh.Count<Tri3>(); i++)
            {
                var triNodes = mesh.NodesOf<Tri3, Node>(i);
                if (triNodes.Contains(node))
                    adjacentTris.Add(i);
            }

            // Try to form quads from adjacent triangle pairs
            // This requires careful topology analysis
            // Complex implementation, simplified for now
        }

        return quadsCreated;
    }

    /// <summary>
    ///     Build a map from node ID to list of triangle indices containing that node.
    /// </summary>
    private static Dictionary<int, List<int>> BuildNodeToTrianglesMap(SimplexMesh mesh)
    {
        var nodeToTris = new Dictionary<int, List<int>>();

        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            foreach (var node in nodes)
            {
                if (!nodeToTris.ContainsKey(node))
                    nodeToTris[node] = new List<int>();
                nodeToTris[node].Add(i);
            }
        }

        return nodeToTris;
    }

    #endregion

    #region Helper Functions

    /// <summary>
    ///     Calculate average edge length from all boundaries.
    /// </summary>
    private static double CalculateAverageBoundaryEdgeLength(double[,] outerBoundary, List<double[,]>? holes)
    {
        var totalLength = 0.0;
        var totalEdges = 0;

        // Outer boundary
        var n = outerBoundary.GetLength(0);
        for (var i = 0; i < n; i++)
        {
            var j = (i + 1) % n;
            var dx = outerBoundary[j, 0] - outerBoundary[i, 0];
            var dy = outerBoundary[j, 1] - outerBoundary[i, 1];
            totalLength += Math.Sqrt(dx * dx + dy * dy);
            totalEdges++;
        }

        // Holes
        if (holes != null)
            foreach (var hole in holes)
            {
                var nh = hole.GetLength(0);
                for (var i = 0; i < nh; i++)
                {
                    var j = (i + 1) % nh;
                    var dx = hole[j, 0] - hole[i, 0];
                    var dy = hole[j, 1] - hole[i, 1];
                    totalLength += Math.Sqrt(dx * dx + dy * dy);
                    totalEdges++;
                }
            }

        return totalEdges > 0 ? totalLength / totalEdges : 1.0;
    }

    /// <summary>
    ///     Generate interior grid points with perturbation to avoid spoke patterns.
    /// </summary>
    private static List<(double x, double y)> GenerateInteriorGrid(
        double[,] outerBoundary,
        List<double[,]>? holes,
        double spacing)
    {
        var interiorPoints = new List<(double x, double y)>();

        // Get bounding box
        var n = outerBoundary.GetLength(0);
        double minX = double.MaxValue, maxX = double.MinValue;
        double minY = double.MaxValue, maxY = double.MinValue;

        for (var i = 0; i < n; i++)
        {
            var x = outerBoundary[i, 0];
            var y = outerBoundary[i, 1];
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
        }

        // Create quasi-uniform grid with hexagonal packing for better uniformity
        var random = new Random(12345); // Fixed seed for reproducibility
        var perturbation = spacing * 0.15; // Reduced from 0.3 for more uniformity

        var rowIndex = 0;
        for (var y = minY + spacing; y < maxY; y += spacing * 0.866) // Hex spacing: sqrt(3)/2
        {
            var xOffset = rowIndex % 2 == 1 ? spacing * 0.5 : 0.0; // Hex offset
            for (var x = minX + spacing + xOffset; x < maxX; x += spacing)
            {
                // Add small random perturbation to avoid perfect alignment
                var px = x + (random.NextDouble() - 0.5) * 2 * perturbation;
                var py = y + (random.NextDouble() - 0.5) * 2 * perturbation;

                // Check if inside outer boundary
                var point = (px, py);
                if (!IsPointInPolygon(point, outerBoundary))
                    continue;

                // Check if NOT inside any hole
                var inHole = false;
                if (holes != null)
                    foreach (var hole in holes)
                        if (IsPointInPolygon(point, hole))
                        {
                            inHole = true;
                            break;
                        }

                if (!inHole)
                    interiorPoints.Add(point);
            }

            rowIndex++;
        }

        return interiorPoints;
    }

    /// <summary>
    ///     Check if point is inside polygon using ray casting.
    /// </summary>
    private static bool IsPointInPolygon((double x, double y) point, double[,] polygon)
    {
        var n = polygon.GetLength(0);
        var inside = false;

        for (int i = 0, j = n - 1; i < n; j = i++)
        {
            double xi = polygon[i, 0], yi = polygon[i, 1];
            double xj = polygon[j, 0], yj = polygon[j, 1];

            if (yi > point.y != yj > point.y &&
                point.x < (xj - xi) * (point.y - yi) / (yj - yi) + xi)
                inside = !inside;
        }

        return inside;
    }

    /// <summary>
    ///     Refines boundary edges to ensure good mesh quality.
    ///     Only subdivides edges that are too long relative to neighbors.
    ///     Preserves existing good points.
    /// </summary>
    /// <param name="boundary">Input boundary coordinates</param>
    /// <param name="maxEdgeRatio">Maximum edge length ratio (default: 2.0)</param>
    /// <param name="minEdgeCount">Minimum total boundary edges (default: 200 for 2D)</param>
    /// <returns>Refined boundary with additional points</returns>
    private static double[,] RefineBoundaryEdges(double[,] boundary, double maxEdgeRatio = 2.0, int minEdgeCount = 200)
    {
        var n = boundary.GetLength(0);
        var dim = boundary.GetLength(1); // 2 or 3 dimensions
        if (n < 3)
            return boundary;

        const double epsilon = 1e-10;

        // Calculate all edge lengths
        var edgeLengths = new double[n];
        var totalLength = 0.0;
        var minLength = double.MaxValue;

        for (var i = 0; i < n; i++)
        {
            var j = (i + 1) % n;
            var dx = boundary[j, 0] - boundary[i, 0];
            var dy = boundary[j, 1] - boundary[i, 1];
            var length = Math.Sqrt(dx * dx + dy * dy);
            edgeLengths[i] = length;
            totalLength += length;

            if (length > epsilon && length < minLength)
                minLength = length;
        }

        if (totalLength < epsilon)
            return boundary;

        // Calculate target edge length to meet minimum count
        var targetFromCount = totalLength / minEdgeCount;
        var targetFromRatio = maxEdgeRatio * minLength;
        var targetLength = Math.Min(targetFromCount, targetFromRatio);

        // Build refined boundary - subdivide only long edges
        var refinedPoints = new List<(double x, double y)>();

        for (var i = 0; i < n; i++)
        {
            var j = (i + 1) % n;

            var x0 = boundary[i, 0];
            var y0 = boundary[i, 1];
            var x1 = boundary[j, 0];
            var y1 = boundary[j, 1];

            // Always add the current point
            refinedPoints.Add((x0, y0));

            var edgeLength = edgeLengths[i];

            if (edgeLength < epsilon)
                continue;

            // Subdivide if edge is too long
            if (edgeLength > targetLength * 1.01) // Small tolerance
            {
                var nSegments = Math.Max(1, (int)Math.Round(edgeLength / targetLength));

                // Add intermediate points
                for (var k = 1; k < nSegments; k++)
                {
                    var t = (double)k / nSegments;
                    var x = x0 + t * (x1 - x0);
                    var y = y0 + t * (y1 - y0);
                    refinedPoints.Add((x, y));
                }
            }
        }

        var nRefined = refinedPoints.Count;
        var result = new double[nRefined, 2];

        for (var i = 0; i < nRefined; i++)
        {
            result[i, 0] = refinedPoints[i].x;
            result[i, 1] = refinedPoints[i].y;
        }

        var added = nRefined - n;
        if (added > 0)
        {
            Console.WriteLine($"  → Refined boundary: {n} → {nRefined} points (+{added})");
            Console.WriteLine($"    Target edge length: {targetLength:F3} (from perimeter {totalLength:F2})");
        }

        return result;
    }

    #endregion

    #region Orientation Helpers

    /// <summary>
    ///     Add triangle to mesh with automatic CCW orientation checking.
    /// </summary>
    private static void AddTriangleCCW(SimplexMesh mesh, double[,] coords, int v0, int v1, int v2)
    {
        var ax = coords[v1, 0] - coords[v0, 0];
        var ay = coords[v1, 1] - coords[v0, 1];
        var bx = coords[v2, 0] - coords[v0, 0];
        var by = coords[v2, 1] - coords[v0, 1];
        var cross = ax * by - ay * bx;

        if (cross < -EPSILON)
            // CW - flip to CCW
            mesh.AddTriangle(v0, v2, v1);
        else if (cross > EPSILON)
            // Already CCW
            mesh.AddTriangle(v0, v1, v2);
        // Skip degenerate (cross ≈ 0)
    }

    /// <summary>
    ///     Add quad to mesh with automatic CCW orientation checking.
    /// </summary>
    private static void AddQuadCCW(SimplexMesh mesh, double[,] coords, int v0, int v1, int v2, int v3)
    {
        // Check if quad is CCW by testing cross product at first corner
        var ax = coords[v1, 0] - coords[v0, 0];
        var ay = coords[v1, 1] - coords[v0, 1];
        var bx = coords[v3, 0] - coords[v0, 0];
        var by = coords[v3, 1] - coords[v0, 1];
        var cross = ax * by - ay * bx;

        if (cross < -EPSILON)
            // CW - flip to CCW by reversing order
            mesh.AddQuad(v0, v3, v2, v1);
        else
            // Already CCW
            mesh.AddQuad(v0, v1, v2, v3);
    }

    #endregion
}